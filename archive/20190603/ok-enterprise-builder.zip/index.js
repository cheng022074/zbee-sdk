



{
    const {
        env
    } = process ;
    
    if(!env['ZBEE-APP-PATH']){
    
        env['ZBEE-APP-PATH'] = __dirname ;
    }
}

const include = (() =>{

    const nameRe = /^(\w+)\:{2}(.+?)$/,
          CODES = {};

    return name =>{

        if(CODES.hasOwnProperty(name)){

            return CODES[name] ;
        }

        let match = name.match(nameRe),
            folder,
            className;
    
        if(match){
    
            folder = match[1],
            className = match[2] ;
    
        }else{

            if(exports.hasOwnProperty(name)){

                return CODES[name] = exports[name] ;
            }
    
            folder = 'src',
            className = name ;
        }

        let fullName = `${folder}::${className}`,
            code = CODES[name] = exports[fullName] ;

        if(code === undefined && folder !== 'config'){

            throw new Error(`${fullName} 没有定义`) ;
        }

        return code ;
    } ;

})();


exports.include = include ;


const config = (() =>{

    const {
        freeze:freeze2,
        isFrozen,
        keys
    } = Object ;

    function freeze(data){

        if (data && typeof data === 'object' && !isFrozen(data)){

            freeze2(data);

            let names = keys(data) ;

            for(let name of names){

                freeze(data[name]) ;
            }
        }

        return data;
    }

    const config = {};

    function get_config(target , key){

        if(key){
    
            if(target.hasOwnProperty(key)){
        
                return freeze(target[key]) ;
            }
        
            let names = key.split(/\./),
                prefix = '';
        
            for(let name of names){
        
                let key = `${prefix}${name}` ;
        
                if(target.hasOwnProperty(key)){
        
                    target = target[key] ;
        
                    prefix = '' ;
                
                }else{
        
                    prefix = `${key}.` ;
                }
            }

            if(prefix){
        
                return ;
            }
        }

        return freeze(target) ; 
    }

    return (name , key) =>{

        try{

            const {
                env
            } = process ;

            let data;

            try{

                data = require(`${env['ZBEE-APPLICATION-ROOT-PATH']}/config/${name.replace(/\./g , '/')}.json`) ;

            }catch(err){
            }

            if(data){

                return get_config(data , key) ;
            }
        
        }catch(err){

        }

        if(config.hasOwnProperty(name)){

            return get_config(config[name] , key) ;
        }

        return get_config(include(`config::${name}`)() , key) ;
    }

})();




exports['src::is.type'] = (() =>{

                

                

                

                

                function main(data , type){

        /**
 * 
 * 对于 typeof 的简单封装
 * 
 * @param {mixed} data 检验数据
 * 
 * @param {string} type 检验数据类型
 * 
 * @return {boolean} 如果检验数据的数据类型与检验数据类型一致，则返回 true，否则返回 false 
 * 
 */

 return typeof data === type ;

    }

                return function(data , type){

                    

                    

                    return main.call(this , data , type) ;
                } ;

            })();

exports['src::is.array'] = (() =>{

                let isType;

                let var_init_locked_1559543037273;

                

                

                function main(data){

        /**
 * 
 * 判定数据是否为数组类型
 * 
 * @import is.type
 * 
 * @param {mixed} data 检验数据
 * 
 * @return {boolean} 如果给定值为数组类型则返回 true , 否则返回 false 
 * 
 */

 return Array.isArray(data) ;

    }

                return function(data){

                    
        if(!var_init_locked_1559543037273){

            isType = include('is.type');

            var_init_locked_1559543037273 = true ;
        }
        

                    

                    return main.call(this , data) ;
                } ;

            })();

exports['src::is.empty'] = (() =>{

                let isArray;

                let var_init_locked_1559543037276;

                

                

                function main(data , allowEmptyString){

        /**
 * 
 * 判定数据是否为空
 * 
 * @import is.array
 * 
 * @param {mixed} data 检验数据
 * 
 * @param {boolean} [allowEmptyString = false] 是否视空符串不为空，默认空符串为空
 * 
 * @return {mixed} 如果给定值为空则返回 true , 否则返回 false  
 * 
 */

return (data == null) || (!allowEmptyString ? data === '' : false) || (isArray(data) && data.length === 0);

    }

                return function(data , allowEmptyString = false){

                    
        if(!var_init_locked_1559543037276){

            isArray = include('is.array');

            var_init_locked_1559543037276 = true ;
        }
        

                    

                    return main.call(this , data , allowEmptyString) ;
                } ;

            })();

exports['src::is.string'] = (() =>{

                let isType;

                let var_init_locked_1559543037276;

                

                

                function main(data){

        /**
 * 
 * 判定数据是否为字符串类型
 * 
 * @import is.type
 * 
 * @param {mixed} data 检验数据
 * 
 * @return {boolean} 如果给定值为字符串类型则返回 true , 否则返回 false 
 * 
 */

return isType(data , 'string') ;

    }

                return function(data){

                    
        if(!var_init_locked_1559543037276){

            isType = include('is.type');

            var_init_locked_1559543037276 = true ;
        }
        

                    

                    return main.call(this , data) ;
                } ;

            })();

exports['src::array.from'] = (() =>{

                let isEmpty,isString;

                let var_init_locked_1559543037278;

                

                

                function main(data){

        /**
 * 
 * 将非数组数据打包成数组数据
 * 
 * @import is.empty
 * 
 * @import is.string
 * 
 * @param {mixed} data 数据
 * 
 * @return {array} 数组数据
 * 
 */

if(isEmpty(data)){

    return [];
}

if (data && data.length !== undefined && !isString(data)) {

    return Array.from(data);

}

return [
    data
];

    }

                return function(data){

                    
        if(!var_init_locked_1559543037278){

            isEmpty = include('is.empty');
isString = include('is.string');

            var_init_locked_1559543037278 = true ;
        }
        

                    

                    return main.call(this , data) ;
                } ;

            })();

exports['src::is.file'] = (() =>{

                

                

                

                

                function main(path){

        
/**
 * 
 * 判断路径是否为文件路径
 * 
 * @param {string} path 路径
 * 
 * @return {boolean} 路径是文件则返回 true , 否则返回 false
 * 
 */

const {
    existsSync,
    statSync
} = require('fs') ;

return existsSync(path) && statSync(path).isFile() ;


    }

                return function(path){

                    

                    

                    return main.call(this , path) ;
                } ;

            })();

exports['src::is.directory'] = (() =>{

                

                

                

                

                function main(path){

        
/**
 * 
 * 判断路径是否为文件夹路径
 * 
 * @param {string} path 路径
 * 
 * @return {boolean} 路径是文件夹则返回 true , 否则返回 false
 * 
 */

const {
    existsSync,
    statSync
} = require('fs') ;

return existsSync(path) && statSync(path).isDirectory() ;


    }

                return function(path){

                    

                    

                    return main.call(this , path) ;
                } ;

            })();

exports['src::directory.readAllFilePaths'] = (() =>{

                let isDirectory,isFile;

                let var_init_locked_1559543037285;

                

                

                
/**
 * 
 * 读取目录下所有文件的路径
 * 
 * @import is.directory
 * 
 * @import is.file
 * 
 * @param {string} path 文件夹目录路径
 * 
 * @param {RegExp} [testRe] 路径匹配正则表达式
 * 
 * @return {array} 多个文件路径
 * 
 */

function main(path , testRe){

    if(isDirectory(path)){

        const {
            readdirSync
        } = require('fs'),
        {
            join
        } = require('path');
    
        let names = readdirSync(path),
            paths = [];
    
        for(let name of names){
    
            let targetPath = join(path , name) ;
    
            if(isFile(targetPath)){

                if(testRe && !testRe.test(targetPath)){

                    continue ;
                }
    
                paths.push(targetPath) ;
            
            }else{
    
                paths.push(...main(targetPath , testRe)) ;
            }
        }
    
        return paths ;
    }
    
    return [] ;
}

                return function(path , testRe){

                    
        if(!var_init_locked_1559543037285){

            isDirectory = include('is.directory');
isFile = include('is.file');

            var_init_locked_1559543037285 = true ;
        }
        

                    

                    return main.call(this , path , testRe) ;
                } ;

            })();

exports['src::path.ext'] = (() =>{

                

                

                

                

                
/**
 * 
 * 获得路径的后缀名
 * 
 * @param {string} path 路径
 * 
 * @return {string} 后缀名
 * 
 */

const extRe = /\.[^\/\\]+$/ ;

function main(path){

    let result = path.match(extRe) ;

    if(result){

        return result[0] ;
    }
}

                return function(path){

                    

                    

                    return main.call(this , path) ;
                } ;

            })();

exports['src::directory.includes'] = (() =>{

                let from,isFile,isDirectory,getFilePaths,ext;

                let var_init_locked_1559543037288;

                

                

                
/**
 * 
 * 在指定目录下包含下符合包含、排除规则的所有文件
 * 
 * @import from from array.from
 * 
 * @import is.file
 * 
 * @import is.directory
 * 
 * @import getFilePaths from ..readAllFilePaths
 * 
 * @import ext from path.ext
 * 
 * @param {string} path 指定目录路径
 * 
 * @param {object} options 配置
 * 
 * @param {mixed} options.includes 包含资源
 * 
 * @param {mixed} [options.excludes] 排除资源
 * 
 * @param {mixed} [options.suffixes] 文件后缀名
 * 
 * @return {array} 所有符合规则的文件
 * 
 */

const {
    join
} = require('path');

function main(path , {
    includes,
    excludes,
    suffixes
}){

    let includeFilePaths = getPaths(path , includes),
        excludeFilePaths = getPaths(path , excludes);

    if(suffixes){

        suffixes = from(suffixes) ;
    }
    
    return includeFilePaths.filter(path => {

        if(!excludeFilePaths.includes(path)){

            if(suffixes && !suffixes.includes(ext(path))){

                return false ;
            }

            return true ;
        }

        return false ;

    }) ;
}

function getPaths(path , resources){

    resources = from(resources) ;

    let resourcePaths = [] ;

    for(let resource of resources){

        let resourcePath = join(path , resource) ;
    
        if(isFile(resourcePath)){
    
            resourcePaths.push(resourcePath) ;
    
        }else if(isDirectory(resourcePath)){
    
            resourcePaths.push(...getFilePaths(resourcePath)) ;
        }
    }

    return resourcePaths ;
    
}






                return function(path , {includes , excludes , suffixes}){

                    
        if(!var_init_locked_1559543037288){

            from = include('array.from');
isFile = include('is.file');
isDirectory = include('is.directory');
getFilePaths = include('src::directory.readAllFilePaths');
ext = include('path.ext');

            var_init_locked_1559543037288 = true ;
        }
        

                    

                    return main.call(this , path , {includes , excludes , suffixes}) ;
                } ;

            })();





