exports['src::message.center.constructor'] = (() => {









    function main() {


        /**
         * 
         * 初始化消息中心
         * 
         */

        this.addresses = {};

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::message.address.constructor'] = (() => {









    function main(name) {


        /**
         * 
         * 初始化地址
         * 
         * @param {string} name 地址名称
         * 
         * 
         */

        let me = this;

        me.name = name;

        me.messages = [];

    }

    return function(name) {





        return main.call(this, name);
    };

})();

exports['src::is.defined'] = (() => {









    function main(data) {

        /**
         * 
         * 判断给定数据是否定义
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果数据定义则返回 true , 否则返回 false
         * 
         */

        return data !== undefined;

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::is.type'] = (() => {









    function main(data, type) {

        /**
         * 
         * 对于 typeof 的简单封装
         * 
         * @param {mixed} data 检验数据
         * 
         * @param {string} type 检验数据类型
         * 
         * @return {boolean} 如果检验数据的数据类型与检验数据类型一致，则返回 true，否则返回 false 
         * 
         */

        return typeof data === type;

    }

    return function(data, type) {





        return main.call(this, data, type);
    };

})();

exports['src::is.string'] = (() => {

    let isType;

    let var_init_locked_1556184849889;





    function main(data) {

        /**
         * 
         * 判定数据是否为字符串类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为字符串类型则返回 true , 否则返回 false 
         * 
         */

        return isType(data, 'string');

    }

    return function(data) {


        if (!var_init_locked_1556184849889) {

            isType = include('is.type');

            var_init_locked_1556184849889 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.object.simple'] = (() => {









    function main(data) {

        /**
         * 
         * 判定数据是否为简单对象类型
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为简单对象类型则返回 true , 否则返回 false 
         * 
         */

        return data instanceof Object && data.constructor === Object;

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::message.address.send'] = (() => {

    let getCenter, isString, isObject;

    let var_init_locked_1556184849897;





    function main(message) {

        /**
         * 
         * 发送消息
         * 
         * @import getCenter from message.center
         * 
         * @import is.string
         * 
         * @import isObject from is.object.simple
         * 
         * @param {mixed} message 消息配置
         * 
         * 
         */

        let center = getCenter();

        if (isString(message)) {

            center.receive({
                to: message
            });

        } else if (isObject(message)) {

            let {
                from
            } = message;

            if (from) {

                let {
                    name
                } = this;

                message.from = `${name}::${from}`;
            }

            center.receive(message);
        }

    }

    return function(message) {


        if (!var_init_locked_1556184849897) {

            getCenter = include('message.center');
            isString = include('is.string');
            isObject = include('is.object.simple');

            var_init_locked_1556184849897 = true;
        }




        return main.call(this, message);
    };

})();

exports['src::message.address.doAction'] = (() => {

    let isDefined, send;

    let var_init_locked_1556184849903;

    let var_current_scope_1556184849903;



    async function main(target, message) {


        /**
         * 
         * 执行绑定对象相关函数
         * 
         * @import is.defined
         * 
         * @import send from .send scoped
         * 
         * @param {mixed} target 作用对象
         * 
         * @param {object} message 消息
         * 
         */

        let {
            toAction,
            from,
            payload
        } = message;

        if (toAction in target) {

            let result = await target[toAction](payload, message);

            if (from && isDefined(result)) {

                send({
                    to: from,
                    replyPayload: payload,
                    payload: result
                });
            }
        }

    }

    return async function(target, message) {


        if (!var_init_locked_1556184849903) {

            isDefined = include('is.defined');

            var_init_locked_1556184849903 = true;
        }



        if (!var_current_scope_1556184849903 !== this) {

            send = include('src::message.address.send').bind(this);

            var_current_scope_1556184849903 = this;
        }


        return await main.call(this, target, message);
    };

})();

exports['src::message.address.bind'] = (() => {

    let doAction;

    let var_init_locked_1556184849912;

    let var_current_scope_1556184849912;



    function main(target) {


        /**
         * 
         * 绑定目标对象
         * 
         * @import doAction from .doAction scoped
         * 
         * @param {mixed} target 目标对象
         * 
         */

        let me = this,
            {
                target: currentTarget,
                messages
            } = me;

        if (!currentTarget) {

            for (let message of messages) {

                doAction(target, message);

            }

            messages.length = 0;

            me.target = target;

            return true;

        } else if (currentTarget === me) {

            return true;
        }

        return false;


    }

    return function(target) {




        if (!var_current_scope_1556184849912 !== this) {

            doAction = include('src::message.address.doAction').bind(this);

            var_current_scope_1556184849912 = this;
        }


        return main.call(this, target);
    };

})();

exports['src::array.remove.index'] = (() => {









    function main(data, index) {


        /**
         * 
         * 根据数组下标删除对应项
         * 
         * @param {array} data 作用数组
         * 
         * @param {number} index 数组项的下标
         * 
         * @return {boolean} 如果删除成功则返回 true , 否则返回　false 
         * 
         */

        if (index >= 0 && index < data.length) {

            data.splice(index, 1);

            return true;
        }

        return false;

    }

    return function(data, index) {





        return main.call(this, data, index);
    };

})();

exports['src::array.remove'] = (() => {

    let remove;

    let var_init_locked_1556184849923;





    function main(data, item) {


        /**
         * 
         * 在数组中去除项目
         * 
         * @import remove from array.remove.index
         * 
         * @param {array} data 数组
         * 
         * @param {mixed} item 项目
         * 
         * @return {boolean} 如果删除项目成功则返回 true ，否则返回 false 
         * 
         */

        return remove(data, data.indexOf(item));


    }

    return function(data, item) {


        if (!var_init_locked_1556184849923) {

            remove = include('array.remove.index');

            var_init_locked_1556184849923 = true;
        }




        return main.call(this, data, item);
    };

})();

exports['src::message.address.unbind'] = (() => {

    let remove;

    let var_init_locked_1556184849925;





    function main() {


        /**
         * 
         * 取消绑定目标对象
         * 
         * @import remove from array.remove
         * 
         */

        delete this.target;



    }

    return function() {


        if (!var_init_locked_1556184849925) {

            remove = include('array.remove');

            var_init_locked_1556184849925 = true;
        }




        return main.call(this);
    };

})();

exports['src::message.address.receive'] = (() => {

    let doAction;

    let var_init_locked_1556184849928;

    let var_current_scope_1556184849928;



    function main(message) {


        /**
         * 
         * 接收消息
         * 
         * @import doAction from .doAction scoped
         * 
         * @param {Message} message 消息
         * 
         */

        let {
            target,
            messages
        } = this;

        if (target) {

            doAction(target, message);

        } else {

            messages.push(message);
        }

    }

    return function(message) {




        if (!var_current_scope_1556184849928 !== this) {

            doAction = include('src::message.address.doAction').bind(this);

            var_current_scope_1556184849928 = this;
        }


        return main.call(this, message);
    };

})();

exports['src::message.address'] = (() => {

    let constructor, method_bind, method_unbind, method_receive, method_send;

    let var_init_locked_1556184849935;

    let var_class_1556184849935;

    return function() {


        if (!var_init_locked_1556184849935) {

            constructor = include('src::message.address.constructor');
            method_bind = include('src::message.address.bind');
            method_unbind = include('src::message.address.unbind');
            method_receive = include('src::message.address.receive');
            method_send = include('src::message.address.send');

            var_init_locked_1556184849935 = true;
        }



        if (!var_class_1556184849935) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                bind(...args) {

                    return method_bind.apply(this, args);

                }
                unbind(...args) {

                    return method_unbind.apply(this, args);

                }
                receive(...args) {

                    return method_receive.apply(this, args);

                }
                send(...args) {

                    return method_send.apply(this, args);

                }



            }

            var_class_1556184849935 = main;
        }


        return new var_class_1556184849935();
    };

})();

exports['src::message.center.register'] = (() => {

    let create;

    let var_init_locked_1556184849942;





    function main(address) {


        /**
         * 
         * 注册地址
         * 
         * @import create from message.address
         * 
         * @param {string} address 消息地址
         * 
         * 
         */

        let {
            addresses
        } = this;

        if (!addresses.hasOwnProperty(address)) {

            addresses[address] = create(address);
        }

        return addresses[address];

    }

    return function(address) {


        if (!var_init_locked_1556184849942) {

            create = include('message.address');

            var_init_locked_1556184849942 = true;
        }




        return main.call(this, address);
    };

})();

exports['src::message.address.parse'] = (() => {









    function main(address) {


        /**
         * 
         * 解析消息地址
         * 
         * @param {string} address 消息地址
         * 
         * @return {object} 地址解析后的结果 
         * 
         */

        let match = address.match(/^([^\:]+)\:{2}([^\:]+)$/);

        if (match) {

            let [,
                address,
                action
            ] = match;

            return {
                address,
                action
            };
        }

    }

    return function(address) {





        return main.call(this, address);
    };

})();

exports['src::message.center.receive'] = (() => {

    let parse;

    let var_init_locked_1556184849950;





    function main({
        from,
        to,
        payload
    }) {


        /**
         * 
         * 接收消息
         * 
         * @import parse from message.address.parse
         * 
         * @param {object} message 消息
         * 
         * @param {string} [message.from] 消息来源地址
         * 
         * @param {string} message.to 消息发送地址
         * 
         * @param {mixed} [message.payload] 消息负荷
         * 
         */

        let result = parse(to);

        if (result) {

            let {
                address: toAddress,
                action: toAction
            } = result;

            this.register(toAddress).receive({
                toAction,
                payload,
                from
            });
        }


    }

    return function({
        from,
        to,
        payload
    }) {


        if (!var_init_locked_1556184849950) {

            parse = include('message.address.parse');

            var_init_locked_1556184849950 = true;
        }




        return main.call(this, {
            from,
            to,
            payload
        });
    };

})();

exports['src::message.center'] = (() => {

    let constructor, method_register, method_receive;

    let var_init_locked_1556184849952;

    let var_class_1556184849952;

    return function() {


        if (!var_init_locked_1556184849952) {

            constructor = include('src::message.center.constructor');
            method_register = include('src::message.center.register');
            method_receive = include('src::message.center.receive');

            var_init_locked_1556184849952 = true;
        }



        if (!var_class_1556184849952) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                register(...args) {

                    return method_register.apply(this, args);

                }
                receive(...args) {

                    return method_receive.apply(this, args);

                }



            }

            var_class_1556184849952 = main;
        }



        if (var_once_value_1556184849952) {

            return var_once_value_1556184849952;

        }

        return var_once_value_1556184849952 = new var_class_1556184849952();

    };

})();

exports['src::id.generate'] = (() => {










    /**
     * 
     * 生成唯一的编号
     * 
     * @param {string} prefix 编号前缀
     * 
     * @return {string} 生成后的唯一编号 
     * 
     */

    let count = 1;

    function main(prefix = 'zb-') {

        return `${prefix}${count ++}`;

    }

    return function(prefix) {





        return main.call(this, prefix);
    };

})();

exports['src::message.address.react'] = (() => {

    let getCenter, get;

    let var_init_locked_1556184849963;





    function main(ReactDOM, reactClass, address) {

        /**
         * 
         * 基于 React 基于消息系统
         * 
         * @import getCenter from message.center
         * 
         * @import get from id.generate
         * 
         * @param {ReactDOM} ReactDOM ReactDOM 引用
         * 
         * @param {React.Component} reactClass 继承的 React 组件类
         * 
         * @param {string} [address] 组件注册的消息地址
         * 
         */

        let center = getCenter(),
            count = 1;

        return class extends reactClass {

            componentDidMount() {

                let me = this,
                    {
                        address: currentAddress
                    } = me.props;

                currentAddress = currentAddress || address || get('address-');

                let {
                    $address
                } = me;

                if ($address) {

                    console.error('已拥有消息地址', $address.name, currentAddress);

                } else {

                    let messageAddress = center.register(currentAddress),
                        isBind = messageAddress.bind(me);

                    if (!isBind) {

                        console.error('消息地址已被注册', currentAddress, ReactDOM.findDOMNode(me), ReactDOM.findDOMNode(messageAddress.target));

                    } else {

                        me.$address = messageAddress;

                    }

                }

                if (super.componentDidMount) {

                    super.componentDidMount();
                }

            }

            componentWillUnmount() {

                if (super.componentWillUnmount) {

                    super.componentWillUnmount();
                }

                let me = this,
                    {
                        $address: address
                    } = me;

                if (address) {

                    address.unbind();

                    delete me.$address;
                }
            }

        }

    }

    return function(ReactDOM, reactClass, address) {


        if (!var_init_locked_1556184849963) {

            getCenter = include('message.center');
            get = include('id.generate');

            var_init_locked_1556184849963 = true;
        }




        return main.call(this, ReactDOM, reactClass, address);
    };

})();

exports['src::array.remove.all'] = (() => {

    let remove;

    let var_init_locked_1556184849969;





    function main(data, item) {


        /**
         * 
         * 在数组中去除所有指定项目
         * 
         * @import remove from array.remove
         * 
         * @param {array} data 数组
         * 
         * @param {mixed} item 项目
         * 
         */

        while (true) {

            if (remove(data, item) === false) {

                break;
            }
        }

    }

    return function(data, item) {


        if (!var_init_locked_1556184849969) {

            remove = include('array.remove');

            var_init_locked_1556184849969 = true;
        }




        return main.call(this, data, item);
    };

})();

exports['src::url.append'] = (() => {

    let isString;

    let var_init_locked_1556184849973;





    function main(url, data) {


        /**
         * 
         * 基于已有链接附加查询信息
         * 
         * @import is.string
         * 
         * @param {string} url 链接
         * 
         * @param {mixed} data 附加查询信息
         * 
         * @return {mixed} 拼接了查询信息的链接 
         * 
         */

        let querystring;

        if (isString(data)) {

            querystring = data;

        } else {

            querystring = [];

            let names = Object.keys(data);

            for (let name of names) {

                querystring.push(`${name}=${encodeURIComponent(data[name])}`);
            }

            querystring = querystring.join('&');

        }

        if (querystring) {

            if (url.includes('?')) {

                return `${url}&${querystring}`;
            }

            return `${url}?${querystring}`;

        }

        return url;


    }

    return function(url, data) {


        if (!var_init_locked_1556184849973) {

            isString = include('is.string');

            var_init_locked_1556184849973 = true;
        }




        return main.call(this, url, data);
    };

})();

exports['src::regexp.int'] = (() => {









    function main(data) {


        /**
         * 
         * 匹配整数
         * 
         * @param {string} data 参数说明
         * 
         * @return {boolean} 如果匹配成功则返回 true , 否则返回 false 
         * 
         */

        return /^\d+$/.test(data);

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::url.template.apply'] = (() => {

    let isInt;

    let var_init_locked_1556184849978;





    function main(url, data) {


        /**
         * 
         * 路径模板应用
         * 
         * @import isInt from regexp.int
         * 
         * @param {string} url 带有参数定义的URL
         * 
         * @param {object} data 模板参数定义数据集合
         * 
         * @return {string} 应用数据后的URL链接
         * 
         */

        return url.replace(/\:(\w+)/g, (match, name) => {

            if (isInt(name)) {

                return `:${name}`;
            }

            return data[name] || '';

        });


    }

    return function(url, data) {


        if (!var_init_locked_1556184849978) {

            isInt = include('regexp.int');

            var_init_locked_1556184849978 = true;
        }




        return main.call(this, url, data);
    };

})();

exports['src::is.array'] = (() => {

    let isType;

    let var_init_locked_1556184849980;





    function main(data) {

        /**
         * 
         * 判定数据是否为数组类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为数组类型则返回 true , 否则返回 false 
         * 
         */

        return Array.isArray(data);

    }

    return function(data) {


        if (!var_init_locked_1556184849980) {

            isType = include('is.type');

            var_init_locked_1556184849980 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.object'] = (() => {

    let isType;

    let var_init_locked_1556184849982;





    function main(data) {

        /**
         * 
         * 判定数据是否为对象类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为对象类型则返回 true , 否则返回 false 
         * 
         */

        return Object.prototype.toString.call(data) === '[object Object]';

    }

    return function(data) {


        if (!var_init_locked_1556184849982) {

            isType = include('is.type');

            var_init_locked_1556184849982 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::object.key.join'] = (() => {










    /**
     * 
     * 将多个键值连接起来
     * 
     * @param {array} [...keys] 一组键值
     * 
     * @return {string} 连接后的键值 
     * 
     */

    const suffixRe = /(?:^\.+)|(?:\.+$)/g;

    function main(...keys) {

        let result = [];

        for (let key of keys) {

            key = key.replace(suffixRe, '');

            if (key) {

                result.push(key);
            }
        }

        return result.join('.');
    }



    return function(...keys) {





        return main.call(this, ...keys);
    };

})();

exports['src::object.get'] = (() => {

    let isArray, isObject, isDefined, join;

    let var_init_locked_1556184849988;






    /**
     * 
     * 获得一个对象的键值
     * 
     * @import is.array
     * 
     * @import is.object
     * 
     * @import is.defined
     * 
     * @import join from object.key.join
     * 
     * @param {object} data 对象数据
     * 
     * @param {string} [key = '.'] 对象键值
     * 
     * @return {mixed} 对应对象数据的键值的数据 
     * 
     * @scoped
     * 
     */

    const firstKeyRe = /^([^\.]+)\./;

    function main(data, key, prefixKey = '') {

        if (key === '.') {

            return data;
        }

        if (isObject(data)) {

            let firstKey,
                lastKey = key.replace(firstKeyRe, function() {

                    firstKey = arguments[1];

                    return '';

                });

            if (firstKey) {

                firstKey = join(prefixKey, firstKey);

                let result;

                if (data.hasOwnProperty(firstKey)) {

                    result = data[firstKey];

                    prefixKey = '';

                } else {

                    result = data;

                    prefixKey = firstKey;
                }

                if (lastKey) {

                    return main(result, lastKey, prefixKey);
                }

                return result;

            } else {

                return data[join(prefixKey, lastKey)];
            }

        } else if (isArray(data)) {

            let result = [];

            for (let item of data) {

                let itemResult = main(item, key);

                if (isArray(itemResult)) {

                    result.push(...itemResult);

                } else if (!isDefined(itemResult)) {

                    result.push(itemResult);

                }
            }

            return result;
        }
    }

    return function(data, key = '.') {


        if (!var_init_locked_1556184849988) {

            isArray = include('is.array');
            isObject = include('is.object');
            isDefined = include('is.defined');
            join = include('object.key.join');

            var_init_locked_1556184849988 = true;
        }




        return main.call(this, data, key);
    };

})();

exports['src::is.function'] = (() => {

    let isType;

    let var_init_locked_1556184849991;





    function main(data) {

        /**
         * 
         * 判定数据是否为函数类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {mixed} 如果给定值为函数类型则返回 true , 否则返回 false
         * 
         */

        return isType(data, 'function');

    }

    return function(data) {


        if (!var_init_locked_1556184849991) {

            isType = include('is.type');

            var_init_locked_1556184849991 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.empty'] = (() => {

    let isArray;

    let var_init_locked_1556184849995;





    function main(data, allowEmptyString) {

        /**
         * 
         * 判定数据是否为空
         * 
         * @import is.array
         * 
         * @param {mixed} data 检验数据
         * 
         * @param {boolean} [allowEmptyString = false] 是否视空符串不为空，默认空符串为空
         * 
         * @return {mixed} 如果给定值为空则返回 true , 否则返回 false  
         * 
         */

        return (data == null) || (!allowEmptyString ? data === '' : false) || (isArray(data) && data.length === 0);

    }

    return function(data, allowEmptyString = false) {


        if (!var_init_locked_1556184849995) {

            isArray = include('is.array');

            var_init_locked_1556184849995 = true;
        }




        return main.call(this, data, allowEmptyString);
    };

})();

exports['src::array.from'] = (() => {

    let isEmpty, isString;

    let var_init_locked_1556184849998;





    function main(data) {

        /**
         * 
         * 将非数组数据打包成数组数据
         * 
         * @import is.empty
         * 
         * @import is.string
         * 
         * @param {mixed} data 数据
         * 
         * @return {array} 数组数据
         * 
         */

        if (isEmpty(data)) {

            return [];
        }

        if (data && data.length !== undefined && !isString(data)) {

            return Array.from(data);

        }

        return [
            data
        ];

    }

    return function(data) {


        if (!var_init_locked_1556184849998) {

            isEmpty = include('is.empty');
            isString = include('is.string');

            var_init_locked_1556184849998 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::object.keys'] = (() => {

    let isObject;

    let var_init_locked_1556184850001;





    /**
     * 
     * 获取对象的键值组合
     * 
     * @import isObject from is.object.simple
     * 
     * @param {object} data 对象
     * 
     * @return {array} 键值数组
     * 
     * @scoped
     * 
     */

    function main(data) {

        return get_keys(data);
    }

    function get_keys(data, rootKey = '') {

        let keys = Object.keys(data),
            result = [];

        for (let key of keys) {

            let value = data[key];

            if (isObject(value)) {

                result.push(...get_keys(value, `${rootKey}${key}.`));

            } else {

                result.push(`${rootKey}${key}`);
            }
        }

        return result;
    }


    return function(data) {


        if (!var_init_locked_1556184850001) {

            isObject = include('is.object.simple');

            var_init_locked_1556184850001 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::string.split'] = (() => {

    let isEmpty;

    let var_init_locked_1556184850003;






    /**
     * 
     * 将字符串通过间隔符分隔成数组
     * 
     * @import is.empty
     * 
     * @param {String} target 字符串
     * 
     * @param {RegEx} splitRe 字符串分隔符
     * 
     * @scoped
     * 
     */

    function main(target, splitRe) {

        return target.split(splitRe).filter(filter);
    }

    function filter(target) {

        return !isEmpty(target);
    }

    return function(target, splitRe) {


        if (!var_init_locked_1556184850003) {

            isEmpty = include('is.empty');

            var_init_locked_1556184850003 = true;
        }




        return main.call(this, target, splitRe);
    };

})();

exports['src::object.set'] = (() => {

    let isObject, split;

    let var_init_locked_1556184850005;





    /**
     * 
     * 设置对象的属性值
     * 
     * @import is.object
     * 
     * @import split from string.split
     * 
     * @param {object} target 目标对象
     * 
     * @param {string} key 属性名称
     * 
     * @param {mixed} value 属性值
     * 
     * @scoped
     * 
     */

    const splitRe = /\./;

    function main(target, key, value) {

        if (splitRe.test(key)) {

            let keys = split(key, splitRe);

            key = keys.pop();

            for (let key of keys) {

                let data = target[key];

                if (!isObject(data)) {

                    data = target[key] = {};
                }

                target = data;
            }

            target[key] = value;

        } else {

            target[key] = value;
        }
    }

    return function(target, key, value) {


        if (!var_init_locked_1556184850005) {

            isObject = include('is.object');
            split = include('string.split');

            var_init_locked_1556184850005 = true;
        }




        return main.call(this, target, key, value);
    };

})();

exports['src::object.assign.if'] = (() => {

    let getKeys, set, get;

    let var_init_locked_1556184850010;






    /**
     * 
     * 如果目标存在来源的字段，则不覆盖
     * 
     * @import getKeys from object.keys
     * 
     * @import set from object.set
     * 
     * @import get from object.get
     * 
     * @param {object} dest 目标数据
     * 
     * @param {object} [...sources] 来源数据
     * 
     * @return {object} 合并后数据
     * 
     * @scoped
     * 
     */

    function assign(dest, source) {

        let keys = getKeys(source),
            destKeys = getKeys(dest);

        for (let key of keys) {

            if (!destKeys.includes(key)) {

                set(dest, key, get(source, key));
            }
        }

    }

    function main(dest, ...sources) {

        for (let source of sources) {

            assign(dest, source);
        }

        return dest;

    }

    return function(dest, ...sources) {


        if (!var_init_locked_1556184850010) {

            getKeys = include('object.keys');
            set = include('object.set');
            get = include('object.get');

            var_init_locked_1556184850010 = true;
        }




        return main.call(this, dest, ...sources);
    };

})();

exports['src::data.reader.fields'] = (() => {

    let isString, isObject;

    let var_init_locked_1556184850015;





    function main(fields) {


        /**
         * 
         * 格式化读取字段配置
         * 
         * @import is.string
         * 
         * @import isObject from is.object.simple
         * 
         * @param {array} fields 字段配置
         * 
         * @return {array} 格式化后的字段配置 
         * 
         */

        let result = [],
            names = [];

        for (let field of fields) {

            if (isString(field)) {

                field = {
                    name: field,
                    mapping: field
                };

            }

            if (isObject(field) && field.hasOwnProperty('name')) {

                let {
                    name
                } = field;

                if (!names.includes(name)) {

                    result.push(field);

                    names.push(name);
                }
            }
        }

        return result;


    }

    return function(fields) {


        if (!var_init_locked_1556184850015) {

            isString = include('is.string');
            isObject = include('is.object.simple');

            var_init_locked_1556184850015 = true;
        }




        return main.call(this, fields);
    };

})();

exports['src::data.reader.json'] = (() => {

    let get, isString, isFunction, isObject, arrayFrom, isEmpty, assign, getFields;

    let var_init_locked_1556184850019;





    /**
     * 
     * JSON 数据读取器
     * 
     * @import get from object.get
     * 
     * @import is.string
     * 
     * @import is.function
     * 
     * @import isObject from is.object.simple
     * 
     * @import array.from
     * 
     * @import is.empty
     * 
     * @import assign from object.assign.if
     * 
     * @import getFields from data.reader.fields
     * 
     * @param {object} [config = {}] 读取参数设置
     * 
     * @param {string} [config.rootProperty = '.'] 读取数据的根
     * 
     * @param {string} [config.fields = []] 读取数据记录的字段项
     * 
     * @param {function} [config.create] 基于构建出来的数据进行构建对象
     * 
     * @param {function} [config.createExtraParams = {}] 基于构建对象函数附加参数
     * 
     * @param {boolean} [config.multi = true] 如果设置为 true , 则返回数组，设置为 false , 则返回第一条记录 
     * 
     * @return {function} 读取器所生成的解析函数
     * 
     */

    function main({
        rootProperty,
        fields,
        multi,
        create: createFn,
        createExtraParams
    }) {

        fields = getFields(fields);

        return (new Function('data', `

      var me = this,
         include = me.include,
         converts = me.converts,
         createFn = me.createFn,
         get = include('object.get'),
         from = include('array.from'),
         isEmpty = include('is.empty');

      ${generate_get_root_data(rootProperty)}

      data = from(data) ;

      var result = [],
          len = data.length;

      for(var i = 0 ; i < len ; i ++){

         var item = {},
             currentItem = data[i];

         ${generate_get_field_data(fields)}

         result.push(createFn(item)) ;
      }

      ${generate_result(multi)}

    `)).bind({
            include,
            converts: generate_get_field_converts(fields),
            createFn: data => {

                if (isFunction(createFn)) {

                    return createFn(assign(data, createExtraParams));
                }

                return data;

            }
        });
    }

    function generate_result(multi) {

        return multi ? `return result;` : `return result[0];`;
    }

    function generate_get_root_data(rootProperty) {

        if (rootProperty !== '.') {

            return `data = get(data , '${rootProperty}');`;
        }

        return '';
    }

    function generate_get_field_converts(fields) {

        let converts = {};

        for (let field of fields) {

            let {
                name,
                convert
            } = field;

            if (convert) {

                converts[name] = convert;
            }
        }

        return converts;
    }

    const {
        stringify
    } = JSON;

    function generate_get_field_data(fields) {

        let result = [];

        for (let field of fields) {

            let {
                name,
                mapping,
                convert,
                defaultValue
            } = field;

            if (convert) {

                result.push(`item.${name} = converts.${name}(currentItem);`);

            } else if (mapping) {

                result.push(`item.${name} = get(currentItem , '${mapping}');`);
            }

            if (defaultValue) {

                result.push(`item.${name} = isEmpty(item.${name}) ? ${stringify(defaultValue)} : item.${name};`);
            }

            result.push(`if(isEmpty(item.${name})){delete item.${name};}`);
        }

        return result.join('');
    }

    return function({
        rootProperty = '.',
        fields = [],
        create,
        createExtraParams = {},
        multi = true
    } = {}) {


        if (!var_init_locked_1556184850019) {

            get = include('object.get');
            isString = include('is.string');
            isFunction = include('is.function');
            isObject = include('is.object.simple');
            arrayFrom = include('array.from');
            isEmpty = include('is.empty');
            assign = include('object.assign.if');
            getFields = include('data.reader.fields');

            var_init_locked_1556184850019 = true;
        }




        return main.call(this, {
            rootProperty,
            fields,
            create,
            createExtraParams,
            multi
        });
    };

})();

exports['src::data.connection.ajax'] = (() => {

    let append, apply, isObject, createReader;

    let var_init_locked_1556184850025;





    function main(url, {
        method,
        query,
        params,
        path,
        requestJSON
    }) {


        /**
         * 
         * 基于 AJAX 进行数据交互
         * 
         * @import append from url.append
         * 
         * @import apply from url.template.apply
         * 
         * @import isObject from is.object.simple
         * 
         * @import createReader from data.reader.json
         * 
         * @require axios
         * 
         * @require qs
         * 
         * @param {string} url 请求路径
         * 
         * @param {object} [config] 请求配置
         * 
         * @param {string} [config.method = 'GET'] 请求方式，默认是 GET 请求
         * 
         * @param {object} [config.query] GET请求的参数集合
         * 
         * @param {object} [config.params = {}] 请求主体的参数集合
         * 
         * @param {object} [config.path] 以路径参数形式提交的参数集合
         * 
         * @param {boolean} [config.requestJSON = true] 是否以 JSON方式提交数据
         * 
         */

        if (query) {

            url = append(url, query);
        }

        if (path) {

            url = apply(url, path);
        }

        const axios = require('axios'),
            {
                stringify
            } = require('qs');

        switch (method) {

            case 'GET':
            case 'DELETE':

                url = append(url, params);

                break;

            case 'POST':
            case 'PUT':

                if (requestJSON === false) {

                    params = stringify(params);
                }
        }

        return axios[method.toLowerCase()](url, params).then(({
            data
        }) => data);



    }

    return function(url, {
        method = 'GET',
        query,
        params = {},
        path,
        requestJSON = true
    }) {


        if (!var_init_locked_1556184850025) {

            append = include('url.append');
            apply = include('url.template.apply');
            isObject = include('is.object.simple');
            createReader = include('data.reader.json');

            var_init_locked_1556184850025 = true;
        }




        return main.call(this, url, {
            method,
            query,
            params,
            path,
            requestJSON
        });
    };

})();

exports['src::data.connection.socket.io'] = (() => {









    /**
     * 
     * 基于 socket.io 标准进行开发
     * 
     * @param {string} url socket.io 连接地址
     * 
     * @param {object} config socket.io 连接配置
     * 
     * @require socket.io-client
     * 
     */

    const IO = require('socket.io-client');

    function main(url, options) {

        return new Socket(url, options);
    }

    class Socket {

        constructor(url, options = {}) {

            let me = this;

            me.url = url;

            me.options = options;

            me.socket = IO(url, {
                transports: [
                    'websocket',
                    'polling'
                ],
                ...options
            });
        }

        get connected() {

            let {
                socket
            } = this;

            return socket.connected;
        }

        emit(event, ...args) {

            let me = this,
                {
                    connected,
                    socket
                } = me;

            if (connected) {

                socket.emit(event, ...args);

            } else {

                const emitFn = () => me.emit(event, ...args);

                socket.once('connect', emitFn);

                socket.once('reconnect', emitFn);
            }
        }

        on(event, fn) {

            this.socket.on(event, fn);
        }
    }

    return function(url, config) {





        return main.call(this, url, config);
    };

})();

exports['src::data.connection.socket.standard'] = (() => {

    let createTimer;

    let var_init_locked_1556184850036;





    /**
     * 
     * 基于标准 WebSocket 进行开发
     * 
     * @import createTimer from timer
     * 
     * @param {string} url socket 连接地址
     * 
     * @param {object} config socket 连接配置
     * 
     */

    function main(url, options = {}) {

        return new Socket(url, options);
    }

    const EventEmitter = require('events');

    class Socket extends EventEmitter {

        constructor(url, options) {

            super();

            let me = this;

            me.url = url;

            me.options = options;

            let {
                timeout = 20000,
                    parse
            } = options;

            me.timer = createTimer(timeout);

            createSocket.call(me);

            let {
                socket
            } = me;

            socket.addEventListener('message', ({
                data
            }) => {

                let {
                    event,
                    params
                } = parse(data);

                me.emit(event, params);

            });

            let onException = () => reconnect.call(me);

            me.once('connect', () => {

                socket.addEventListener('error', onException);

                socket.addEventListener('close', onException);

            });
        }

        get connected() {

            let {
                socket
            } = this;

            return socket.readyState === 1;
        }

        emit(event, ...args) {

            let me = this,
                {
                    connected,
                    options,
                    socket
                } = me,
                {
                    stringify
                } = options;

            if (connected) {

                socket.send(stringify(event, args));

            } else {

                me.on('connect', () => me.emit(event, ...args));
            }
        }

        on(eventName, fn) {

            this.addListener(eventName, fn);
        }
    }

    function reconnect() {

        let me = this;

        if (me.connected) {

            me.socket.close();
        }

        return createSocket.call(me);
    }

    function createSocket() {

        let me = this,
            socket = me.socket = new WebSocket(url),
            {
                timer
            } = me,
            onConnectError = () => me.emit('connect_error');

        timer.start();

        timer.on('timeout', () => me.emit('connect_timeout'));

        socket.addEventListener('open', () => {

            socket.removeEventListener('error', onConnectError);

            timer.end();

            me.emit('connect');

        });

        socket.addEventListener('error', onConnectError);

        return me.socket;
    }

    return function(url, config) {


        if (!var_init_locked_1556184850036) {

            createTimer = include('timer');

            var_init_locked_1556184850036 = true;
        }




        return main.call(this, url, config);
    };

})();

exports['src::object.equals'] = (() => {

    let keys, get;

    let var_init_locked_1556184850041;





    function main(value1, value2) {

        /**
         * 
         * 匹配两个对象数据是否匹配
         * 
         * @import keys from object.keys
         * 
         * @import get from object.get
         * 
         * @param {object} value1 第一个对象数据
         * 
         * @param {object} value2 第二个对象数据
         * 
         * @return {boolean} 如果对象数据匹配则返回 true ， 否则返回 false
         * 
         */

        let keys1 = keys(value1),
            keys2 = keys(value2);

        if (keys1.length !== keys2.length) {

            return false;
        }

        for (let key of keys1) {

            if (!keys2.includes(key) || get(value1, key) !== get(value2, key)) {

                return false;
            }
        }

        return true;

    }

    return function(value1, value2) {


        if (!var_init_locked_1556184850041) {

            keys = include('object.keys');
            get = include('object.get');

            var_init_locked_1556184850041 = true;
        }




        return main.call(this, value1, value2);
    };

})();

exports['src::map.constructor'] = (() => {









    function main() {


        /**
         * 
         * 初始化 Map 对象
         * 
         */

        this.map = new Map();

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::map.size.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前 Map 的键值对数量
         * 
         * @return {number} 数量 
         * 
         */

        return this.map.size;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::map.find'] = (() => {









    function main(keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @param {array} keys 组合键
         * 
         * @return {object} 返回查询结果 
         * 
         */

        let me = this,
            {
                map
            } = me,
            currentKeys = map.keys(),
            {
                length
            } = keys;

        for (let groupKeys of currentKeys) {

            if (length === groupKeys.length) {

                let isMatch = true;

                for (let i = 0; i < length; i++) {

                    if (groupKeys[i] !== keys[i]) {

                        isMatch = false;

                        break;
                    }
                }

                if (isMatch) {

                    return {
                        match: true,
                        key: groupKeys
                    };
                }
            }
        }

        return {
            match: false
        };

    }

    return function(keys) {





        return main.call(this, keys);
    };

})();

exports['src::map.set'] = (() => {

    let find;

    let var_init_locked_1556184850055;

    let var_current_scope_1556184850055;



    function main(...values) {


        /**
         * 
         * 设置一个值
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...values] 包含多维键，以及相应值
         * 
         * @return {Map} 返回当前对象 
         * 
         */

        let me = this,
            {
                map
            } = me,
            {
                length
            } = values;

        if (length >= 2) {

            let keys = values.slice(0, length - 1),
                value = values[length - 1],
                {
                    match,
                    key
                } = find(keys);

            if (match) {

                map.set(key, value);

            } else {

                map.set(keys, value);
            }
        }

        return me;

    }

    return function(...values) {




        if (!var_current_scope_1556184850055 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1556184850055 = this;
        }


        return main.call(this, ...values);
    };

})();

exports['src::map.get'] = (() => {

    let find;

    let var_init_locked_1556184850057;

    let var_current_scope_1556184850057;



    function main(...keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let me = this,
            {
                map
            } = me;

        let {
            match,
            key
        } = find(keys);

        if (match) {

            return map.get(key);
        }

    }

    return function(...keys) {




        if (!var_current_scope_1556184850057 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1556184850057 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.has'] = (() => {

    let find;

    let var_init_locked_1556184850059;

    let var_current_scope_1556184850059;



    function main(...keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let {
            match
        } = find(keys);

        return match;

    }

    return function(...keys) {




        if (!var_current_scope_1556184850059 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1556184850059 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.delete'] = (() => {

    let find;

    let var_init_locked_1556184850063;

    let var_current_scope_1556184850063;



    function main(...keys) {



        /**
         * 
         * 删除指定组合键
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let me = this,
            {
                map
            } = me;

        let {
            match,
            key
        } = find(keys);

        if (match) {

            return map.delete(key);
        }

        return false;

    }

    return function(...keys) {




        if (!var_current_scope_1556184850063 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1556184850063 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.forEach'] = (() => {









    function main(fn, scope) {


        /**
         * 
         * 实现迭代
         * 
         * @param {function} fn 函数引用
         * 
         * @param {mixed} scope 函数作用域
         * 
         */

        let {
            map
        } = this;

        map.forEach(fn, scope);

    }

    return function(fn, scope) {





        return main.call(this, fn, scope);
    };

})();

exports['src::map'] = (() => {

    let constructor, get_size, method_set, method_get, method_has, method_delete, method_forEach;

    let var_init_locked_1556184850067;

    let var_class_1556184850067;

    return function() {


        if (!var_init_locked_1556184850067) {

            constructor = include('src::map.constructor');
            get_size = include('src::map.size.get');
            method_set = include('src::map.set');
            method_get = include('src::map.get');
            method_has = include('src::map.has');
            method_delete = include('src::map.delete');
            method_forEach = include('src::map.forEach');

            var_init_locked_1556184850067 = true;
        }



        if (!var_class_1556184850067) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                set(...args) {

                    return method_set.apply(this, args);

                }
                get(...args) {

                    return method_get.apply(this, args);

                }
                has(...args) {

                    return method_has.apply(this, args);

                }
                delete(...args) {

                    return method_delete.apply(this, args);

                }
                forEach(...args) {

                    return method_forEach.apply(this, args);

                }

                get size() {

                    return get_size.call(this);

                }

            }

            var_class_1556184850067 = main;
        }


        return new var_class_1556184850067();
    };

})();

exports['src::function.empty'] = (() => {









    /**
     * 
     * 返回一个空函数
     * 
     * @scoped
     * 
     */

    const emptyFn = () => {};

    function main() {

        return emptyFn;
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::function.get'] = (() => {

    let isString, isFunction, empty;

    let var_init_locked_1556184850072;





    function main(fn, scope) {

        /**
         * 
         * 获得一个函数引用
         * 
         * @import is.string
         * 
         * @import is.function
         * 
         * @import empty from function.empty
         * 
         * @param {string | function} fn 函数描述
         * 
         * @param {mixed} [scope] 函数作用域
         * 
         * @return {function} 函数引用本身 
         * 
         */

        if (isString(fn)) {

            if (scope && scope.hasOwnProperty(fn)) {

                fn = scope[fn];

            } else {

                fn = include(fn);
            }
        }

        if (isFunction(fn)) {

            if (scope) {

                return fn.bind(scope);
            }

            return fn;
        }

        return empty();

    }

    return function(fn, scope) {


        if (!var_init_locked_1556184850072) {

            isString = include('is.string');
            isFunction = include('is.function');
            empty = include('function.empty');

            var_init_locked_1556184850072 = true;
        }




        return main.call(this, fn, scope);
    };

})();

exports['src::map.set.multi'] = (() => {

    let isArray;

    let var_init_locked_1556184850076;





    function main(map, ...values) {


        /**
         * 
         * 设置复合值
         * 
         * @import is.array
         * 
         * @param {Map} map Map 对象
         * 
         * @param {array} [...values] 包含多维键，以及相应值
         * 
         * @return {Map} 返回 Map 对象引用
         * 
         */

        let {
            length
        } = values;

        if (length >= 2) {

            let key = values.slice(0, length - 1),
                value = values[length - 1],
                oldValues = map.get(...key);

            if (isArray(oldValues)) {

                if (!oldValues.includes(value)) {

                    oldValues.push(value);
                }

            } else {

                oldValues = [
                    value
                ];
            }

            map.set(...key, oldValues);
        }

        return map;



    }

    return function(map, ...values) {


        if (!var_init_locked_1556184850076) {

            isArray = include('is.array');

            var_init_locked_1556184850076 = true;
        }




        return main.call(this, map, ...values);
    };

})();

exports['src::is.number'] = (() => {

    let isType;

    let var_init_locked_1556184850078;





    function main(data) {

        /**
         * 
         * 判定数据是否为数值类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为数值类型则返回 true , 否则返回 false 
         * 
         */

        return isType(data, 'number') && isFinite(data);

    }

    return function(data) {


        if (!var_init_locked_1556184850078) {

            isType = include('is.type');

            var_init_locked_1556184850078 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::math.region.rect.constructor'] = (() => {









    function main({
        x,
        y,
        width,
        height
    }) {


        /**
         * 
         * 初始化一个矩形计算区域
         * 
         * @param {object} config 区域配置
         * 
         * @param {number} config.x 区域横坐标
         * 
         * @param {number} config.y 区域纵坐标
         * 
         * @param {number} config.width 区域宽度
         * 
         * @param {number} config.height 区域高度
         * 
         */

        let me = this;

        me.x = x;

        me.y = y;

        me.width = width;

        me.height = height;

    }

    return function({
        x,
        y,
        width,
        height
    }) {





        return main.call(this, {
            x,
            y,
            width,
            height
        });
    };

})();

exports['src::math.region.rect.getAnchorXY'] = (() => {









    function main(anchor) {


        /**
         * 
         * 计算当前区域锚点坐标
         * 
         * @param {string} [anchor = 'tl'] 锚点信息
         * 
         * @return {object} 坐标值 
         * 
         */

        let {
            x,
            y,
            width,
            height
        } = this;

        switch (anchor) {

            case 'tl':

                return {
                    x,
                    y
                };

            case 'r':

                return {
                    x: x + width,
                    y: y + height / 2
                };

            case 'l':

                return {
                    x,
                    y: y + height / 2
                };

            case 't':

                return {
                    x: x + width / 2,
                    y
                };

            case 'b':

                return {
                    x: x + width / 2,
                    y: y + height
                }
        }

    }

    return function(anchor = 'tl') {





        return main.call(this, anchor);
    };

})();

exports['src::math.region.rect'] = (() => {

    let constructor, method_getAnchorXY;

    let var_init_locked_1556184850087;

    let var_class_1556184850087;

    return function(config) {


        if (!var_init_locked_1556184850087) {

            constructor = include('src::math.region.rect.constructor');
            method_getAnchorXY = include('src::math.region.rect.getAnchorXY');

            var_init_locked_1556184850087 = true;
        }



        if (!var_class_1556184850087) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                getAnchorXY(...args) {

                    return method_getAnchorXY.apply(this, args);

                }



            }

            var_class_1556184850087 = main;
        }


        return new var_class_1556184850087(config);
    };

})();

exports['src::object.assign'] = (() => {

    let getKeys, set, get;

    let var_init_locked_1556184850090;






    /**
     * 
     * 深度合并
     * 
     * @import getKeys from object.keys
     * 
     * @import set from object.set
     * 
     * @import get from object.get
     * 
     * @param {object} dest 目标数据
     * 
     * @param {object} [...sources] 来源数据
     * 
     * @return {object} 合并后数据
     * 
     * @scoped
     * 
     */

    function assign(dest, source) {

        let keys = getKeys(source);

        for (let key of keys) {

            set(dest, key, get(source, key));
        }

    }

    function main(dest, ...sources) {

        for (let source of sources) {

            assign(dest, source);
        }

        return dest;

    }

    return function(dest, ...sources) {


        if (!var_init_locked_1556184850090) {

            getKeys = include('object.keys');
            set = include('object.set');
            get = include('object.get');

            var_init_locked_1556184850090 = true;
        }




        return main.call(this, dest, ...sources);
    };

})();

exports['src::canvas.draw.line.bezierCurve'] = (() => {

    let assign;

    let var_init_locked_1556184850094;





    function main(context, {
        points,
        ...styles
    }) {


        /**
         * 
         * 绘制贝赛尔曲线
         * 
         * @import assign from object.assign
         * 
         * @param {canvas.Context} context 画板的上下文对象
         * 
         * @param {object} [config = {}] 画线配置
         * 
         * @param {array} [config.points = []] 画线点集合
         * 
         * @param {object} [...config.styles] 画线样式
         * 
         */

        if (points.length === 8) {

            context.beginPath();

            assign(context, styles);

            context.moveTo(...points.slice(0, 2));

            context.bezierCurveTo(...points.slice(2));

            context.stroke();
        }

    }

    return function(context, {
        points = [],
        ...styles
    } = {}) {


        if (!var_init_locked_1556184850094) {

            assign = include('object.assign');

            var_init_locked_1556184850094 = true;
        }




        return main.call(this, context, {
            points,
            ...styles
        });
    };

})();

exports['src::math.degree2radian'] = (() => {









    function main(degree) {


        /**
         * 
         * 将角度转换成弧度
         * 
         * @param {number} degree 角度
         * 
         * @return {number} 弧度 
         * 
         */

        return Math.PI / 180 * degree;


    }

    return function(degree) {





        return main.call(this, degree);
    };

})();

exports['src::canvas.draw.line.arc'] = (() => {

    let assign, degree2radian;

    let var_init_locked_1556184850100;





    function main(context, {
        x,
        y,
        r,
        start,
        end,
        counterclockwise,
        ...styles
    }) {


        /**
         * 
         * 绘制弧线
         * 
         * @import assign from object.assign
         * 
         * @import degree2radian from math.degree2radian
         * 
         * @param {canvas.Context} context 画板的上下文对象
         * 
         * @param {object} [config = {}] 画线配置
         * 
         * @param {number} config.x 圆中心点横坐标
         * 
         * @param {number} config.y 圆中心点纵坐标
         * 
         * @param {number} config.r 圆的半径
         * 
         * @param {number} [config.start = -90] 圆起始角度
         * 
         * @param {number} config.end 圆终止角度
         * 
         * @param {number} [config.counterclockwise = false] 如果为 false 则为顺时针，反之为逆时针
         * 
         * @param {object} [...config.styles] 画线样式
         * 
         */

        context.beginPath();

        assign(context, styles);

        context.arc(x, y, r, degree2radian(start), degree2radian(end), counterclockwise);

        context.stroke();

    }

    return function(context, {
        x,
        y,
        r,
        start = -90,
        end,
        counterclockwise = false,
        ...styles
    } = {}) {


        if (!var_init_locked_1556184850100) {

            assign = include('object.assign');
            degree2radian = include('math.degree2radian');

            var_init_locked_1556184850100 = true;
        }




        return main.call(this, context, {
            x,
            y,
            r,
            start,
            end,
            counterclockwise,
            ...styles
        });
    };

})();

exports['src::object.proxy'] = (() => {










    /**
     * 
     * 对象代理，如果对象没有需要的方法或者属性时，则会抛出异常
     * 
     * @param {mixed} target 需要代理的对象
     * 
     * @return {object.Proxy} 代理对象引用 
     * 
     */

    function main(target) {

        return new Proxy(target);
    }

    class Proxy {

        constructor(target) {

            this.target = target;
        }

        call(method, ...args) {

            let {
                target
            } = this;

            if (method in target) {

                return target[method](...args);

            } else {

                throw new ProxyMethodNotFoundError(target, method);
            }
        }

        callIf(method, ...args) {

            let {
                target
            } = this;

            if (method in target) {

                return target[method](...args);
            }
        }

        set(name, value) {

            let {
                target
            } = this;

            if (name in target) {

                target[name] = value;

            } else {

                throw new ProxyPropertyNotFoundError(target, name, 'set');
            }
        }

        get(name) {

            let {
                target
            } = this;

            if (name in target) {

                return target[name];

            } else {

                throw new ProxyPropertyNotFoundError(target, name, 'get');
            }
        }
    }

    class ProxyMethodNotFoundError extends Error {

        constructor(target, method) {

            super(`无法访问名称为 ${method} 的方法`);

            let me = this;

            me.proxyTarget = target;

            me.proxyMethod = method;

        }
    }

    class ProxyPropertyNotFoundError extends Error {

        constructor(target, property, mode) {

            let modeMessage;

            switch (mode) {

                case 'set':

                    modeMessage = '设置';

                    break;

                case 'get':

                    modeMessage = '获取';
            }

            super(`无法${modeMessage}名称为 ${property} 的属性`);

            let me = this;

            me.proxyTarget = target;

            me.proxyProperty = property;

        }
    }

    return function(target) {





        return main.call(this, target);
    };

})();

exports['src::date.get'] = (() => {

    let isDefined;

    let var_init_locked_1556184850109;





    function main({
        year,
        month,
        day,
        hours,
        minutes,
        seconds
    }) {


        /**
         * 
         * 获得日期对象
         * 
         * @import is.defined
         * 
         * @param {object} [config = {}] 日期配置
         * 
         * @param {number} [config.year] 年份
         * 
         * @param {number} [config.month] 月份
         * 
         * @param {number} [config.day] 日
         * 
         * @param {number} [config.hours] 小时
         * 
         * @param {number} [config.minutes] 分钟
         * 
         * @param {number} [config.seconds] 秒
         * 
         * @return {Date} 日期对象 
         * 
         */

        let data = new Date();

        if (isDefined(year)) {

            data.setFullYear(year);
        }

        if (isDefined(month)) {

            data.setMonth(month - 1);
        }

        if (isDefined(day)) {

            data.setDate(day);
        }

        if (isDefined(hours)) {

            data.setHours(hours);
        }

        if (isDefined(minutes)) {

            data.setMinutes(minutes);
        }

        if (isDefined(seconds)) {

            data.setSeconds(seconds);
        }

        return data;



    }

    return function({
        year,
        month,
        day,
        hours,
        minutes,
        seconds
    } = {}) {


        if (!var_init_locked_1556184850109) {

            isDefined = include('is.defined');

            var_init_locked_1556184850109 = true;
        }




        return main.call(this, {
            year,
            month,
            day,
            hours,
            minutes,
            seconds
        });
    };

})();

exports['src::week.days'] = (() => {









    function main(startDay) {


        /**
         * 
         * 获得一周周期排列
         * 
         * @param {number} [startDay = 0] 确定起始周几
         * 
         * @return {array} 一周周期排列数字集合
         * 
         */

        let result = [
            startDay
        ];

        while (result.length < 7) {

            startDay++;

            if (startDay <= 6) {

                result.push(startDay);

            } else {

                result.push(startDay = 0);
            }
        }

        return result;


    }

    return function(startDay = 0) {





        return main.call(this, startDay);
    };

})();

exports['src::date.get.properties'] = (() => {

    let from;

    let var_init_locked_1556184850113;





    function main(date, names) {


        /**
         * 
         * 获得指定日期的属性值
         * 
         * @import from from array.from
         * 
         * @param {Date} date 日期对象
         * 
         * @param {string[]} [names] 属性名称集合
         * 
         * @return {object} 日期描述
         * 
         */

        names = from(names);

        let result = {};

        for (name of names) {

            let value;

            switch (name) {

                case 'year':

                    value = date.getFullYear();

                    break;

                case 'month':

                    value = date.getMonth() + 1;

                    break;

                case 'day':

                    value = date.getDate();
            }

            result[name] = value;
        }

        return result;

    }

    return function(date, names) {


        if (!var_init_locked_1556184850113) {

            from = include('array.from');

            var_init_locked_1556184850113 = true;
        }




        return main.call(this, date, names);
    };

})();

exports['src::is.date'] = (() => {









    function main(data) {

        /**
         * 
         * 判定数据是否为日期类型
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为日期类型则返回 true , 否则返回 false 
         * 
         */


        return Object.prototype.toString.call(data) === '[object Date]';

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::date.prev'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1556184850118;





    function main(date, step) {

        /**
         * 
         * 基于当前日历向前移一次
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date} date 基准日期
         * 
         * @param {number} [step = 1] 步长
         * 
         * @return {Date} 移过的日期 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            day,
            ...other
        } = date;

        day -= step;

        return get({
            day,
            ...other
        });

    }

    return function(date, step = 1) {


        if (!var_init_locked_1556184850118) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1556184850118 = true;
        }




        return main.call(this, date, step);
    };

})();

exports['src::date.next'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1556184850121;





    function main(date, step) {

        /**
         * 
         * 基于当前日历向后移一次
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 基准日期
         * 
         * @param {number} [step = 1] 步长
         * 
         * @return {Date} 移过的日期 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            day,
            ...other
        } = date;

        day += step;

        return get({
            day,
            ...other
        });

    }

    return function(date, step = 1) {


        if (!var_init_locked_1556184850121) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1556184850121 = true;
        }




        return main.call(this, date, step);
    };

})();

exports['src::month.date.last'] = (() => {

    let get, prev, getLastDate;

    let var_init_locked_1556184850126;





    function main(year, month) {


        /**
         * 
         * 指定月份的最后日期
         * 
         * @import get from date.get
         * 
         * @import prev from date.prev
         * 
         * @import getLastDate from ..last
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @return {Date} 日期对象 
         * 
         */

        let date = get({
            year,
            month,
            day: 31
        });

        if (month < 1 || month > 12) {

            return getLastDate(date.getFullYear(), date.getMonth() + 1);
        }

        while (date.getMonth() + 1 !== month) {

            date = prev(date);
        }

        return date;


    }

    return function(year, month) {


        if (!var_init_locked_1556184850126) {

            get = include('date.get');
            prev = include('date.prev');
            getLastDate = include('src::month.date.last');

            var_init_locked_1556184850126 = true;
        }




        return main.call(this, year, month);
    };

})();

exports['src::calendar.month'] = (() => {

    let get, getDays, prev, next, getLastDate;

    let var_init_locked_1556184850131;





    function main(year, month, {
        row,
        weekStartDay,
        day,
        ignoreNotCurrentMonthLastRow
    }) {


        /**
         * 
         * 显示以月份显示的日历数据
         * 
         * @import get from date.get
         * 
         * @import getDays from week.days
         * 
         * @import prev from date.prev
         * 
         * @import next from date.next
         * 
         * @import getLastDate from month.date.last
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @param {object} [config = {}] 日历构造配置
         * 
         * @param {number} [config.row = 6] 日历显示行数
         * 
         * @param {number} [config.weekStartDay = 1] 每周从周几进行显示
         * 
         * @param {number} [config.day] 指定日期所在周作为日历的第一周
         * 
         * @param {boolean} [config.ignoreNotCurrentMonthLastRow = true] 是否忽略不是本月的尾行
         * 
         * @return {array} 一组日历数据 
         * 
         */


        if (!day) {

            day = 1;

        }

        let lastDay = getLastDate(year, month).getDate();

        if (day > lastDay) {

            day = lastDay;
        }

        let date = get({
            year,
            month,
            day
        });

        let days = getDays(weekStartDay),
            prevCount = days.indexOf(date.getDay()),
            nextCount = 6 - prevCount,
            result = [
                date
            ];

        let currentDate = date;

        while (prevCount-- > 0) {

            result.unshift(date = prev(date));
        }

        date = currentDate;

        while (nextCount-- > 0) {

            result.push(date = next(date));
        }

        let count = (row - 1);

        while (count-- > 0) {

            date = next(date);

            if (ignoreNotCurrentMonthLastRow && date.getMonth() + 1 !== month) {

                break;
            }

            result.push(date);

            for (let i = 0; i < 6; i++) {

                result.push(date = next(date));
            }


        }

        return result;





    }

    return function(year, month, {
        row = 6,
        weekStartDay = 1,
        day,
        ignoreNotCurrentMonthLastRow = true
    } = {}) {


        if (!var_init_locked_1556184850131) {

            get = include('date.get');
            getDays = include('week.days');
            prev = include('date.prev');
            next = include('date.next');
            getLastDate = include('month.date.last');

            var_init_locked_1556184850131 = true;
        }




        return main.call(this, year, month, {
            row,
            weekStartDay,
            day,
            ignoreNotCurrentMonthLastRow
        });
    };

})();

exports['src::calendar.month.view.deselect'] = (() => {









    function main() {


        /**
         * 
         * 清除当前日历所有选定
         * 
         */

        let me = this,
            {
                proxy,
                dates,
                selectedDate
            } = me;

        if (selectedDate) {

            selectedDate.selected = false;

            proxy.call('deselect', dates.indexOf(selectedDate), selectedDate);

        }

        delete me.selectedDate;


    }

    return function() {





        return main.call(this);
    };

})();

exports['src::calendar.month.view.select'] = (() => {

    let deselect, getLastDate, get;

    let var_init_locked_1556184850139;

    let var_current_scope_1556184850139;



    function main(year, month, day) {


        /**
         * 
         * 选定
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import getLastDate from month.date.last
         * 
         * @import get from date.get.properties
         * 
         * @param {number} year 选定年份
         * 
         * @param {number} month 选定月份
         * 
         * @param {number} day 选定日期
         * 
         */

        let me = this,
            {
                proxy,
                selectedDate,
                dates
            } = me;

        deselect();

        let {
            day: lastDay
        } = get(getLastDate(year, month), [
            'day'
        ]);

        if (day > lastDay) {

            day = lastDay;
        }

        let count = -1;

        for (let date of dates) {

            let {
                year: itemYear,
                month: itemMonth,
                day: itemDay
            } = date;

            count++;

            if (itemYear === year && itemMonth === month && itemDay === day) {

                me.selectedDate = date;

                date.selected = true;

                proxy.call('select', count, date);

                break;
            }
        }







    }

    return function(year, month, day) {


        if (!var_init_locked_1556184850139) {

            getLastDate = include('month.date.last');
            get = include('date.get.properties');

            var_init_locked_1556184850139 = true;
        }



        if (!var_current_scope_1556184850139 !== this) {

            deselect = include('src::calendar.month.view.deselect').bind(this);

            var_current_scope_1556184850139 = this;
        }


        return main.call(this, year, month, day);
    };

})();

exports['src::calendar.month.view.selectMonth'] = (() => {

    let getDates, deselect, select, getProperty;

    let var_init_locked_1556184850145;

    let var_current_scope_1556184850145;



    function main(year, month) {


        /**
         * 
         * 选定月份
         * 
         * @import getDates from ......month
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import select from ..select scoped
         * 
         * @import getProperty from date.get.properties
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         */

        let me = this,
            {
                selectedDate,
                weekStartDay,
                viewConfig
            } = me;

        deselect();

        let fields = [
                'year',
                'month',
                'day'
            ],
            dates = me.dates = getDates(year, month, {
                ...viewConfig,
                weekStartDay
            }).map(date => {

                let {
                    year: itemYear,
                    month: itemMonth,
                    day
                } = getProperty(date, fields),
                    activate = year === itemYear && month === itemMonth;

                return {
                    activate,
                    year: itemYear,
                    month: itemMonth,
                    day,
                    selected: false,
                    key: date.getTime()
                };

            });

        me.year = year;

        me.month = month;

        me.proxy.call('load', year, month, dates);

        if (selectedDate) {

            let {
                day
            } = selectedDate, {
                year,
                month
            } = me;

            select(year, month, day);
        }

    }

    return function(year, month) {


        if (!var_init_locked_1556184850145) {

            getDates = include('src::calendar.month');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850145 = true;
        }



        if (!var_current_scope_1556184850145 !== this) {

            deselect = include('src::calendar.month.view.deselect').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850145 = this;
        }


        return main.call(this, year, month);
    };

})();

exports['src::calendar.month.view.constructor'] = (() => {

    let getProxy, selectMonth, select, getProperty;

    let var_init_locked_1556184850149;

    let var_current_scope_1556184850149;



    function main(target, {
        selectedDate,
        weekStartDay,
        viewConfig
    }) {


        /**
         * 
         * 构建一个月基日历
         * 
         * @import getProxy from object.proxy
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         * @import select from ..select scoped
         * 
         * @import getProperty from date.get.properties
         * 
         * @param {mixed} target 可提供日历显示的套件
         * 
         * @param {object} [config = {}] 初始化配置
         * 
         * @param {object} [config.selectedDate] 初始化选择日期
         * 
         * @param {number} [config.weekStartDay = 0] 默认从星期天进行计算
         * 
         * @param {object} [config.viewConfig = {}] 日历视图设置
         * 
         */

        let me = this;

        me.viewConfig = viewConfig;

        me.weekStartDay = weekStartDay;

        me.proxy = getProxy(target);

        me.selectedDates = [];

        me.dates = [];

        if (!selectedDate) {

            selectedDate = getProperty(new Date(), [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            year,
            month,
            day
        } = selectedDate;

        selectMonth(year, month);

        select(year, month, day);

    }

    return function(target, {
        selectedDate,
        weekStartDay = 0,
        viewConfig = {}
    } = {}) {


        if (!var_init_locked_1556184850149) {

            getProxy = include('object.proxy');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850149 = true;
        }



        if (!var_current_scope_1556184850149 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850149 = this;
        }


        return main.call(this, target, {
            selectedDate,
            weekStartDay,
            viewConfig
        });
    };

})();

exports['src::is.week.day.first'] = (() => {









    function main(date, weekStartDay) {


        /**
         * 
         * 判断指定日期是否为一周的第一天
         * 
         * @param {Date} date 校验日期
         * 
         * @param {number} [weekStartDay = 1] 确认一周是从周几算起
         *  
         * @return {boolean} 如果是第一天的话，则返回 true , 否则返回 false
         * 
         */

        return date.getDay() === weekStartDay;



    }

    return function(date, weekStartDay = 1) {





        return main.call(this, date, weekStartDay);
    };

})();

exports['src::month.prev'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1556184850154;





    function main(date) {

        /**
         * 
         * 获得指定月份的上一个月份
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 包括月份的日期对象 
         * 
         * @return {Date} 上一个月份 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month'
            ]);
        }

        let {
            month,
            ...other
        } = date;

        month--;

        return get({
            month,
            ...other
        });

    }

    return function(date) {


        if (!var_init_locked_1556184850154) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1556184850154 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectPrevMonth'] = (() => {

    let prev, getProperty, selectMonth;

    let var_init_locked_1556184850158;

    let var_current_scope_1556184850158;



    function main() {


        /**
         * 
         * 向上移动月份
         * 
         * @import prev from month.prev
         * 
         * @import getProperty from date.get.properties
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         */

        let me = this,
            {
                year,
                month
            } = me,
            {
                year: selectedYear,
                month: selectedMonth
            } = getProperty(prev({
                year,
                month
            }), [
                'year',
                'month'
            ]);

        selectMonth(selectedYear, selectedMonth);

    }

    return function() {


        if (!var_init_locked_1556184850158) {

            prev = include('month.prev');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850158 = true;
        }



        if (!var_current_scope_1556184850158 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);

            var_current_scope_1556184850158 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view.selectLeft'] = (() => {

    let isFirst, get, prevMonth, prevDate, getProperty, select;

    let var_init_locked_1556184850164;

    let var_current_scope_1556184850164;



    function main() {

        /**
         * 
         * 向左移一个格
         * 
         * @import isFirst from is.week.day.first
         * 
         * @import get from date.get
         * 
         * @import prevMonth from ..selectPrevMonth scoped
         * 
         * @import prevDate from date.prev
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            month
        } = this;

        if (selectedDate) {

            let date = get(selectedDate);

            if (isFirst(date, weekStartDay)) {

                prevMonth();

            } else {

                date = prevDate(date);

                let {
                    year: prevYearValue,
                    month: prevMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (prevMonthValue !== month) {

                    prevMonth();
                }

                select(prevYearValue, prevMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1556184850164) {

            isFirst = include('is.week.day.first');
            get = include('date.get');
            prevDate = include('date.prev');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850164 = true;
        }



        if (!var_current_scope_1556184850164 !== this) {

            prevMonth = include('src::calendar.month.view.selectPrevMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850164 = this;
        }


        return main.call(this);
    };

})();

exports['src::is.week.day.last'] = (() => {

    let getDays;

    let var_init_locked_1556184850168;





    function main(date, weekStartDay) {


        /**
         * 
         * 判断指定日期是否为一周的最后一天
         * 
         * @import getDays from week.days
         * 
         * @param {Date} date 校验日期
         * 
         * @param {number} [weekStartDay = 1] 确认一周是从周几算起
         *  
         * @return {boolean} 如果是最后一天的话，则返回 true , 否则返回 false
         * 
         */

        let days = getDays(weekStartDay);

        return date.getDay() === days[days.length - 1];

    }

    return function(date, weekStartDay = 1) {


        if (!var_init_locked_1556184850168) {

            getDays = include('week.days');

            var_init_locked_1556184850168 = true;
        }




        return main.call(this, date, weekStartDay);
    };

})();

exports['src::month.next'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1556184850170;





    function main(date) {

        /**
         * 
         * 获得指定月份的下一个月份
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 包括月份的日期对象 
         * 
         * @return {Date} 下一个月份 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month'
            ]);
        }

        let {
            month,
            ...other
        } = date;

        month++;

        return get({
            month,
            ...other
        });

    }

    return function(date) {


        if (!var_init_locked_1556184850170) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1556184850170 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectNextMonth'] = (() => {

    let next, getProperty, selectMonth;

    let var_init_locked_1556184850174;

    let var_current_scope_1556184850174;



    function main() {


        /**
         * 
         * 向下移动月份
         * 
         * @import next from month.next
         * 
         * @import getProperty from date.get.properties
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         */

        let me = this,
            {
                year,
                month
            } = me,
            {
                year: selectedYear,
                month: selectedMonth
            } = getProperty(next({
                year,
                month
            }), [
                'year',
                'month'
            ]);


        selectMonth(selectedYear, selectedMonth);

    }

    return function() {


        if (!var_init_locked_1556184850174) {

            next = include('month.next');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850174 = true;
        }



        if (!var_current_scope_1556184850174 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);

            var_current_scope_1556184850174 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view.selectRight'] = (() => {

    let isLast, get, nextMonth, nextDate, getProperty, select;

    let var_init_locked_1556184850179;

    let var_current_scope_1556184850179;



    function main() {


        /**
         * 
         * 向右移一个格日期
         * 
         * @import isLast from is.week.day.last
         * 
         * @import get from date.get
         * 
         * @import nextMonth from ..selectNextMonth scoped
         * 
         * @import nextDate from date.next
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */


        let {
            selectedDate,
            weekStartDay,
            month
        } = this;

        if (selectedDate) {

            let date = get(selectedDate);

            if (isLast(date, weekStartDay)) {

                nextMonth();

            } else {

                date = nextDate(date);

                let {
                    year: nextYearValue,
                    month: nextMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (nextMonthValue !== month) {

                    nextMonth();
                }

                select(nextYearValue, nextMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1556184850179) {

            isLast = include('is.week.day.last');
            get = include('date.get');
            nextDate = include('date.next');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850179 = true;
        }



        if (!var_current_scope_1556184850179 !== this) {

            nextMonth = include('src::calendar.month.view.selectNextMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850179 = this;
        }


        return main.call(this);
    };

})();

exports['src::month.date.first'] = (() => {

    let get;

    let var_init_locked_1556184850183;





    function main(year, month) {


        /**
         * 
         * 指定月份的第一个日期
         * 
         * @import get from date.get
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @return {Date} 日期对象 
         * 
         */

        return get({
            year,
            month,
            day: 1
        });

    }

    return function(year, month) {


        if (!var_init_locked_1556184850183) {

            get = include('date.get');

            var_init_locked_1556184850183 = true;
        }




        return main.call(this, year, month);
    };

})();

exports['src::month.dates.week.first'] = (() => {

    let getDays, getFirstDate, next;

    let var_init_locked_1556184850185;





    function main(year, month, weekStartDay) {


        /**
         * 
         * 获得指定月份的第一周的所有日期
         * 
         * @import getDays from week.days
         * 
         * @import getFirstDate from month.date.first
         * 
         * @import next from date.next
         * 
         * @param {number} year 年份 
         * 
         * @param {number} month 月份
         * 
         * @param {number} [weekStartDay = 1] 确定一周从周几进行计算
         * 
         * @return {Date[]} 一周里所有的日期 
         * 
         */

        let days = getDays(weekStartDay),
            date = getFirstDate(year, month),
            firstIndex = days.indexOf(date.getDay()),
            result = [
                date
            ];

        for (let i = firstIndex + 1; i < 7; i++) {

            result.push(date = next(date));
        }

        return result;





    }

    return function(year, month, weekStartDay = 1) {


        if (!var_init_locked_1556184850185) {

            getDays = include('week.days');
            getFirstDate = include('month.date.first');
            next = include('date.next');

            var_init_locked_1556184850185 = true;
        }




        return main.call(this, year, month, weekStartDay);
    };

})();

exports['src::array.dates.includes'] = (() => {

    let get;

    let var_init_locked_1556184850191;





    function main(dates, date, fields) {


        /**
         * 
         * 基于日历数组进行包含性检测
         * 
         * @import get from date.get.properties
         * 
         * @param {Date[]} dates 日历数组
         * 
         * @param {Date} date 校验匹配数据项
         * 
         * @param {array} [fields = ['year' , 'month' , 'day']] 校验字段项
         * 
         * @return {boolean} 如果日历数组中包含校验项则返回 true , 否则返回 false 
         * 
         */

        let {
            year,
            month,
            day
        } = get(date, fields);

        for (let date of dates) {

            let {
                year: itemYear,
                month: itemMonth,
                day: itemDay
            } = get(date, fields);

            if (itemYear === year && itemMonth === month && itemDay === day) {

                return true;
            }
        }

        return false;






    }

    return function(dates, date, fields = ['year', 'month', 'day']) {


        if (!var_init_locked_1556184850191) {

            get = include('date.get.properties');

            var_init_locked_1556184850191 = true;
        }




        return main.call(this, dates, date, fields);
    };

})();

exports['src::date.prev.week'] = (() => {

    let prev;

    let var_init_locked_1556184850194;





    function main(date) {


        /**
         * 
         * 基于当前日期的上一周的日期
         * 
         * @import prev from date.prev
         * 
         * @param {Date | object} date 基准日期
         * 
         * @return {Date} 移过的日期 
         * 
         */

        return prev(date, 7);


    }

    return function(date) {


        if (!var_init_locked_1556184850194) {

            prev = include('date.prev');

            var_init_locked_1556184850194 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectUp'] = (() => {

    let getFirstWeekDates, includes, get, prevMonth, prevDate, getProperty, select;

    let var_init_locked_1556184850197;

    let var_current_scope_1556184850197;



    function main() {


        /**
         * 
         * 向上移一格日期
         * 
         * @import getFirstWeekDates from month.dates.week.first
         * 
         * @import includes from array.dates.includes
         * 
         * @import get from date.get
         * 
         * @import prevMonth from ..selectPrevMonth scoped
         * 
         * @import prevDate from date.prev.week
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            year,
            month
        } = this;

        if (selectedDate) {

            let dates = getFirstWeekDates(year, month, weekStartDay),
                date = get(selectedDate);

            if (includes(dates, date)) {

                prevMonth();

            } else {

                date = prevDate(date);

                let {
                    year: prevYearValue,
                    month: prevMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (prevMonthValue !== month) {

                    prevMonth();
                }

                select(prevYearValue, prevMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1556184850197) {

            getFirstWeekDates = include('month.dates.week.first');
            includes = include('array.dates.includes');
            get = include('date.get');
            prevDate = include('date.prev.week');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850197 = true;
        }



        if (!var_current_scope_1556184850197 !== this) {

            prevMonth = include('src::calendar.month.view.selectPrevMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850197 = this;
        }


        return main.call(this);
    };

})();

exports['src::month.dates.week.last'] = (() => {

    let getDays, getLastDate, prev;

    let var_init_locked_1556184850203;





    function main(year, month, weekStartDay) {


        /**
         * 
         * 获得指定月份的最后一周的所有日期
         * 
         * @import getDays from week.days
         * 
         * @import getLastDate from month.date.last
         * 
         * @import prev from date.prev
         * 
         * @param {number} year 年份 
         * 
         * @param {number} month 月份
         * 
         * @param {number} [weekStartDay = 1] 确定一周从周几进行计算
         * 
         * @return {Date[]} 一周里所有的日期 
         * 
         */

        let days = getDays(weekStartDay),
            date = getLastDate(year, month),
            lastIndex = days.indexOf(date.getDay()),
            result = [
                date
            ];

        for (let i = lastIndex - 1; i >= 0; i--) {

            result.push(date = prev(date));
        }

        return result;

    }

    return function(year, month, weekStartDay = 1) {


        if (!var_init_locked_1556184850203) {

            getDays = include('week.days');
            getLastDate = include('month.date.last');
            prev = include('date.prev');

            var_init_locked_1556184850203 = true;
        }




        return main.call(this, year, month, weekStartDay);
    };

})();

exports['src::date.next.week'] = (() => {

    let next;

    let var_init_locked_1556184850206;





    function main(date) {


        /**
         * 
         * 基于当前日期的下一周的日期
         * 
         * @import next from date.next
         * 
         * @param {Date | object} date 基准日期
         * 
         * @return {Date} 移过的日期 
         * 
         */

        return next(date, 7);



    }

    return function(date) {


        if (!var_init_locked_1556184850206) {

            next = include('date.next');

            var_init_locked_1556184850206 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectDown'] = (() => {

    let getLastWeekDates, includes, get, nextMonth, nextDate, getProperty, select;

    let var_init_locked_1556184850210;

    let var_current_scope_1556184850210;



    function main() {


        /**
         * 
         * 向下移一格日期
         * 
         * @import getLastWeekDates from month.dates.week.last
         * 
         * @import includes from array.dates.includes
         * 
         * @import get from date.get
         * 
         * @import nextMonth from ..selectNextMonth scoped
         * 
         * @import nextDate from date.next.week
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            year,
            month
        } = this;

        if (selectedDate) {

            let dates = getLastWeekDates(year, month, weekStartDay),
                date = get(selectedDate);

            if (includes(dates, date)) {

                nextMonth();

            } else {

                date = nextDate(date);

                let {
                    year: nextYearValue,
                    month: nextMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (nextMonthValue !== month) {

                    nextMonth();
                }

                select(nextYearValue, nextMonthValue, day);
            }
        }



    }

    return function() {


        if (!var_init_locked_1556184850210) {

            getLastWeekDates = include('month.dates.week.last');
            includes = include('array.dates.includes');
            get = include('date.get');
            nextDate = include('date.next.week');
            getProperty = include('date.get.properties');

            var_init_locked_1556184850210 = true;
        }



        if (!var_current_scope_1556184850210 !== this) {

            nextMonth = include('src::calendar.month.view.selectNextMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1556184850210 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view'] = (() => {

    let constructor, method_select, method_selectLeft, method_selectRight, method_selectUp, method_selectDown, method_selectMonth, method_selectNextMonth, method_selectPrevMonth, method_deselect;

    let var_init_locked_1556184850217;

    let var_class_1556184850217;

    return function(target, config) {


        if (!var_init_locked_1556184850217) {

            constructor = include('src::calendar.month.view.constructor');
            method_select = include('src::calendar.month.view.select');
            method_selectLeft = include('src::calendar.month.view.selectLeft');
            method_selectRight = include('src::calendar.month.view.selectRight');
            method_selectUp = include('src::calendar.month.view.selectUp');
            method_selectDown = include('src::calendar.month.view.selectDown');
            method_selectMonth = include('src::calendar.month.view.selectMonth');
            method_selectNextMonth = include('src::calendar.month.view.selectNextMonth');
            method_selectPrevMonth = include('src::calendar.month.view.selectPrevMonth');
            method_deselect = include('src::calendar.month.view.deselect');

            var_init_locked_1556184850217 = true;
        }



        if (!var_class_1556184850217) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                select(...args) {

                    return method_select.apply(this, args);

                }
                selectLeft(...args) {

                    return method_selectLeft.apply(this, args);

                }
                selectRight(...args) {

                    return method_selectRight.apply(this, args);

                }
                selectUp(...args) {

                    return method_selectUp.apply(this, args);

                }
                selectDown(...args) {

                    return method_selectDown.apply(this, args);

                }
                selectMonth(...args) {

                    return method_selectMonth.apply(this, args);

                }
                selectNextMonth(...args) {

                    return method_selectNextMonth.apply(this, args);

                }
                selectPrevMonth(...args) {

                    return method_selectPrevMonth.apply(this, args);

                }
                deselect(...args) {

                    return method_deselect.apply(this, args);

                }



            }

            var_class_1556184850217 = main;
        }


        return new var_class_1556184850217(target, config);
    };

})();

exports['src::browser.support.pointer'] = (() => {







    let var_once_value_1556184850224;

    function main() {


        /**
         * 
         * 判断当前浏览器是否支持点触
         * 
         * @return {boolean} 如果是支持点触则返回 true ，否则返回 false 
         * 
         * @once
         * 
         */

        return window.hasOwnProperty('onpointerdown');

    }

    return function() {






        if (var_once_value_1556184850224) {

            return var_once_value_1556184850224;

        }
        return var_once_value_1556184850224 = main.call(this);

    };

})();

exports['src::browser.support.touch'] = (() => {







    let var_once_value_1556184850226;

    function main() {


        /**
         * 
         * 判断当前浏览器是否支持触摸
         * 
         * @return {boolean} 如果是支持触摸则返回 true ，否则返回 false 
         * 
         * @once
         * 
         */

        return window.hasOwnProperty('ontouchstart');

    }

    return function() {






        if (var_once_value_1556184850226) {

            return var_once_value_1556184850226;

        }
        return var_once_value_1556184850226 = main.call(this);

    };

})();

exports['src::browser.event.name'] = (() => {

    let isPointer, isTouch;

    let var_init_locked_1556184850229;






    /**
     * 
     * 获得事件的兼容名称
     * 
     * @import isPointer from browser.support.pointer
     * 
     * @import isTouch from browser.support.touch
     * 
     * @param {string} name 事件名称
     * 
     * @return {string} 对应事件的兼容名称 
     * 
     */

    function get_event_name(name) {

        switch (name) {

            case 'start':

                if (isPointer()) {

                    return 'pointerdown';

                } else if (isTouch()) {

                    return 'touchstart';
                }

                return 'mousedown';

            case 'move':

                if (isPointer()) {

                    return 'pointermove';

                } else if (isTouch()) {

                    return 'touchmove';
                }

                return 'mousemove';

            case 'end':

                if (isPointer()) {

                    return 'pointerup';

                } else if (isTouch()) {

                    return 'touchend';
                }

                return 'mouseup';
        }
    }

    function main(name) {

        switch (name) {

            case 'pointerdown':
            case 'touchstart':
            case 'mousedown':

                return get_event_name('start');

            case 'pointermove':
            case 'touchmove':
            case 'mousemove':

                return get_event_name('move');

            case 'pointerup':
            case 'touchend':
            case 'mousedup':

                return get_event_name('end');
        }

        return name;
    }



    return function(name) {


        if (!var_init_locked_1556184850229) {

            isPointer = include('browser.support.pointer');
            isTouch = include('browser.support.touch');

            var_init_locked_1556184850229 = true;
        }




        return main.call(this, name);
    };

})();

exports['src::browser.global.listener.map'] = (() => {

    let map;

    let var_init_locked_1556184850231;



    let var_once_value_1556184850231;

    function main() {


        /**
         * 
         * 维护全局事件监听对象
         * 
         * @import map value
         * 
         * @return {Map} 集合对象 
         * 
         * @once
         * 
         */

        return map;

    }

    return function() {


        if (!var_init_locked_1556184850231) {

            map = include('map')();

            var_init_locked_1556184850231 = true;
        }





        if (var_once_value_1556184850231) {

            return var_once_value_1556184850231;

        }
        return var_once_value_1556184850231 = main.call(this);

    };

})();

exports['src::browser.selector.is'] = (() => {









    function main(el, selector) {


        /**
         * 
         * 判断元素是否匹配选择器
         * 
         * @param {HTMLElement} el 元素
         * 
         * @param {string} selector 选择器字符串
         * 
         * @return {boolean} 如果元素匹配选择器则返回 true , 否则返回 false 
         * 
         */

        let {
            ownerDocument
        } = el;

        let els = Array.from(ownerDocument.querySelectorAll(selector));

        return els.includes(el);

    }

    return function(el, selector) {





        return main.call(this, el, selector);
    };

})();

exports['src::browser.selector.parent'] = (() => {

    let is;

    let var_init_locked_1556184850237;





    function main(el, selector) {


        /**
         * 
         * 判断元素及其元素父祖级元素是否匹配选择器
         * 
         * @import is from ..is
         * 
         * @param {HTMLElement} el 元素
         * 
         * @param {string} selector 选择器
         * 
         * @return {boolean} 如果匹配则返回 true , 否则返回 false 
         * 
         */

        while (el) {

            if (is(el, selector)) {

                return el;
            }

            el = el.parentElement;
        }

    }

    return function(el, selector) {


        if (!var_init_locked_1556184850237) {

            is = include('src::browser.selector.is');

            var_init_locked_1556184850237 = true;
        }




        return main.call(this, el, selector);
    };

})();

exports['src::browser.global.listener.add'] = (() => {

    let getEventName, getMap, is;

    let var_init_locked_1556184850239;





    function main(event, fn, selector) {


        /**
         * 
         * 监听全局事件
         * 
         * @import getEventName from browser.event.name
         * 
         * @import getMap from ..map
         * 
         * @import is from browser.selector.parent
         * 
         * @param {string} event 目标监听事件
         * 
         * @param {function} fn 目标监听回调
         * 
         * @param {string} selector 选择器
         * 
         * @return {mixed} 返回说明 
         * 
         */

        event = getEventName(event);

        let map = getMap(),
            listenerFn = e => {

                let {
                    target
                } = e;

                if (selector) {

                    if (is(target, selector)) {

                        fn(e);
                    }

                } else {

                    fn(e);
                }
            };

        map.set(event, fn, selector, listenerFn);

        document.addEventListener(event, listenerFn);




    }

    return function(event, fn, selector) {


        if (!var_init_locked_1556184850239) {

            getEventName = include('browser.event.name');
            getMap = include('src::browser.global.listener.map');
            is = include('browser.selector.parent');

            var_init_locked_1556184850239 = true;
        }




        return main.call(this, event, fn, selector);
    };

})();

exports['src::browser.global.listener.remove'] = (() => {

    let getEventName, getMap;

    let var_init_locked_1556184850242;





    function main(event, fn, selector) {


        /**
         * 
         * 去除监听全局事件
         * 
         * @import getEventName from browser.event.name
         * 
         * @import getMap from ..map
         * 
         * @param {string} event 目标监听事件
         * 
         * @param {function} fn 目标监听回调
         * 
         * @param {string} selector 选择器
         * 
         * @return {mixed} 返回说明 
         * 
         */

        event = getEventName(event);

        let map = getMap(),
            listenerFn = map.get(event, fn, selector);

        if (listenerFn) {

            document.removeEventListener(event, listenerFn);
        }

    }

    return function(event, fn, selector) {


        if (!var_init_locked_1556184850242) {

            getEventName = include('browser.event.name');
            getMap = include('src::browser.global.listener.map');

            var_init_locked_1556184850242 = true;
        }




        return main.call(this, event, fn, selector);
    };

})();

exports['src::browser.event.key'] = (() => {










    /**
     * 
     * 得到对应代码的值键值 
     * 
     * @param {Event} event 键事件对象
     * 
     * @return {mixed} 键值 
     * 
     */

    const KEY_CODES = {
            39: 'DIRECTION::RIGHT',
            37: 'DIRECTION::LEFT',
            38: 'DIRECTION::UP',
            40: 'DIRECTION::DOWN',
            13: 'ENTER',
            46: 'DELETE',
            9: 'TAB',
            107: 'ADDITION'
        },
        WITH_SHIFT_KEY_CODES = {
            187: 'ADDITION'
        };

    function main({
        shiftKey,
        keyCode
    }) {

        if (shiftKey) {

            return WITH_SHIFT_KEY_CODES[keyCode];
        }

        return KEY_CODES[keyCode];
    }

    return function(event) {





        return main.call(this, event);
    };

})();

exports['src::os.name'] = (() => {







    let var_once_value_1556184850248;

    function main() {

        /**
         * 
         * 返回当前操作系统的名称
         * 
         * @once
         * 
         * @return {string} 操作系统的名称
         * 
         */

        const NAMES = {
            iphone: 'iOS',
            android: 'Android',
            mac: 'MacOS',
            win: 'Windows',
            linux: 'Linux',
            other: 'Other'
        };

        let userAgent = navigator.userAgent.toLowerCase(),
            name = NAMES[(userAgent.match(/mac|win|linux/) || ['other'])[0]];

        switch (name) {

            case 'MacOS':
            case 'Linux':

                {

                    let name = NAMES[(userAgent.match(/iphone|android/) || ['other'])[0]];

                    if (name !== 'Other') {

                        return name;
                    }
                }
        }

        return name;

    }

    return function() {






        if (var_once_value_1556184850248) {

            return var_once_value_1556184850248;

        }
        return var_once_value_1556184850248 = main.call(this);

    };

})();

exports['src::data.node.relationship.constructor'] = (() => {









    function main(node, {
        parentNodeField,
        childNodesField,
        relationshipField
    }) {


        /**
         * 
         * 构建节点方向识别器
         * 
         * @param {mixed} node 节点引用
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {string} [config.parentNodeField = 'parentNode'] 父节点引用字段名称
         * 
         * @param {string} [config.childNodesField = 'childNodes'] 子节点集合引用字段名称 
         * 
         * @param {string} [config.relationshipField = 'relationship'] 描述节点关系字段名称
         * 
         */

        let me = this;

        me.node = node;

        me.parentNodeField = parentNodeField;

        me.childNodesField = childNodesField;

        node[me.relationshipField = relationshipField] = me;

    }

    return function(node, {
        parentNodeField = 'parentNode',
        childNodesField = 'childNodes',
        relationshipField = 'relationship'
    } = {}) {





        return main.call(this, node, {
            parentNodeField,
            childNodesField,
            relationshipField
        });
    };

})();

exports['src::data.node.relationship.node.parent'] = (() => {









    function main() {


        /**
         * 
         * 返回父节点
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        let {
            node,
            parentNodeField,
            relationshipField
        } = this,
        parentNode = node[parentNodeField];

        if (parentNode) {

            return parentNode[relationshipField];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.child'] = (() => {

    let isString, isNumber;

    let var_init_locked_1556184850254;





    function main(index) {

        /**
         * 
         * 快速子节点定位器
         * 
         * @import is.string
         * 
         * @import is.number
         * 
         * @param {mixed} index 子节点定位索引
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        let {
            node,
            parentNodeField,
            childNodesField,
            relationshipField
        } = this,
        result;

        if (isString(index)) {

            let childNodes = node[childNodesField];

            switch (index) {

                case 'first':

                    result = childNodes[0];

                    break;

                case 'last':

                    result = childNodes[childNodes.length - 1];
            }

        } else if (isNumber(index)) {

            let parentNode = node[parentNodeField];

            if (parentNode) {

                let childNodes = parentNode[childNodesField];

                result = childNodes[childNodes.indexOf(node) + index];
            }
        }

        if (result) {

            return result[relationshipField];
        }

    }

    return function(index) {


        if (!var_init_locked_1556184850254) {

            isString = include('is.string');
            isNumber = include('is.number');

            var_init_locked_1556184850254 = true;
        }




        return main.call(this, index);
    };

})();

exports['src::data.node.relationship.node.next'] = (() => {

    let getNode;

    let var_init_locked_1556184850256;

    let var_current_scope_1556184850256;



    function main() {


        /**
         * 
         * 返回下一个兄弟节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode(1);

    }

    return function() {




        if (!var_current_scope_1556184850256 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1556184850256 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.first'] = (() => {

    let getNode;

    let var_init_locked_1556184850258;

    let var_current_scope_1556184850258;



    function main() {


        /**
         * 
         * 返回第一个子节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('first');

    }

    return function() {




        if (!var_current_scope_1556184850258 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1556184850258 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.last'] = (() => {

    let getNode;

    let var_init_locked_1556184850260;

    let var_current_scope_1556184850260;



    function main() {


        /**
         * 
         * 返回最后一个子节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('last');

    }

    return function() {




        if (!var_current_scope_1556184850260 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1556184850260 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.previos'] = (() => {

    let getNode;

    let var_init_locked_1556184850262;

    let var_current_scope_1556184850262;



    function main() {


        /**
         * 
         * 返回下一个兄弟节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode(-1);

    }

    return function() {




        if (!var_current_scope_1556184850262 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1556184850262 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.iterate'] = (() => {









    function main(field, floor) {


        /**
         * 
         * 获得指定层数节点数据,如果层数不足，则返回最后一层的节点数据
         * 
         * @param {string} field 节点字段
         * 
         * @param {number} [floor= 1] 迭代次数
         * 
         * @return {data.node.Relationship} 节点关系对象 
         * 
         */


        let node = this;

        for (let i = 1; i <= floor; i++) {

            let tempNode = node[field];

            if (tempNode) {

                node = tempNode;

            } else {

                return node;
            }
        }

        return node;

    }

    return function(field, floor = 1) {





        return main.call(this, field, floor);
    };

})();

exports['src::data.node.relationship.node.first.get'] = (() => {

    let getNode;

    let var_init_locked_1556184850266;

    let var_current_scope_1556184850266;



    function main(count) {


        /**
         * 
         * 返回指定层数的第一个节点
         * 
         * @import getNode from ....iterate scoped
         * 
         * @param {number} [count] 迭代次数
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('firstNode', count);

    }

    return function(count) {




        if (!var_current_scope_1556184850266 !== this) {

            getNode = include('src::data.node.relationship.node.iterate').bind(this);

            var_current_scope_1556184850266 = this;
        }


        return main.call(this, count);
    };

})();

exports['src::data.node.relationship.node.last.get'] = (() => {

    let getNode;

    let var_init_locked_1556184850268;

    let var_current_scope_1556184850268;



    function main(count) {


        /**
         * 
         * 返回指定层数的第一个节点
         * 
         * @import getNode from ....iterate scoped
         * 
         * @param {number} [count] 迭代次数
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('lastNode', count);

    }

    return function(count) {




        if (!var_current_scope_1556184850268 !== this) {

            getNode = include('src::data.node.relationship.node.iterate').bind(this);

            var_current_scope_1556184850268 = this;
        }


        return main.call(this, count);
    };

})();

exports['src::data.node.relationship.up'] = (() => {









    function main() {


        /**
         * 
         * 返回上面的节点引用
         * 
         * @return {data.node.Relationship} 上面节点 
         * 
         */

        let node = this,
            {
                previousNode
            } = node;

        if (previousNode) {

            return previousNode;
        }

        let count = 0;

        while (node = node.parentNode) {

            count++;

            let {
                previousNode
            } = node;

            if (previousNode) {

                return previousNode.getLastNode(count);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.down'] = (() => {









    function main() {


        /**
         * 
         * 返回下面的节点引用
         * 
         * @return {mixed} 下面节点 
         * 
         */

        let node = this,
            {
                nextNode
            } = node;

        if (nextNode) {

            return nextNode;
        }

        let count = 0;

        while (node = node.parentNode) {

            count++;

            let {
                nextNode
            } = node;

            if (nextNode) {

                return nextNode.getFirstNode(count);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.left'] = (() => {









    function main() {


        /**
         * 
         * 返回左面的节点引用
         * 
         * @return {data.node.Relationship} 左面节点 
         * 
         */

        let node = this,
            {
                parentNode
            } = node;

        if (parentNode) {

            return parentNode;
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.right'] = (() => {









    function main() {


        /**
         * 
         * 返回右面的节点引用
         * 
         * @return {data.node.Relationship} 右面节点 
         * 
         */

        let node = this,
            {
                firstNode
            } = node;

        if (firstNode) {

            return firstNode;
        }

        let previousCount = 0,
            previousNode,
            lastChildNode,
            basePreviousNode = node;

        while (previousNode = basePreviousNode.previousNode) {

            previousCount++;

            if (lastChildNode = previousNode.lastNode) {

                break;

            } else {

                basePreviousNode = previousNode;
            }
        }

        if (!lastChildNode) {

            let upNode;

            while (upNode = basePreviousNode.up()) {

                previousCount++;

                if (lastChildNode = upNode.lastNode) {

                    break;

                } else {

                    basePreviousNode = upNode;
                }
            }
        }

        let nextount = 0,
            nextNode,
            firstChildNode,
            baseNextNode = node;

        while (nextNode = baseNextNode.nextNode) {

            nextount++;

            if (firstChildNode = nextNode.firstNode) {

                break;

            } else {

                baseNextNode = nextNode;
            }
        }

        if (!firstChildNode) {

            let downNode;

            while (downNode = baseNextNode.down()) {

                nextount++;

                if (firstChildNode = downNode.firstNode) {

                    break;

                } else {

                    baseNextNode = downNode;
                }
            }
        }

        let result;

        if (firstChildNode && lastChildNode) {

            if (previousCount >= nextount) {

                result = lastChildNode;

            } else {

                result = firstChildNode;
            }

        } else {

            result = lastChildNode || firstChildNode;
        }



        return result;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship'] = (() => {

    let constructor, get_parentNode, get_nextNode, get_firstNode, get_lastNode, get_previousNode, method_getFirstNode, method_getLastNode, method_up, method_down, method_left, method_right;

    let var_init_locked_1556184850278;

    let var_class_1556184850278;

    return function(node, config) {


        if (!var_init_locked_1556184850278) {

            constructor = include('src::data.node.relationship.constructor');
            get_parentNode = include('src::data.node.relationship.node.parent');
            get_nextNode = include('src::data.node.relationship.node.next');
            get_firstNode = include('src::data.node.relationship.node.first');
            get_lastNode = include('src::data.node.relationship.node.last');
            get_previousNode = include('src::data.node.relationship.node.previos');
            method_getFirstNode = include('src::data.node.relationship.node.first.get');
            method_getLastNode = include('src::data.node.relationship.node.last.get');
            method_up = include('src::data.node.relationship.up');
            method_down = include('src::data.node.relationship.down');
            method_left = include('src::data.node.relationship.left');
            method_right = include('src::data.node.relationship.right');

            var_init_locked_1556184850278 = true;
        }



        if (!var_class_1556184850278) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                getFirstNode(...args) {

                    return method_getFirstNode.apply(this, args);

                }
                getLastNode(...args) {

                    return method_getLastNode.apply(this, args);

                }
                up(...args) {

                    return method_up.apply(this, args);

                }
                down(...args) {

                    return method_down.apply(this, args);

                }
                left(...args) {

                    return method_left.apply(this, args);

                }
                right(...args) {

                    return method_right.apply(this, args);

                }

                get parentNode() {

                    return get_parentNode.call(this);

                }
                get nextNode() {

                    return get_nextNode.call(this);

                }
                get firstNode() {

                    return get_firstNode.call(this);

                }
                get lastNode() {

                    return get_lastNode.call(this);

                }
                get previousNode() {

                    return get_previousNode.call(this);

                }

            }

            var_class_1556184850278 = main;
        }


        return new var_class_1556184850278(node, config);
    };

})();

exports['src::tree.node.constructor'] = (() => {

    let createRelationship, generate;

    let var_init_locked_1556184850283;





    function main(config) {


        /**
         * 
         * 构建一个树型节点
         * 
         * @import createRelationship from data.node.relationship
         * 
         * 
         * @import generate from id.generate
         * 
         * @param {object} config 节点配置
         * 
         */

        let me = this;

        Object.assign(me, config);

        me.id = generate('tree-node-');

        me.$children = [];

        createRelationship(me, {
            childNodesField: 'children'
        });

    }

    return function(config) {


        if (!var_init_locked_1556184850283) {

            createRelationship = include('data.node.relationship');
            generate = include('id.generate');

            var_init_locked_1556184850283 = true;
        }




        return main.call(this, config);
    };

})();

exports['src::array.insert'] = (() => {









    function main(data, index, ...items) {


        /**
         * 
         * 在指定下标处插入项
         * 
         * @param {array} data 数组
         * 
         * @param {number} index 数组下标
         * 
         * @param {mixed} [...items] 项
         * 
         */

        data.splice(index, 0, ...items);

    }

    return function(data, index, ...items) {





        return main.call(this, data, index, ...items);
    };

})();

exports['src::data.node.list.constructor'] = (() => {

    let insert;

    let var_init_locked_1556184850290;






    /**
     * 
     * 构建节点的一维列表
     * 
     * @import insert from array.insert
     * 
     * @param {mixed} node 节点
     * 
     * @param {object} [config = {}] 配置
     * 
     * @param {string} [config.childNodesField = 'childNodes'] 子节点集合引用字段名称 
     * 
     */

    function initNodes(nodes, nodeMap, childNodesField, node) {

        let childNodes = node[childNodesField],
            index = nodes.indexOf(node),
            children = [];

        for (let childNode of childNodes) {

            insert(nodes, index + 1, childNode);

            children.push(childNode);

            index = initNodes(nodes, nodeMap, childNodesField, childNode);
        }

        nodeMap.set(node, children);

        return index;
    }

    function main(node, {
        childNodesField
    }) {

        let me = this,
            nodes = [
                node
            ],
            nodeMap = new Map();

        initNodes(nodes, nodeMap, childNodesField, node);

        me.nodes = nodes;

        me.nodeMap = nodeMap;
    }



    return function(node, {
        childNodesField = 'childNodes'
    } = {}) {


        if (!var_init_locked_1556184850290) {

            insert = include('array.insert');

            var_init_locked_1556184850290 = true;
        }




        return main.call(this, node, {
            childNodesField
        });
    };

})();

exports['src::data.node.list.node.start'] = (() => {









    function main() {


        /**
         * 
         * 获取当前节点列表的第一个节点
         * 
         * @return {mixed} 节点 
         * 
         */

        let {
            nodes
        } = this;

        return nodes[0];

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.list.node.end'] = (() => {









    function main() {


        /**
         * 
         * 获取当前节点列表的最后一个节点
         * 
         * @return {mixed} 节点 
         * 
         */

        let {
            nodes
        } = this;

        return nodes[nodes.length - 1];

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.list.nodes.get'] = (() => {









    function main(startNode, endNode) {


        /**
         * 
         * 获取指定两个节点之间的所有节点集合
         * 
         * @param {mixed} startNode 开始节点
         * 
         * @param {mixed} endNode 结束节点
         * 
         * @return {array} 节点集合 
         * 
         */

        let {
            nodes
        } = this,
        startIndex = nodes.indexOf(startNode),
            endIndex = nodes.indexOf(endNode);

        if (startIndex !== -1 && endIndex !== -1) {

            return nodes.slice(startIndex, endIndex + 1);
        }

        return [];

    }

    return function(startNode, endNode) {





        return main.call(this, startNode, endNode);
    };

})();

exports['src::data.node.list.node.deepest.last'] = (() => {

    let getLastNode;

    let var_init_locked_1556184850297;

    let var_current_scope_1556184850297;



    function main(node) {


        /**
         * 
         * 获取指定节点最底部的叶子节点
         * 
         * @import getLastNode from ..last scoped
         * 
         * @param {mixed} node 节点
         * 
         * @return {mixed} 叶子节点 
         * 
         */

        let {
            nodeMap
        } = this,
        childNodes = nodeMap.get(node), {
            length
        } = childNodes;

        if (length) {

            let lastNode = childNodes[length - 1],
                deepNode = getLastNode(lastNode);

            if (deepNode) {

                return deepNode;
            }

            return lastNode;
        }


    }

    return function(node) {




        if (!var_current_scope_1556184850297 !== this) {

            getLastNode = include('src::data.node.list.node.deepest.last').bind(this);

            var_current_scope_1556184850297 = this;
        }


        return main.call(this, node);
    };

})();

exports['src::data.node.list.join'] = (() => {









    function main(list) {


        /**
         * 
         * 合并节点列表
         * 
         * @param {data.node.List} list 节点列表
         * 
         * 
         */

        let {
            startNode,
            endNode
        } = list, {
            nodes,
            nodeMap
        } = this;

        if (!nodes.includes(startNode) && !nodes.includes(endNode)) {

            list.nodeMap.forEach((value, key) => nodeMap.set(key, value));

        } else if (!(nodes.includes(startNode) && nodes.includes(endNode))) {

            throw new Error('无法合并交差节点集合');
        }

    }

    return function(list) {





        return main.call(this, list);
    };

})();

exports['src::data.node.list.append'] = (() => {

    let insert, getLastNode, join;

    let var_init_locked_1556184850301;

    let var_current_scope_1556184850301;



    function main(parentNode, list) {


        /**
         * 
         * 添加节点列表
         * 
         * @import insert from array.insert
         * 
         * @import getLastNode from .node.deepest.last scoped
         * 
         * @import join from ..join scoped
         * 
         * @param {mixed} parentNode 父节点
         * 
         * @param {data.node.List} list 节点列表
         * 
         * @return {boolean} 添加成功后则返回 true , 否则返回 false
         * 
         */

        let me = this;

        let {
            startNode,
            endNode
        } = list, {
            nodes,
            nodeMap
        } = me;

        if (!nodes.includes(startNode) && !nodes.includes(endNode)) {

            list.nodeMap.forEach((value, key) => nodeMap.set(key, value));

            if (nodes.includes(parentNode)) {

                let lastNode = getLastNode(parentNode),
                    index;

                if (lastNode) {

                    index = nodes.indexOf(lastNode);

                } else {

                    index = nodes.indexOf(parentNode);
                }

                insert(nodes, index + 1, ...list.nodes);

                nodeMap.get(parentNode).push(startNode);

                return true;
            }
        }

        return false;

    }

    return function(parentNode, list) {


        if (!var_init_locked_1556184850301) {

            insert = include('array.insert');

            var_init_locked_1556184850301 = true;
        }



        if (!var_current_scope_1556184850301 !== this) {

            getLastNode = include('src::data.node.list.node.deepest.last').bind(this);
            join = include('src::data.node.list.join').bind(this);

            var_current_scope_1556184850301 = this;
        }


        return main.call(this, parentNode, list);
    };

})();

exports['src::data.node.list.remove'] = (() => {

    let remove;

    let var_init_locked_1556184850303;





    function main(parentNode, list) {


        /**
         * 
         * 删除节点列表
         * 
         * @import remove from array.remove
         * 
         * @param {mixed} parentNode 父节点
         * 
         * @param {data.node.List} list 节点列表
         * 
         * @return {boolean} 添加成功后则返回 true , 否则返回 false
         * 
         */

        let me = this;

        let {
            nodes,
            nodeMap
        } = this;

        if (nodes.includes(parentNode)) {

            let {
                startNode,
                endNode
            } = list;

            if (remove(nodeMap.get(parentNode), startNode)) {

                let startIndex = nodes.indexOf(startNode),
                    endIndex = nodes.indexOf(endNode);

                if (endIndex === -1) {

                    throw new Error('无法拆分交差节点集合');
                }

                nodes.splice(startIndex, endIndex - startIndex + 1);

                return true;
            }
        }

        return false;

    }

    return function(parentNode, list) {


        if (!var_init_locked_1556184850303) {

            remove = include('array.remove');

            var_init_locked_1556184850303 = true;
        }




        return main.call(this, parentNode, list);
    };

})();

exports['src::array.insert.before'] = (() => {









    function main(data, insertItem, existItem) {


        /**
         * 
         * 在数组中指定项之前添加
         * 
         * @param {array} data 目标数组
         * 
         * @param {mixed} insertItem 需要添加的项
         * 
         * @param {mixed} existItem 指定项
         * 
         */

        let index = data.indexOf(existItem);

        if (index !== -1) {

            data.splice(index, 0, insertItem);
        }

    }

    return function(data, insertItem, existItem) {





        return main.call(this, data, insertItem, existItem);
    };

})();

exports['src::array.insert.after'] = (() => {









    function main(data, insertItem, existItem) {


        /**
         * 
         * 在数组中指定项之后添加
         * 
         * @param {array} data 目标数组
         * 
         * @param {mixed} insertItem 需要添加的项
         * 
         * @param {mixed} existItem 指定项
         * 
         */

        let index = data.indexOf(existItem);

        if (index !== -1) {

            data.splice(index + 1, 0, insertItem);
        }

    }

    return function(data, insertItem, existItem) {





        return main.call(this, data, insertItem, existItem);
    };

})();

exports['src::data.node.list.insert'] = (() => {

    let getLastNode, insert, arrayInsertBefore, arrayInsertAfter, join;

    let var_init_locked_1556184850310;

    let var_current_scope_1556184850310;



    function main(parentNode, list, baseChildNode, position) {


        /**
         * 
         * 插入节点列表
         * 
         * @import getLastNode from .node.deepest.last scoped
         * 
         * @import insert from array.insert
         * 
         * @import array.insert.before
         * 
         * @import array.insert.after
         * 
         * @import join from ..join scoped
         * 
         * @param {mixed} parentNode 父节点
         * 
         * @param {data.node.List} list 子节点
         * 
         * @param {mixed} baseChildNode 基准子节点
         * 
         * @param {string} position = 'before' 插入在基准子节点的前后位置
         * 
         * @return {boolean} 插入成功后则返回 true , 否则返回 false
         * 
         */
        let me = this;

        join(list);

        let {
            nodes,
            nodeMap
        } = this,
        childNodes = nodeMap.get(parentNode);

        if (nodes.includes(parentNode) && nodes.includes(baseChildNode) && childNodes.includes(baseChildNode)) {

            let index;

            switch (position) {

                case 'before':

                    index = nodes.indexOf(baseChildNode);

                case 'after':

                    let lastNode = getLastNode(baseChildNode);

                    if (lastNode) {

                        index = nodes.indexOf(lastNode) + 1;

                    } else {

                        index = nodes.indexOf(baseChildNode) + 1;
                    }
            }

            let {
                startNode,
                endNode
            } = list;

            insert(nodes, index, ...me.getNodes(startNode, endNode));

            include(`array.insert.${position}`)(nodeMap.get(parentNode), startNode, baseChildNode);

            return true;
        }

        return false;

    }

    return function(parentNode, list, baseChildNode, position) {


        if (!var_init_locked_1556184850310) {

            insert = include('array.insert');
            arrayInsertBefore = include('array.insert.before');
            arrayInsertAfter = include('array.insert.after');

            var_init_locked_1556184850310 = true;
        }



        if (!var_current_scope_1556184850310 !== this) {

            getLastNode = include('src::data.node.list.node.deepest.last').bind(this);
            join = include('src::data.node.list.join').bind(this);

            var_current_scope_1556184850310 = this;
        }


        return main.call(this, parentNode, list, baseChildNode, position);
    };

})();

exports['src::data.node.list'] = (() => {

    let constructor, get_startNode, get_endNode, method_getNodes, method_append, method_remove, method_insert;

    let var_init_locked_1556184850313;

    let var_class_1556184850313;

    return function(node, config) {


        if (!var_init_locked_1556184850313) {

            constructor = include('src::data.node.list.constructor');
            get_startNode = include('src::data.node.list.node.start');
            get_endNode = include('src::data.node.list.node.end');
            method_getNodes = include('src::data.node.list.nodes.get');
            method_append = include('src::data.node.list.append');
            method_remove = include('src::data.node.list.remove');
            method_insert = include('src::data.node.list.insert');

            var_init_locked_1556184850313 = true;
        }



        if (!var_class_1556184850313) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                getNodes(...args) {

                    return method_getNodes.apply(this, args);

                }
                append(...args) {

                    return method_append.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }
                insert(...args) {

                    return method_insert.apply(this, args);

                }

                get startNode() {

                    return get_startNode.call(this);

                }
                get endNode() {

                    return get_endNode.call(this);

                }

            }

            var_class_1556184850313 = main;
        }


        return new var_class_1556184850313(node, config);
    };

})();

exports['src::tree.node.list.get'] = (() => {

    let getList;

    let var_init_locked_1556184850317;





    function main() {


        /**
         * 
         * 获取节点列表
         * 
         * @import getList from data.node.list
         * 
         * @return {data.node.List} 节点列表 
         * 
         */

        return getList(this, {
            childNodesField: 'children'
        });

    }

    return function() {


        if (!var_init_locked_1556184850317) {

            getList = include('data.node.list');

            var_init_locked_1556184850317 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.index.get'] = (() => {









    function main() {


        /**
         * 
         * 获取树型节点在线性表中的位置
         * 
         * @return {number} 位置信息
         * 
         */

        let me = this,
            {
                nodes
            } = me.tree.list;

        return nodes.indexOf(me);

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.remove'] = (() => {

    let remove;

    let var_init_locked_1556184850323;





    function main(node) {


        /**
         * 
         * 删除子节点
         * 
         * @import remove from array.remove
         * 
         * @param {tree.node} node 子节点
         * 
         */

        let {
            $children,
            tree
        } = this;

        if ($children.includes(node)) {

            tree.removeQueue(node);

            remove($children, node);

            delete node.parentNode;
        }

    }

    return function(node) {


        if (!var_init_locked_1556184850323) {

            remove = include('array.remove');

            var_init_locked_1556184850323 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::tree.node.append'] = (() => {

    let isObject;

    let var_init_locked_1556184850325;





    function main(node) {


        /**
         * 
         * 添加子节点
         * 
         * @import isObject from is.object.simple
         * 
         * @param {mixed} node 子节点
         * 
         */

        let me = this,
            {
                $children,
                tree
            } = me;

        if (isObject(node)) {

            node = tree.read(node);

            if (!node) {

                return;
            }
        }

        let {
            parentNode
        } = node;

        if (parentNode) {

            parentNode.removeChild(node);

        }

        if (!$children.includes(node)) {

            node.parentNode = me;

            $children.push(node);

            tree.appendQueue(me, node);

            return node;
        }

    }

    return function(node) {


        if (!var_init_locked_1556184850325) {

            isObject = include('is.object.simple');

            var_init_locked_1556184850325 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::tree.node.children.set'] = (() => {

    let from, remove, append;

    let var_init_locked_1556184850327;

    let var_current_scope_1556184850327;



    function main(children) {


        /**
         * 
         * 设置子节点集合
         * 
         * @import from from array.from
         * 
         * @import remove from ....remove scoped
         * 
         * @import append from ....append scoped
         * 
         * @param {array} children 子节点集合
         * 
         * 
         */

        children = from(children);

        let me = this,
            {
                $children
            } = me;

        {
            let childNodes = from($children);

            for (let childNode of childNodes) {

                remove(childNode);
            }
        }

        {
            let childNodes = from(children);

            for (let childNode of childNodes) {

                append(childNode);
            }
        }



    }

    return function(children) {


        if (!var_init_locked_1556184850327) {

            from = include('array.from');

            var_init_locked_1556184850327 = true;
        }



        if (!var_current_scope_1556184850327 !== this) {

            remove = include('src::tree.node.remove').bind(this);
            append = include('src::tree.node.append').bind(this);

            var_current_scope_1556184850327 = this;
        }


        return main.call(this, children);
    };

})();

exports['src::tree.node.children.get'] = (() => {

    let from;

    let var_init_locked_1556184850332;





    function main() {


        /**
         * 
         * 获取子节点集合
         * 
         * @import from from array.from
         * 
         * @return {array} 子节点数组 
         * 
         */

        return from(this.$children);

    }

    return function() {


        if (!var_init_locked_1556184850332) {

            from = include('array.from');

            var_init_locked_1556184850332 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.descendants.get'] = (() => {









    function main() {


        /**
         * 
         * 获得所有的子孙节点
         * 
         * @return {array} 子孙节点集合
         * 
         */

        let nodes = [],
            {
                children
            } = this;

        for (let child of children) {

            nodes.push(child);

            if (!child.isLeaf) {

                nodes.push(...child.descendants);
            }
        }

        return nodes;



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::object.copy'] = (() => {









    function main(dest, source, fields) {


        /**
         * 
         * 复制
         * 
         * @param {object} dest 目标对象
         * 
         * @param {object} source 来源对象
         * 
         * @param {string[]} [fields = []] 拷贝字段集合 
         * 
         * @return {object} 目标对象引用
         * 
         */

        for (let field of fields) {

            dest[field] = source[field];
        }

        return dest;

    }

    return function(dest, source, fields = []) {





        return main.call(this, dest, source, fields);
    };

})();

exports['src::tree.node.data.get'] = (() => {

    let copy;

    let var_init_locked_1556184850337;





    function main() {


        /**
         * 
         * 获取节点的简单JSON数据
         * 
         * @import copy from object.copy
         * 
         * @return {object} JSON 数据
         * 
         */

        let me = this,
            {
                fields
            } = me.tree;

        return copy({}, me, fields);

    }

    return function() {


        if (!var_init_locked_1556184850337) {

            copy = include('object.copy');

            var_init_locked_1556184850337 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.isLeaf.get'] = (() => {









    function main() {


        /**
         * 
         * 判断当前节点是否是叶子节点
         * 
         * @return {boolean} 如果为叶子节点则返回 true , 否则返回 false 
         * 
         */

        return this.$children.length === 0;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.isRoot.get'] = (() => {









    function main() {


        /**
         * 
         * 判断当前节点是否为根节点
         * 
         * @return {boolean} 如果是根节点则返回 true , 否则返回 false 
         * 
         */

        return !this.parentNode;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.first.get'] = (() => {









    function main() {


        /**
         * 
         * 获得第一个子节点引用
         * 
         * @return {tree.Node} 树型节点
         * 
         */

        let {
            $children: children
        } = this;

        if (children.length) {

            return children[0];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.last.get'] = (() => {









    function main() {


        /**
         * 
         * 获得最后一个子节点引用
         * 
         * @return {tree.Node} 树型节点
         * 
         */

        let {
            $children: children
        } = this, {
            length
        } = children;

        if (length) {

            return children[length - 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.prev.get'] = (() => {









    function main() {


        /**
         * 
         * 返回当前节点的上一个兄弟节点
         * 
         * @return {tree.Node} 节点 
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            let {
                $children: children
            } = parentNode;

            return children[children.indexOf(me) - 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.next.get'] = (() => {









    function main() {


        /**
         * 
         * 返回当前节点的下一个兄弟节点
         * 
         * @return {tree.Node} 节点 
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            let {
                $children: children
            } = parentNode;

            return children[children.indexOf(me) + 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.first'] = (() => {










    /**
     * 
     * 第一个叶子节点
     * 
     * @return {tree.Node} 节点 
     * 
     */


    function get_first_node(node) {

        let {
            isLeaf
        } = node;

        if (isLeaf) {

            return node;
        }

        return get_first_node(node.first);
    }

    function main() {

        let me = this,
            {
                isLeaf
            } = me;

        if (isLeaf) {

            return
        }

        return get_first_node(me);
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.last'] = (() => {










    /**
     * 
     * 最后一个叶子节点
     * 
     * @return {tree.Node} 节点 
     * 
     */

    function get_last_node(node) {

        let {
            isLeaf
        } = node;

        if (isLeaf) {

            return node;
        }

        return get_last_node(node.last);
    }

    function main() {

        let me = this,
            {
                isLeaf
            } = me;

        if (isLeaf) {

            return
        }

        return get_last_node(me);
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.descendants'] = (() => {









    function main() {


        /**
         * 
         * 所有叶子子孙节点
         * 
         * @return {array} 子孙节点集合
         * 
         */


        let nodes = [],
            {
                descendants
            } = this;

        for (let descendant of descendants) {

            if (descendant.isLeaf) {

                nodes.push(descendant);
            }
        }

        return nodes;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.deepest'] = (() => {









    function main() {


        /**
         * 
         * 获取最深节点
         * 
         * @return {tree.NOde} 节点引用 
         * 
         */

        let {
            leafDescendants: nodes
        } = this;

        if (nodes.length) {

            let deepestNode = nodes[0],
                deepestFloor = deepestNode.floor;

            for (let node of nodes) {

                let {
                    floor
                } = node;

                if (deepestFloor < floor) {

                    deepestFloor = floor;

                    deepestNode = node;
                }
            }

            return deepestNode;
        }



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.floor.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前节点所在的层次
         * 
         * @return {number} 层次数值 
         * 
         */

        let node = this,
            floor = 1,
            parentNode;

        while (parentNode = node.parentNode) {

            node = parentNode;

            floor++;
        }

        return floor;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.insert.after'] = (() => {

    let isObject, insert;

    let var_init_locked_1556184850356;





    function main(node, existNode) {


        /**
         * 
         * 在指定节点之前插入
         * 
         * @import isObject from is.object.simple
         * 
         * @import insert from array.insert.after
         * 
         * @param {mixed} node 子节点
         * 
         * @param {tree.Node} existNode 已有子节点
         * 
         * @return {mixed} 返回说明 
         * 
         */

        let me = this,
            {
                $children: children,
                tree
            } = me;

        if (!children.includes(existNode)) {

            return;
        }

        if (isObject(node)) {

            node = tree.read(node);

            if (!node) {

                return;
            }
        }

        let {
            parentNode
        } = node;

        if (parentNode) {

            parentNode.removeChild(node);

        }

        if (!children.includes(node)) {

            tree.insertQueue(existNode.index + 1, node);

            node.parentNode = me;

            insert(children, node, existNode);

            return node;
        }

    }

    return function(node, existNode) {


        if (!var_init_locked_1556184850356) {

            isObject = include('is.object.simple');
            insert = include('array.insert.after');

            var_init_locked_1556184850356 = true;
        }




        return main.call(this, node, existNode);
    };

})();

exports['src::tree.node.insert.before'] = (() => {









    function main(data) {


        /**
         * 
         * 函数实现说明
         * 
         * @param {mixed} data 参数说明
         * 
         * @return {mixed} 返回说明 
         * 
         */

        // 代码实现

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::tree.node.destroy'] = (() => {









    function main() {


        /**
         * 
         * 销毁节点
         *
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            let {
                descendants
            } = me;

            descendants = descendants.reverse();

            for (let descendant of descendants) {

                descendant.destroy();
            }

            parentNode.remove(me);
        }





    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node'] = (() => {

    let constructor, get_list, get_index, set_children, get_children, get_descendants, get_data, get_isLeaf, get_isRoot, get_first, get_last, get_prev, get_next, get_firstLeaf, get_lastLeaf, get_leafDescendants, get_deepestLeaf, get_floor, method_append, method_insertAfter, method_insertBefore, method_remove, method_destroy;

    let var_init_locked_1556184850363;

    let var_class_1556184850363;

    return function() {


        if (!var_init_locked_1556184850363) {

            constructor = include('src::tree.node.constructor');
            get_list = include('src::tree.node.list.get');
            get_index = include('src::tree.node.index.get');
            set_children = include('src::tree.node.children.set');
            get_children = include('src::tree.node.children.get');
            get_descendants = include('src::tree.node.descendants.get');
            get_data = include('src::tree.node.data.get');
            get_isLeaf = include('src::tree.node.isLeaf.get');
            get_isRoot = include('src::tree.node.isRoot.get');
            get_first = include('src::tree.node.first.get');
            get_last = include('src::tree.node.last.get');
            get_prev = include('src::tree.node.prev.get');
            get_next = include('src::tree.node.next.get');
            get_firstLeaf = include('tree.node.leaf.first');
            get_lastLeaf = include('tree.node.leaf.last');
            get_leafDescendants = include('tree.node.leaf.descendants');
            get_deepestLeaf = include('tree.node.leaf.deepest');
            get_floor = include('src::tree.node.floor.get');
            method_append = include('src::tree.node.append');
            method_insertAfter = include('tree.node.insert.after');
            method_insertBefore = include('tree.node.insert.before');
            method_remove = include('src::tree.node.remove');
            method_destroy = include('src::tree.node.destroy');

            var_init_locked_1556184850363 = true;
        }



        if (!var_class_1556184850363) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                append(...args) {

                    return method_append.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                insertBefore(...args) {

                    return method_insertBefore.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }
                destroy(...args) {

                    return method_destroy.apply(this, args);

                }

                get list() {

                    return get_list.call(this);

                }
                get index() {

                    return get_index.call(this);

                }
                set children(value) {

                    set_children.call(this, value);

                }
                get children() {

                    return get_children.call(this);

                }
                get descendants() {

                    return get_descendants.call(this);

                }
                get data() {

                    return get_data.call(this);

                }
                get isLeaf() {

                    return get_isLeaf.call(this);

                }
                get isRoot() {

                    return get_isRoot.call(this);

                }
                get first() {

                    return get_first.call(this);

                }
                get last() {

                    return get_last.call(this);

                }
                get prev() {

                    return get_prev.call(this);

                }
                get next() {

                    return get_next.call(this);

                }
                get firstLeaf() {

                    return get_firstLeaf.call(this);

                }
                get lastLeaf() {

                    return get_lastLeaf.call(this);

                }
                get leafDescendants() {

                    return get_leafDescendants.call(this);

                }
                get deepestLeaf() {

                    return get_deepestLeaf.call(this);

                }
                get floor() {

                    return get_floor.call(this);

                }

            }

            var_class_1556184850363 = main;
        }


        return var_class_1556184850363;
    };

})();

exports['src::tree.node.mind.constructor'] = (() => {









    function main() {


        /**
         * 
         * 构建脑图节点
         * 
         */

        let me = this;

        me.x = 0;

        me.y = 0;

        me.selected = false;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind.height.region'] = (() => {









    function main() {


        /**
         * 
         * 当前节点所占的区域高度
         * 
         * @return {nubmber} 高度值 
         * 
         */

        let {
            leafDescendants,
            tree,
            height
        } = this, {
            verticalSpacing = 5
        } = tree.layoutConfig, {
            length
        } = leafDescendants;

        if (length) {

            let countHeight = 0;

            for (let descendant of leafDescendants) {

                countHeight += descendant.height;
            }

            return countHeight + verticalSpacing * (length - 1);
        }

        return height;



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind.region.node'] = (() => {

    let getRegion;

    let var_init_locked_1556184850378;





    function main() {


        /**
         * 
         * 实现基于节点的区域模型
         * 
         * @import getRegion from math.region.rect
         * 
         * @return {math.region.Rect} 矩型区域模型 
         * 
         */

        return getRegion(this);

    }

    return function() {


        if (!var_init_locked_1556184850378) {

            getRegion = include('math.region.rect');

            var_init_locked_1556184850378 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.mind.layout'] = (() => {









    function main() {


        /**
         * 
         * 布局
         * 
         */

        let me = this,
            {
                isRoot,
                isLeaf,
                x,
                y,
                width,
                height,
                $children: children,
                tree
            } = me,
            {
                length
            } = children,
            {
                horizontalSpacing = 5,
                verticalSpacing = 5
            } = tree.layoutConfig,
            startX = x + width + horizontalSpacing,
            startY;

        if (isRoot) {

            let countHeight = 0;

            for (let child of children) {

                countHeight += child.regionHeight;
            }

            startY = y - (countHeight + (length - 1) * verticalSpacing) / 2 + height / 2;

        } else {

            startY = y;
        }

        for (let child of children) {

            child.x = startX;

            child.y = startY;

            startY += child.regionHeight + verticalSpacing;

            child.layout();
        }

        if (!isRoot && !isLeaf) {

            let {
                first,
                last
            } = me;

            me.y = first.y + (last.y + last.height - first.y) / 2 - height / 2;
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind'] = (() => {

    let extend, constructor, get_regionHeight, get_nodeRegion, method_layout;

    let var_init_locked_1556184850384;

    let var_class_1556184850384;

    return function() {


        if (!var_init_locked_1556184850384) {

            extend = include('tree.node')();
            constructor = include('src::tree.node.mind.constructor');
            get_regionHeight = include('tree.node.mind.height.region');
            get_nodeRegion = include('tree.node.mind.region.node');
            method_layout = include('src::tree.node.mind.layout');

            var_init_locked_1556184850384 = true;
        }



        if (!var_class_1556184850384) {

            class main extends extend {





                constructor(...args) {

                    super(...args);

                    constructor.apply(this, args);

                }

                layout(...args) {

                    return method_layout.apply(this, args);

                }

                get regionHeight() {

                    return get_regionHeight.call(this);

                }
                get nodeRegion() {

                    return get_nodeRegion.call(this);

                }

            }

            var_class_1556184850384 = main;
        }


        return var_class_1556184850384;
    };

})();

exports['src::tree.reader.json'] = (() => {

    let objectGet, from, isEmpty, isObjectSimple, getReader;

    let var_init_locked_1556184850398;






    /**
     * 
     * 解析树型数据
     * 
     * @import object.get
     * 
     * @import from from array.from
     * 
     * @import is.empty
     * 
     * @import is.object.simple
     * 
     * @import getReader from data.reader.json
     * 
     * @param {object} [config = {}] 读取参数设置
     * 
     * @param {string} [config.rootProperty = '.'] 读取数据的根名称
     * 
     * @param {string} [config.childrenProperty = 'cn'] 读取子节点的字段名称
     * 
     * @param {string} [config.childrenField = 'children'] 存储子节点的字段名称
     * 
     * @param {function} [config.create] 构建对象函数
     * 
     * @param {function} [config.createExtraParams] 基于构建对象函数附加参数
     * 
     * @param {string} [config.fields] 读取数据记录的字段项
     * 
     * @return {function} 读取器所生成的解析函数
     * 
     */

    function main({
        rootProperty,
        childrenProperty,
        childrenField,
        fields,
        create,
        createExtraParams
    }) {

        const read = getReader({
                multi: false,
                create,
                createExtraParams,
                fields
            }),
            parse = children => {

                children = from(children);

                let result = [];

                for (let child of children) {

                    {
                        let children = child[childrenProperty];

                        child = read(child);

                        if (children) {

                            child[childrenField] = parse(children);

                        } else {

                            child[childrenField] = [];
                        }

                        result.push(child);
                    }
                }

                return result;

            };

        return (new Function('data', `

        var include = this.include,
            parse = this.parse,
            get = include('object.get'),
            isObject = include('is.object.simple');

        ${generate_get_root_data(rootProperty)}

        if(isObject(data)){

            return parse(data)[0] ;
        }

    `)).bind({
            include,
            parse
        });
    }

    function generate_get_root_data(rootProperty) {

        if (rootProperty !== '.') {

            return `data = get(data , '${rootProperty}');`;
        }

        return '';
    }

    return function({
        rootProperty = '.',
        childrenProperty = 'cn',
        childrenField = 'children',
        create,
        createExtraParams,
        fields
    } = {}) {


        if (!var_init_locked_1556184850398) {

            objectGet = include('object.get');
            from = include('array.from');
            isEmpty = include('is.empty');
            isObjectSimple = include('is.object.simple');
            getReader = include('data.reader.json');

            var_init_locked_1556184850398 = true;
        }




        return main.call(this, {
            rootProperty,
            childrenProperty,
            childrenField,
            create,
            createExtraParams,
            fields
        });
    };

})();

exports['src::tree.constructor'] = (() => {

    let createRead, getNodeClass, getProxy, getFields;

    let var_init_locked_1556184850404;





    function main(target, {
        reader,
        Node,
        defaultNodeConfig,
        layoutConfig,
        fields
    }) {


        /**
         * 
         * 初始化树
         * 
         * @import createRead from tree.reader.json
         * 
         * @import getNodeClass from tree.node
         * 
         * @import getProxy from object.proxy
         * 
         * @import getFields from data.reader.fields
         * 
         * @param {mixed} target 树所绑定的对象
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {object} [config.reader = {}] 读取器配置
         * 
         * @param {class} [config.Node] 节点类型 
         * 
         * @param {object} [config.defaultNodeConfig = {}] 默认的节点配置
         * 
         * @param {object} [config.layoutConfig = {}] 树型图的布局信息
         * 
         * @param {array} [config.fields] 可以显示的节点字段
         * 
         */

        let me = this;

        Node = me.Node = Node || getNodeClass();

        me.proxy = getProxy(target);

        fields = getFields(fields || [
            'id'
        ]);

        me.layoutConfig = layoutConfig;

        me.read = createRead(Object.assign({
            fields,
            create(config) {

                return new Node(config);

            }
        }, reader, {
            childrenField: 'children',
            createExtraParams: Object.assign({
                tree: me
            }, defaultNodeConfig)
        }));

        let fieldNames = me.fields = [];

        for (let {
                name
            } of fields) {

            fieldNames.push(name);
        }

        me.loading = false;

    }

    return function(target, {
        reader = {},
        Node,
        defaultNodeConfig = {},
        layoutConfig = {},
        fields
    } = {}) {


        if (!var_init_locked_1556184850404) {

            createRead = include('tree.reader.json');
            getNodeClass = include('tree.node');
            getProxy = include('object.proxy');
            getFields = include('data.reader.fields');

            var_init_locked_1556184850404 = true;
        }




        return main.call(this, target, {
            reader,
            Node,
            defaultNodeConfig,
            layoutConfig,
            fields
        });
    };

})();

exports['src::tree.data.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前树型结构的所有节点数据
         * 
         * @return {array} 一组数据 
         * 
         */

        let me = this,
            {
                rootNode
            } = me;

        if (!rootNode) {

            return [];
        }

        let {
            nodes
        } = me.list,
            result = [];

        for (let {
                data
            } of nodes) {

            result.push(data);
        }

        return result;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.get'] = (() => {









    function main(id) {


        /**
         * 
         * 获取树型节点
         * 
         * @param {string} id 基于编号定位树型节点
         * 
         * @return {tree.Node} 树型节点 
         * 
         */

        let {
            nodes
        } = this.list;

        for (let node of nodes) {

            if (node.id === id) {

                return node;
            }
        }

    }

    return function(id) {





        return main.call(this, id);
    };

})();

exports['src::tree.set'] = (() => {

    let assign, get;

    let var_init_locked_1556184850425;

    let var_current_scope_1556184850425;



    function main(id, values) {

        /**
         * 
         * 设置节点属性
         * 
         * @import assign from object.assign
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} [values = {}] 节点值
         * 
         * @return {mixed} 返回说明 
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node) {

            assign(node, values);

            proxy.call('update', node.data, node.index);
        }


    }

    return function(id, values = {}) {


        if (!var_init_locked_1556184850425) {

            assign = include('object.assign');

            var_init_locked_1556184850425 = true;
        }



        if (!var_current_scope_1556184850425 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1556184850425 = this;
        }


        return main.call(this, id, values);
    };

})();

exports['src::tree.clear'] = (() => {

    let from;

    let var_init_locked_1556184850429;





    function main() {


        /**
         * 
         * 清除所有节点
         * 
         * @import from from array.from
         * 
         */

        let me = this,
            {
                nodes,
                proxy
            } = me;

        nodes = from(nodes);

        for (let node of nodes) {

            node.destroy();
        }



        let {
            rootNode
        } = me;

        if (rootNode) {

            delete me.rootNode;

            delete me.list;

            me.nodes.length = 0;

            proxy.callIf('remove', 1);
        }

    }

    return function() {


        if (!var_init_locked_1556184850429) {

            from = include('array.from');

            var_init_locked_1556184850429 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.load'] = (() => {









    function main(data) {


        /**
         * 
         * 重新载入树形数据
         * 
         * @param {mixed} data 树型数据
         * 
         */

        let me = this;

        me.clear();

        me.loading = true;

        let rootNode = me.read(data);

        if (rootNode) {

            me.rootNode = rootNode;

            let {
                proxy
            } = me;

            me.list = rootNode.list;

            console.log('初始化列表', me.list);

            proxy.callIf('load', me.data);

        }

        me.loading = false;



    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::tree.queue.append'] = (() => {









    function main(parentNode, node) {


        /**
         * 
         * 新增一个节点进队列
         * 
         * @param {number} parentNode 父节点
         * 
         * @param {tree.Node} node 节点
         * 
         */

        let {
            list
        } = this;

        if (list) {

            list.append(parentNode, node.list);
        }

    }

    return function(parentNode, node) {





        return main.call(this, parentNode, node);
    };

})();

exports['src::tree.queue.remove'] = (() => {

    let remove;

    let var_init_locked_1556184850438;





    function main(node) {


        /**
         * 
         * 移除树型节点
         * 
         * @import remove from array.remove
         *
         * @param {tree.Node} node 节点配置
         * 
         */

        let me = this,
            {
                nodes,
                proxy
            } = me,
            index = nodes.indexOf(node);

        remove(nodes, node);

    }

    return function(node) {


        if (!var_init_locked_1556184850438) {

            remove = include('array.remove');

            var_init_locked_1556184850438 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::tree.queue.insert'] = (() => {

    let insert;

    let var_init_locked_1556184850441;





    function main(index, node) {

        /**
         * 
         * 将节点插入到线性表中
         * 
         * @import insert from array.insert
         * 
         * @param {number} index 数组下标
         * 
         * @param {tree.Node} node 树型节点
         * 
         */

        let {
            nodes
        } = this;

        insert(nodes, index, node);

    }

    return function(index, node) {


        if (!var_init_locked_1556184850441) {

            insert = include('array.insert');

            var_init_locked_1556184850441 = true;
        }




        return main.call(this, index, node);
    };

})();

exports['src::tree.append'] = (() => {

    let get;

    let var_init_locked_1556184850443;

    let var_current_scope_1556184850443;



    function main(id, config) {


        /**
         * 
         * 添加子节点
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node) {

            let newNode = node.append(config);

            if (newNode) {

                proxy.callIf('insert', newNode.data, newNode.index);

                return true;
            }
        }

        return false;



    }

    return function(id, config) {




        if (!var_current_scope_1556184850443 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1556184850443 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.insert.before'] = (() => {









    function main(data) {


        /**
         * 
         * 函数实现说明
         * 
         * @param {mixed} data 参数说明
         * 
         * @return {mixed} 返回说明 
         * 
         */

        // 代码实现

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::tree.insert.after'] = (() => {

    let get;

    let var_init_locked_1556184850447;

    let var_current_scope_1556184850447;



    function main(id, config) {


        /**
         * 
         * 在指定节点下方添加节点
         * 
         * @import get from ....node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node && !node.isRoot) {

            let {
                parentNode
            } = node,
            newNode = parentNode.insertAfter(config, node);

            if (newNode) {

                proxy.callIf('insert', newNode.data, newNode.index);

                return true;
            }
        }

        return false;

    }

    return function(id, config) {




        if (!var_current_scope_1556184850447 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1556184850447 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.remove'] = (() => {

    let get;

    let var_init_locked_1556184850450;

    let var_current_scope_1556184850450;



    function main(id) {


        /**
         * 
         * 删除子节点
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node && !node.isRoot) {

            proxy.callIf('remove', node.index);

            node.destroy();

            return true;
        }

        return false;


    }

    return function(id) {




        if (!var_current_scope_1556184850450 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1556184850450 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree'] = (() => {

    let constructor, get_data, method_set, method_clear, method_load, method_appendQueue, method_removeQueue, method_insertQueue, method_append, method_insertBefore, method_insertAfter, method_remove;

    let var_init_locked_1556184850452;

    let var_class_1556184850452;

    return function() {


        if (!var_init_locked_1556184850452) {

            constructor = include('src::tree.constructor');
            get_data = include('src::tree.data.get');
            method_set = include('src::tree.set');
            method_clear = include('src::tree.clear');
            method_load = include('src::tree.load');
            method_appendQueue = include('tree.queue.append');
            method_removeQueue = include('tree.queue.remove');
            method_insertQueue = include('tree.queue.insert');
            method_append = include('src::tree.append');
            method_insertBefore = include('tree.insert.before');
            method_insertAfter = include('tree.insert.after');
            method_remove = include('src::tree.remove');

            var_init_locked_1556184850452 = true;
        }



        if (!var_class_1556184850452) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                set(...args) {

                    return method_set.apply(this, args);

                }
                clear(...args) {

                    return method_clear.apply(this, args);

                }
                load(...args) {

                    return method_load.apply(this, args);

                }
                appendQueue(...args) {

                    return method_appendQueue.apply(this, args);

                }
                removeQueue(...args) {

                    return method_removeQueue.apply(this, args);

                }
                insertQueue(...args) {

                    return method_insertQueue.apply(this, args);

                }
                append(...args) {

                    return method_append.apply(this, args);

                }
                insertBefore(...args) {

                    return method_insertBefore.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }

                get data() {

                    return get_data.call(this);

                }

            }

            var_class_1556184850452 = main;
        }


        return var_class_1556184850452;
    };

})();

exports['src::tree.mind.extend'] = (() => {

    let Node, tree;

    let var_init_locked_1556184850472;

    let var_class_1556184850472;

    return function() {


        if (!var_init_locked_1556184850472) {

            Node = include('tree.node.mind')();
            tree = include('tree')();

            var_init_locked_1556184850472 = true;
        }



        if (!var_class_1556184850472) {

            /**
             * 
             * 脑图
             * 
             * @import Node from tree.node.mind value
             * 
             * @import tree value
             * 
             * @class
             * 
             */

            class main extends tree {

                constructor(target, config) {

                    let {
                        fields = []
                    } = config;

                    config.fields = [
                        'id',
                        'x',
                        'y',
                        'width',
                        'height',
                        'selected',
                        ...fields
                    ];

                    config.Node = Node;

                    super(target, config);
                }
            }

            var_class_1556184850472 = main;
        }


        return var_class_1556184850472;
    };

})();

exports['src::tree.mind.constructor'] = (() => {









    function main(target, {
        rootXY
    }) {


        /**
         * 
         * 构建脑图
         * 
         * @param {mixed} target 脑图绑定对象
         * 
         * @param {object} config 脑图配置
         * 
         * @param {object} config.rootXY 脑图根节点的位置
         * 
         */

        this.rootXY = rootXY;

    }

    return function(target, {
        rootXY
    }) {





        return main.call(this, target, {
            rootXY
        });
    };

})();

exports['src::tree.mind.deselect'] = (() => {









    function main() {


        /**
         * 
         * 取消选定
         * 
         */

        let me = this,
            {
                selectedNode,
                proxy
            } = me;

        if (selectedNode) {

            selectedNode.selected = false;

            delete me.selectedNode;

            proxy.call('deselect', selectedNode.index);
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.clear'] = (() => {

    let clear, deselect;

    let var_init_locked_1556184850493;

    let var_current_scope_1556184850493;



    function main() {


        /**
         * 
         * 清空数据
         * 
         * @import clear from tree.clear scoped
         * 
         * @import deselect from ..deselect scoped
         * 
         */

        deselect();

        clear();

    }

    return function() {




        if (!var_current_scope_1556184850493 !== this) {

            clear = include('tree.clear').bind(this);
            deselect = include('src::tree.mind.deselect').bind(this);

            var_current_scope_1556184850493 = this;
        }


        return main.call(this);
    };

})();

exports['src::tree.mind.layout'] = (() => {










    /**
     * 
     * 基于根节点进行布局
     * 
     */

    function main() {

        let me = this,
            {
                rootNode,
                rootXY,
                layoutConfig
            } = me,
            {
                lineOffset = 5
            } = layoutConfig;

        if (rootNode) {

            let {
                x,
                y
            } = rootXY;

            rootNode.x = x;

            rootNode.y = y;

            rootNode.layout();

            let {
                proxy,
                data
            } = me, {
                firstLeaf,
                lastLeaf,
                deepestLeaf
            } = rootNode;

            if (!firstLeaf) {

                firstLeaf = rootNode;
            }

            if (!lastLeaf) {

                lastLeaf = rootNode;
            }

            if (!deepestLeaf) {

                deepestLeaf = rootNode;
            }

            let top = firstLeaf.y;

            if (top > 0) {

                top = 0;

            } else {

                top = -top;
            }

            let left = rootNode.x;

            if (left > 0) {

                left = 0;

            } else {

                left = -left;
            }

            proxy.call('layout', data, {
                left,
                right: deepestLeaf.x + deepestLeaf.width,
                top,
                bottom: lastLeaf.y + lastLeaf.height,
                lines: get_lines(rootNode, {
                    left,
                    top,
                    lineOffset
                })
            });
        }
    }

    function get_lines(node, params) {

        let {
            left,
            top,
            lineOffset
        } = params;

        let lines = [];

        let {
            nodeRegion,
            children
        } = node, {
            x: startX,
            y: startY
        } = nodeRegion.getAnchorXY('r');

        startX += left;

        startY += top;

        for (let child of children) {

            let {
                isLeaf,
                nodeRegion
            } = child, {
                x,
                y
            } = nodeRegion.getAnchorXY('l');

            x += left;

            y += top;

            lines.push([
                startX,
                startY,
                startX + lineOffset,
                startY,
                x - lineOffset,
                y,
                x,
                y
            ]);

            if (!isLeaf) {

                lines.push(...get_lines(child, params));
            }
        }

        return lines;
    }



    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.load'] = (() => {

    let load, layout;

    let var_init_locked_1556184850499;

    let var_current_scope_1556184850499;



    function main(data) {


        /**
         * 
         * 数据载入
         * 
         * @import load from tree.load scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {mixed} data 树型数据
         * 
         */

        load(data);

        layout();



    }

    return function(data) {




        if (!var_current_scope_1556184850499 !== this) {

            load = include('tree.load').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1556184850499 = this;
        }


        return main.call(this, data);
    };

})();

exports['src::tree.mind.insert.after'] = (() => {

    let insert, layout;

    let var_init_locked_1556184850502;

    let var_current_scope_1556184850502;



    function main(id, config) {

        /**
         * 
         * 增加子节点
         * 
         * @import insert from tree.insert.after scoped
         * 
         * @import layout from ....layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        if (insert(id, config)) {

            layout();
        }

    }

    return function(id, config) {




        if (!var_current_scope_1556184850502 !== this) {

            insert = include('tree.insert.after').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1556184850502 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.append'] = (() => {

    let append, layout;

    let var_init_locked_1556184850504;

    let var_current_scope_1556184850504;



    function main(id, config) {


        /**
         * 
         * 增加子节点
         * 
         * @import append from tree.append scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        if (append(id, config)) {

            layout();
        }



    }

    return function(id, config) {




        if (!var_current_scope_1556184850504 !== this) {

            append = include('tree.append').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1556184850504 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.remove'] = (() => {

    let deselect, remove, layout;

    let var_init_locked_1556184850506;

    let var_current_scope_1556184850506;



    function main(id, config) {


        /**
         * 
         * 删除子节点
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import remove from tree.remove scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        deselect();

        if (remove(id, config)) {

            layout();
        }


    }

    return function(id, config) {




        if (!var_current_scope_1556184850506 !== this) {

            deselect = include('src::tree.mind.deselect').bind(this);
            remove = include('tree.remove').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1556184850506 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.select'] = (() => {

    let deselect, get;

    let var_init_locked_1556184850508;

    let var_current_scope_1556184850508;



    function main(id) {


        /**
         * 
         * 选定节点
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import get from tree.node.get scoped
         * 
         * @param {string} id 需要选定的节点
         * 
         */

        let me = this,
            {
                proxy
            } = me,
            node = get(id);

        if (node) {

            deselect();

            node.selected = true;

            me.selectedNode = node;

            proxy.call('select', node.index);
        }



    }

    return function(id) {




        if (!var_current_scope_1556184850508 !== this) {

            deselect = include('src::tree.mind.deselect').bind(this);
            get = include('tree.node.get').bind(this);

            var_current_scope_1556184850508 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree.mind.select.right'] = (() => {









    function main() {


        /**
         * 
         * 向右选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.right();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.left'] = (() => {









    function main() {


        /**
         * 
         * 向左选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.left();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.up'] = (() => {









    function main() {


        /**
         * 
         * 向上选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.up();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.down'] = (() => {









    function main() {


        /**
         * 
         * 向下选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.down();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind'] = (() => {

    let extend, constructor, method_clear, method_load, method_insertAfter, method_append, method_remove, method_deselect, method_select, method_selectRight, method_selectLeft, method_selectUp, method_selectDown, method_layout;

    let var_init_locked_1556184850518;

    let var_class_1556184850518;

    return function(target, config) {


        if (!var_init_locked_1556184850518) {

            extend = include('src::tree.mind.extend')();
            constructor = include('src::tree.mind.constructor');
            method_clear = include('src::tree.mind.clear');
            method_load = include('src::tree.mind.load');
            method_insertAfter = include('tree.mind.insert.after');
            method_append = include('src::tree.mind.append');
            method_remove = include('src::tree.mind.remove');
            method_deselect = include('src::tree.mind.deselect');
            method_select = include('src::tree.mind.select');
            method_selectRight = include('src::tree.mind.select.right');
            method_selectLeft = include('src::tree.mind.select.left');
            method_selectUp = include('src::tree.mind.select.up');
            method_selectDown = include('src::tree.mind.select.down');
            method_layout = include('src::tree.mind.layout');

            var_init_locked_1556184850518 = true;
        }



        if (!var_class_1556184850518) {

            class main extends extend {





                constructor(...args) {

                    super(...args);

                    constructor.apply(this, args);

                }

                clear(...args) {

                    return method_clear.apply(this, args);

                }
                load(...args) {

                    return method_load.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                append(...args) {

                    return method_append.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }
                deselect(...args) {

                    return method_deselect.apply(this, args);

                }
                select(...args) {

                    return method_select.apply(this, args);

                }
                selectRight(...args) {

                    return method_selectRight.apply(this, args);

                }
                selectLeft(...args) {

                    return method_selectLeft.apply(this, args);

                }
                selectUp(...args) {

                    return method_selectUp.apply(this, args);

                }
                selectDown(...args) {

                    return method_selectDown.apply(this, args);

                }
                layout(...args) {

                    return method_layout.apply(this, args);

                }



            }

            var_class_1556184850518 = main;
        }


        return new var_class_1556184850518(target, config);
    };

})();