exports['src::class.empty'] = (() => {










    /**
     * 
     * 返回一个空类
     * 
     * @return {function} 类引用 
     * 
     */

    const emptyClass = class {

    };

    function main() {

        return emptyClass;
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::message.center.constructor'] = (() => {









    function main() {


        /**
         * 
         * 初始化消息中心
         * 
         */

        this.addresses = {};

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::message.address.constructor'] = (() => {









    function main(name) {


        /**
         * 
         * 初始化地址
         * 
         * @param {string} name 地址名称
         * 
         * 
         */

        let me = this;

        me.name = name;

        me.messages = [];

    }

    return function(name) {





        return main.call(this, name);
    };

})();

exports['src::is.defined'] = (() => {









    function main(data) {

        /**
         * 
         * 判断给定数据是否定义
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果数据定义则返回 true , 否则返回 false
         * 
         */

        return data !== undefined;

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::is.type'] = (() => {









    function main(data, type) {

        /**
         * 
         * 对于 typeof 的简单封装
         * 
         * @param {mixed} data 检验数据
         * 
         * @param {string} type 检验数据类型
         * 
         * @return {boolean} 如果检验数据的数据类型与检验数据类型一致，则返回 true，否则返回 false 
         * 
         */

        return typeof data === type;

    }

    return function(data, type) {





        return main.call(this, data, type);
    };

})();

exports['src::is.string'] = (() => {

    let isType;

    let var_init_locked_1557128179180;





    function main(data) {

        /**
         * 
         * 判定数据是否为字符串类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为字符串类型则返回 true , 否则返回 false 
         * 
         */

        return isType(data, 'string');

    }

    return function(data) {


        if (!var_init_locked_1557128179180) {

            isType = include('is.type');

            var_init_locked_1557128179180 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.object.simple'] = (() => {









    function main(data) {

        /**
         * 
         * 判定数据是否为简单对象类型
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为简单对象类型则返回 true , 否则返回 false 
         * 
         */

        return data instanceof Object && data.constructor === Object;

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::message.address.send'] = (() => {

    let getCenter, isString, isObject;

    let var_init_locked_1557128179191;





    function main(message) {

        /**
         * 
         * 发送消息
         * 
         * @import getCenter from message.center
         * 
         * @import is.string
         * 
         * @import isObject from is.object.simple
         * 
         * @param {mixed} message 消息配置
         * 
         * 
         */

        let center = getCenter();

        if (isString(message)) {

            center.receive({
                to: message
            });

        } else if (isObject(message)) {

            let {
                from
            } = message;

            if (from) {

                let {
                    name
                } = this;

                message.from = `${name}::${from}`;
            }

            center.receive(message);
        }

    }

    return function(message) {


        if (!var_init_locked_1557128179191) {

            getCenter = include('message.center');
            isString = include('is.string');
            isObject = include('is.object.simple');

            var_init_locked_1557128179191 = true;
        }




        return main.call(this, message);
    };

})();

exports['src::message.address.doAction'] = (() => {

    let isDefined, send;

    let var_init_locked_1557128179198;

    let var_current_scope_1557128179198;



    async function main(target, message) {


        /**
         * 
         * 执行绑定对象相关函数
         * 
         * @import is.defined
         * 
         * @import send from .send scoped
         * 
         * @param {mixed} target 作用对象
         * 
         * @param {object} message 消息
         * 
         */

        let {
            toAction,
            from,
            payload
        } = message;

        if (toAction in target) {

            let result = await target[toAction](payload, message);

            if (from && isDefined(result)) {

                send({
                    to: from,
                    replyPayload: payload,
                    payload: result
                });
            }
        }

    }

    return async function(target, message) {


        if (!var_init_locked_1557128179198) {

            isDefined = include('is.defined');

            var_init_locked_1557128179198 = true;
        }



        if (!var_current_scope_1557128179198 !== this) {

            send = include('src::message.address.send').bind(this);

            var_current_scope_1557128179198 = this;
        }


        return await main.call(this, target, message);
    };

})();

exports['src::message.address.bind'] = (() => {

    let doAction;

    let var_init_locked_1557128179208;

    let var_current_scope_1557128179208;



    function main(target) {


        /**
         * 
         * 绑定目标对象
         * 
         * @import doAction from .doAction scoped
         * 
         * @param {mixed} target 目标对象
         * 
         */

        let me = this,
            {
                target: currentTarget,
                messages
            } = me;

        if (!currentTarget) {

            for (let message of messages) {

                doAction(target, message);

            }

            messages.length = 0;

            me.target = target;

            return true;

        } else if (currentTarget === me) {

            return true;
        }

        return false;


    }

    return function(target) {




        if (!var_current_scope_1557128179208 !== this) {

            doAction = include('src::message.address.doAction').bind(this);

            var_current_scope_1557128179208 = this;
        }


        return main.call(this, target);
    };

})();

exports['src::array.remove.index'] = (() => {









    function main(data, index) {


        /**
         * 
         * 根据数组下标删除对应项
         * 
         * @param {array} data 作用数组
         * 
         * @param {number} index 数组项的下标
         * 
         * @return {boolean} 如果删除成功则返回 true , 否则返回　false 
         * 
         */

        if (index >= 0 && index < data.length) {

            data.splice(index, 1);

            return true;
        }

        return false;

    }

    return function(data, index) {





        return main.call(this, data, index);
    };

})();

exports['src::array.remove'] = (() => {

    let remove;

    let var_init_locked_1557128179217;





    function main(data, ...items) {


        /**
         * 
         * 在数组中去除项目
         * 
         * @import remove from array.remove.index
         * 
         * @param {array} data 数组
         * 
         * @param {mixed} [...items] 项目
         * 
         */

        for (let item of items) {

            remove(data, data.indexOf(item));
        }

    }

    return function(data, ...items) {


        if (!var_init_locked_1557128179217) {

            remove = include('array.remove.index');

            var_init_locked_1557128179217 = true;
        }




        return main.call(this, data, ...items);
    };

})();

exports['src::message.address.unbind'] = (() => {

    let remove;

    let var_init_locked_1557128179219;





    function main() {


        /**
         * 
         * 取消绑定目标对象
         * 
         * @import remove from array.remove
         * 
         */

        delete this.target;



    }

    return function() {


        if (!var_init_locked_1557128179219) {

            remove = include('array.remove');

            var_init_locked_1557128179219 = true;
        }




        return main.call(this);
    };

})();

exports['src::message.address.receive'] = (() => {

    let doAction;

    let var_init_locked_1557128179223;

    let var_current_scope_1557128179223;



    function main(message) {


        /**
         * 
         * 接收消息
         * 
         * @import doAction from .doAction scoped
         * 
         * @param {Message} message 消息
         * 
         */

        let {
            target,
            messages
        } = this;

        if (target) {

            doAction(target, message);

        } else {

            messages.push(message);
        }

    }

    return function(message) {




        if (!var_current_scope_1557128179223 !== this) {

            doAction = include('src::message.address.doAction').bind(this);

            var_current_scope_1557128179223 = this;
        }


        return main.call(this, message);
    };

})();

exports['src::message.address'] = (() => {

    let extend, constructor, method_bind, method_unbind, method_receive, method_send;

    let var_init_locked_1557128179231;

    let var_class_1557128179231;

    return function() {


        if (!var_init_locked_1557128179231) {

            extend = include('class.empty')();
            constructor = include('src::message.address.constructor');
            method_bind = include('src::message.address.bind');
            method_unbind = include('src::message.address.unbind');
            method_receive = include('src::message.address.receive');
            method_send = include('src::message.address.send');

            var_init_locked_1557128179231 = true;
        }



        if (!var_class_1557128179231) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                bind(...args) {

                    return method_bind.apply(this, args);

                }
                unbind(...args) {

                    return method_unbind.apply(this, args);

                }
                receive(...args) {

                    return method_receive.apply(this, args);

                }
                send(...args) {

                    return method_send.apply(this, args);

                }



            }

            var_class_1557128179231 = main;
        }


        return new var_class_1557128179231();
    };

})();

exports['src::message.center.register'] = (() => {

    let create;

    let var_init_locked_1557128179239;





    function main(address) {


        /**
         * 
         * 注册地址
         * 
         * @import create from message.address
         * 
         * @param {string} address 消息地址
         * 
         * 
         */

        let {
            addresses
        } = this;

        if (!addresses.hasOwnProperty(address)) {

            addresses[address] = create(address);
        }

        return addresses[address];

    }

    return function(address) {


        if (!var_init_locked_1557128179239) {

            create = include('message.address');

            var_init_locked_1557128179239 = true;
        }




        return main.call(this, address);
    };

})();

exports['src::message.address.parse'] = (() => {









    function main(address) {


        /**
         * 
         * 解析消息地址
         * 
         * @param {string} address 消息地址
         * 
         * @return {object} 地址解析后的结果 
         * 
         */

        let match = address.match(/^([^\:]+)\:{2}([^\:]+)$/);

        if (match) {

            let [,
                address,
                action
            ] = match;

            return {
                address,
                action
            };
        }

    }

    return function(address) {





        return main.call(this, address);
    };

})();

exports['src::message.center.receive'] = (() => {

    let parse;

    let var_init_locked_1557128179252;





    function main({
        from,
        to,
        payload
    }) {


        /**
         * 
         * 接收消息
         * 
         * @import parse from message.address.parse
         * 
         * @param {object} message 消息
         * 
         * @param {string} [message.from] 消息来源地址
         * 
         * @param {string} message.to 消息发送地址
         * 
         * @param {mixed} [message.payload] 消息负荷
         * 
         */

        let result = parse(to);

        if (result) {

            let {
                address: toAddress,
                action: toAction
            } = result;

            this.register(toAddress).receive({
                toAction,
                payload,
                from
            });
        }


    }

    return function({
        from,
        to,
        payload
    }) {


        if (!var_init_locked_1557128179252) {

            parse = include('message.address.parse');

            var_init_locked_1557128179252 = true;
        }




        return main.call(this, {
            from,
            to,
            payload
        });
    };

})();

exports['src::message.center'] = (() => {

    let extend, constructor, method_register, method_receive;

    let var_init_locked_1557128179255;

    let var_class_1557128179255;

    return function() {


        if (!var_init_locked_1557128179255) {

            extend = include('class.empty')();
            constructor = include('src::message.center.constructor');
            method_register = include('src::message.center.register');
            method_receive = include('src::message.center.receive');

            var_init_locked_1557128179255 = true;
        }



        if (!var_class_1557128179255) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                register(...args) {

                    return method_register.apply(this, args);

                }
                receive(...args) {

                    return method_receive.apply(this, args);

                }



            }

            var_class_1557128179255 = main;
        }



        if (var_once_value_1557128179255) {

            return var_once_value_1557128179255;

        }

        return var_once_value_1557128179255 = new var_class_1557128179255();

    };

})();

exports['src::id.generate'] = (() => {










    /**
     * 
     * 生成唯一的编号
     * 
     * @param {string} prefix 编号前缀
     * 
     * @return {string} 生成后的唯一编号 
     * 
     */

    let count = 1;

    function main(prefix = 'zb-') {

        return `${prefix}${count ++}`;

    }

    return function(prefix) {





        return main.call(this, prefix);
    };

})();

exports['src::message.address.react'] = (() => {

    let getCenter, get;

    let var_init_locked_1557128179273;





    function main(ReactDOM, reactClass, address) {

        /**
         * 
         * 基于 React 基于消息系统
         * 
         * @import getCenter from message.center
         * 
         * @import get from id.generate
         * 
         * @param {ReactDOM} ReactDOM ReactDOM 引用
         * 
         * @param {React.Component} reactClass 继承的 React 组件类
         * 
         * @param {string} [address] 组件注册的消息地址
         * 
         */

        let center = getCenter(),
            count = 1;

        return class extends reactClass {

            componentDidMount() {

                let me = this,
                    {
                        address: currentAddress
                    } = me.props;

                currentAddress = currentAddress || address || get('address-');

                let {
                    $address
                } = me;

                if ($address) {

                    console.error('已拥有消息地址', $address.name, currentAddress);

                } else {

                    let messageAddress = center.register(currentAddress),
                        isBind = messageAddress.bind(me);

                    if (!isBind) {

                        console.error('消息地址已被注册', currentAddress, ReactDOM.findDOMNode(me), ReactDOM.findDOMNode(messageAddress.target));

                    } else {

                        me.$address = messageAddress;

                    }

                }

                if (super.componentDidMount) {

                    super.componentDidMount();
                }

            }

            componentWillUnmount() {

                if (super.componentWillUnmount) {

                    super.componentWillUnmount();
                }

                let me = this,
                    {
                        $address: address
                    } = me;

                if (address) {

                    address.unbind();

                    delete me.$address;
                }
            }

        }

    }

    return function(ReactDOM, reactClass, address) {


        if (!var_init_locked_1557128179273) {

            getCenter = include('message.center');
            get = include('id.generate');

            var_init_locked_1557128179273 = true;
        }




        return main.call(this, ReactDOM, reactClass, address);
    };

})();

exports['src::array.remove.all'] = (() => {

    let remove;

    let var_init_locked_1557128179279;





    function main(data, item) {


        /**
         * 
         * 在数组中去除所有指定项目
         * 
         * @import remove from array.remove
         * 
         * @param {array} data 数组
         * 
         * @param {mixed} item 项目
         * 
         */

        while (true) {

            if (remove(data, item) === false) {

                break;
            }
        }

    }

    return function(data, item) {


        if (!var_init_locked_1557128179279) {

            remove = include('array.remove');

            var_init_locked_1557128179279 = true;
        }




        return main.call(this, data, item);
    };

})();

exports['src::url.append'] = (() => {

    let isString;

    let var_init_locked_1557128179288;





    function main(url, data) {


        /**
         * 
         * 基于已有链接附加查询信息
         * 
         * @import is.string
         * 
         * @param {string} url 链接
         * 
         * @param {mixed} data 附加查询信息
         * 
         * @return {mixed} 拼接了查询信息的链接 
         * 
         */

        let querystring;

        if (isString(data)) {

            querystring = data;

        } else {

            querystring = [];

            let names = Object.keys(data);

            for (let name of names) {

                querystring.push(`${name}=${encodeURIComponent(data[name])}`);
            }

            querystring = querystring.join('&');

        }

        if (querystring) {

            if (url.includes('?')) {

                return `${url}&${querystring}`;
            }

            return `${url}?${querystring}`;

        }

        return url;


    }

    return function(url, data) {


        if (!var_init_locked_1557128179288) {

            isString = include('is.string');

            var_init_locked_1557128179288 = true;
        }




        return main.call(this, url, data);
    };

})();

exports['src::regexp.int'] = (() => {









    function main(data) {


        /**
         * 
         * 匹配整数
         * 
         * @param {string} data 参数说明
         * 
         * @return {boolean} 如果匹配成功则返回 true , 否则返回 false 
         * 
         */

        return /^\d+$/.test(data);

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::url.template.apply'] = (() => {

    let isInt;

    let var_init_locked_1557128179296;





    function main(url, data) {


        /**
         * 
         * 路径模板应用
         * 
         * @import isInt from regexp.int
         * 
         * @param {string} url 带有参数定义的URL
         * 
         * @param {object} data 模板参数定义数据集合
         * 
         * @return {string} 应用数据后的URL链接
         * 
         */

        return url.replace(/\:(\w+)/g, (match, name) => {

            if (isInt(name)) {

                return `:${name}`;
            }

            return data[name] || '';

        });


    }

    return function(url, data) {


        if (!var_init_locked_1557128179296) {

            isInt = include('regexp.int');

            var_init_locked_1557128179296 = true;
        }




        return main.call(this, url, data);
    };

})();

exports['src::is.array'] = (() => {

    let isType;

    let var_init_locked_1557128179299;





    function main(data) {

        /**
         * 
         * 判定数据是否为数组类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为数组类型则返回 true , 否则返回 false 
         * 
         */

        return Array.isArray(data);

    }

    return function(data) {


        if (!var_init_locked_1557128179299) {

            isType = include('is.type');

            var_init_locked_1557128179299 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.object'] = (() => {

    let isType;

    let var_init_locked_1557128179302;





    function main(data) {

        /**
         * 
         * 判定数据是否为对象类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为对象类型则返回 true , 否则返回 false 
         * 
         */

        return Object.prototype.toString.call(data) === '[object Object]';

    }

    return function(data) {


        if (!var_init_locked_1557128179302) {

            isType = include('is.type');

            var_init_locked_1557128179302 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::object.key.join'] = (() => {










    /**
     * 
     * 将多个键值连接起来
     * 
     * @param {array} [...keys] 一组键值
     * 
     * @return {string} 连接后的键值 
     * 
     */

    const suffixRe = /(?:^\.+)|(?:\.+$)/g;

    function main(...keys) {

        let result = [];

        for (let key of keys) {

            key = key.replace(suffixRe, '');

            if (key) {

                result.push(key);
            }
        }

        return result.join('.');
    }



    return function(...keys) {





        return main.call(this, ...keys);
    };

})();

exports['src::object.get'] = (() => {

    let isArray, isObject, isDefined, join;

    let var_init_locked_1557128179311;






    /**
     * 
     * 获得一个对象的键值
     * 
     * @import is.array
     * 
     * @import is.object
     * 
     * @import is.defined
     * 
     * @import join from object.key.join
     * 
     * @param {object} data 对象数据
     * 
     * @param {string} [key = '.'] 对象键值
     * 
     * @return {mixed} 对应对象数据的键值的数据 
     * 
     * @scoped
     * 
     */

    const firstKeyRe = /^([^\.]+)\./;

    function main(data, key, prefixKey = '') {

        if (key === '.') {

            return data;
        }

        if (isObject(data)) {

            let firstKey,
                lastKey = key.replace(firstKeyRe, function() {

                    firstKey = arguments[1];

                    return '';

                });

            if (firstKey) {

                firstKey = join(prefixKey, firstKey);

                let result;

                if (data.hasOwnProperty(firstKey)) {

                    result = data[firstKey];

                    prefixKey = '';

                } else {

                    result = data;

                    prefixKey = firstKey;
                }

                if (lastKey) {

                    return main(result, lastKey, prefixKey);
                }

                return result;

            } else {

                return data[join(prefixKey, lastKey)];
            }

        } else if (isArray(data)) {

            let result = [];

            for (let item of data) {

                let itemResult = main(item, key);

                if (isArray(itemResult)) {

                    result.push(...itemResult);

                } else if (!isDefined(itemResult)) {

                    result.push(itemResult);

                }
            }

            return result;
        }
    }

    return function(data, key = '.') {


        if (!var_init_locked_1557128179311) {

            isArray = include('is.array');
            isObject = include('is.object');
            isDefined = include('is.defined');
            join = include('object.key.join');

            var_init_locked_1557128179311 = true;
        }




        return main.call(this, data, key);
    };

})();

exports['src::is.function'] = (() => {

    let isType;

    let var_init_locked_1557128179314;





    function main(data) {

        /**
         * 
         * 判定数据是否为函数类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {mixed} 如果给定值为函数类型则返回 true , 否则返回 false
         * 
         */

        return isType(data, 'function');

    }

    return function(data) {


        if (!var_init_locked_1557128179314) {

            isType = include('is.type');

            var_init_locked_1557128179314 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::is.empty'] = (() => {

    let isArray;

    let var_init_locked_1557128179319;





    function main(data, allowEmptyString) {

        /**
         * 
         * 判定数据是否为空
         * 
         * @import is.array
         * 
         * @param {mixed} data 检验数据
         * 
         * @param {boolean} [allowEmptyString = false] 是否视空符串不为空，默认空符串为空
         * 
         * @return {mixed} 如果给定值为空则返回 true , 否则返回 false  
         * 
         */

        return (data == null) || (!allowEmptyString ? data === '' : false) || (isArray(data) && data.length === 0);

    }

    return function(data, allowEmptyString = false) {


        if (!var_init_locked_1557128179319) {

            isArray = include('is.array');

            var_init_locked_1557128179319 = true;
        }




        return main.call(this, data, allowEmptyString);
    };

})();

exports['src::array.from'] = (() => {

    let isEmpty, isString;

    let var_init_locked_1557128179323;





    function main(data) {

        /**
         * 
         * 将非数组数据打包成数组数据
         * 
         * @import is.empty
         * 
         * @import is.string
         * 
         * @param {mixed} data 数据
         * 
         * @return {array} 数组数据
         * 
         */

        if (isEmpty(data)) {

            return [];
        }

        if (data && data.length !== undefined && !isString(data)) {

            return Array.from(data);

        }

        return [
            data
        ];

    }

    return function(data) {


        if (!var_init_locked_1557128179323) {

            isEmpty = include('is.empty');
            isString = include('is.string');

            var_init_locked_1557128179323 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::class.create'] = (() => {

    let isString, isObject;

    let var_init_locked_1557128179328;





    function main(namespace, options) {


        /**
         * 
         * 实例基于指定类对象
         * 
         * @import is.string
         * 
         * @import isObject from is.object.simple
         * 
         * @param {string} namespace 命名空间
         * 
         * @param {mixed} options 实例参数
         * 
         * @return {mixed} 类实例 
         * 
         */


        if (isString(options)) {

            return include(`${namespace}.${options}`)();

        } else if (isObject(options)) {

            let {
                name,
                ...currentOptions
            } = options;

            return include(`${namespace}.${name}`)(currentOptions);
        }

        return options;

    }

    return function(namespace, options) {


        if (!var_init_locked_1557128179328) {

            isString = include('is.string');
            isObject = include('is.object.simple');

            var_init_locked_1557128179328 = true;
        }




        return main.call(this, namespace, options);
    };

})();

exports['src::data.model.get'] = (() => {

    let create;

    let var_init_locked_1557128179331;





    function main(model) {


        /**
         * 
         * 获取数据模型类引用
         * 
         * @import create from class.create
         * 
         * @param {mixed} model 数据模型名称
         * 
         * @return {data.Model} 模型类引用
         * 
         */

        return create('data.model', model);

    }

    return function(model) {


        if (!var_init_locked_1557128179331) {

            create = include('class.create');

            var_init_locked_1557128179331 = true;
        }




        return main.call(this, model);
    };

})();

exports['src::data.reader.json'] = (() => {

    let objectGet, isString, isFunction, arrayFrom, isEmpty, getModel;

    let var_init_locked_1557128179338;





    /**
     * 
     * JSON 数据读取器
     * 
     * @import object.get
     * 
     * @import is.string
     * 
     * @import is.function
     * 
     * @import array.from
     * 
     * @import is.empty
     * 
     * @import getModel from data.model.get
     * 
     * @param {object} [config = {}] 读取参数设置
     * 
     * @param {string} [config.rootProperty = '.'] 读取数据的根
     * 
     * @param {function} [config.model] 数据模型类
     * 
     * @return {function} 读取器所生成的解析函数
     * 
     */

    function main({
        rootProperty,
        model
    }) {

        const Model = model ? getModel(model) : getModel('empty');

        let {
            fields
        } = Model;

        return (new Function('data', `

      var me = this,
         include = me.include,
         converts = me.converts,
         createModel = me.createModel,
         get = include('object.get'),
         from = include('array.from'),
         isEmpty = include('is.empty');

      ${generate_get_root_data(rootProperty)}

      data = from(data) ;

      var result = [],
          len = data.length;

      for(var i = 0 ; i < len ; i ++){

         var item = {},
             currentItem = data[i];

         ${generate_get_field_data(fields)}

         result.push(createModel(item)) ;
      }

      return result;

    `)).bind({
            include,
            converts: fields.converts,
            createModel: data => new Model(data)
        });
    }

    function generate_get_root_data(rootProperty) {

        if (rootProperty !== '.') {

            return `data = get(data , '${rootProperty}');`;
        }

        return '';
    }

    function generate_get_field_data({
        names
    }) {

        let result = [];

        for (let name of names) {

            result.push(`item.${name} = converts.${name}(currentItem);`);

            result.push(`if(isEmpty(item.${name})){

         delete item.${name};
      
      }`);
        }

        return result.join('');
    }

    return function({
        rootProperty = '.',
        model
    } = {}) {


        if (!var_init_locked_1557128179338) {

            objectGet = include('object.get');
            isString = include('is.string');
            isFunction = include('is.function');
            arrayFrom = include('array.from');
            isEmpty = include('is.empty');
            getModel = include('data.model.get');

            var_init_locked_1557128179338 = true;
        }




        return main.call(this, {
            rootProperty,
            model
        });
    };

})();

exports['src::data.connection.ajax'] = (() => {

    let append, apply, isObject, createReader;

    let var_init_locked_1557128179346;





    function main(url, {
        method,
        query,
        params,
        path,
        requestJSON
    }) {


        /**
         * 
         * 基于 AJAX 进行数据交互
         * 
         * @import append from url.append
         * 
         * @import apply from url.template.apply
         * 
         * @import isObject from is.object.simple
         * 
         * @import createReader from data.reader.json
         * 
         * @require axios
         * 
         * @require qs
         * 
         * @param {string} url 请求路径
         * 
         * @param {object} [config] 请求配置
         * 
         * @param {string} [config.method = 'GET'] 请求方式，默认是 GET 请求
         * 
         * @param {object} [config.query] GET请求的参数集合
         * 
         * @param {object} [config.params = {}] 请求主体的参数集合
         * 
         * @param {object} [config.path] 以路径参数形式提交的参数集合
         * 
         * @param {boolean} [config.requestJSON = true] 是否以 JSON方式提交数据
         * 
         */

        if (query) {

            url = append(url, query);
        }

        if (path) {

            url = apply(url, path);
        }

        const axios = require('axios'),
            {
                stringify
            } = require('qs');

        switch (method) {

            case 'GET':
            case 'DELETE':

                url = append(url, params);

                break;

            case 'POST':
            case 'PUT':

                if (requestJSON === false) {

                    params = stringify(params);
                }
        }

        return axios[method.toLowerCase()](url, params).then(({
            data
        }) => data);



    }

    return function(url, {
        method = 'GET',
        query,
        params = {},
        path,
        requestJSON = true
    }) {


        if (!var_init_locked_1557128179346) {

            append = include('url.append');
            apply = include('url.template.apply');
            isObject = include('is.object.simple');
            createReader = include('data.reader.json');

            var_init_locked_1557128179346 = true;
        }




        return main.call(this, url, {
            method,
            query,
            params,
            path,
            requestJSON
        });
    };

})();

exports['src::data.connection.socket'] = (() => {

    let get;

    let var_init_locked_1557128179354;

    let var_class_1557128179354;

    return function() {


        if (!var_init_locked_1557128179354) {

            get = include('object.get');

            var_init_locked_1557128179354 = true;
        }



        if (!var_class_1557128179354) {


            /**
             * 
             * Socket 消息机
             * 
             * @import get from object.get
             * 
             * @param {mixed} options Socket 初始化配置
             * 
             * @class
             * 
             */

            class main {

                constructor(options) {

                    let me = this;

                    me.init(options);

                    me.subscribers = new Map();
                }

                /**
                 * 
                 * 初始化 Socket
                 * 
                 * @param {mixed} options 初始化 Socket 参数
                 *  
                 */
                init(options) {

                }

                /**
                 * 
                 * 接收来自服务器端的消息推送,推送可能是配置式，也可能是参数式
                 * 
                 * @param {mixed} msg 接收消息
                 * 
                 */
                acceptMessage(...args) {

                    let me = this;

                    msg = me.processMessage(...args);

                    if (me.isAcceptMessage(msg) === false) {

                        return;
                    }

                    let {
                        subscribers
                    } = me;

                    subscribers.forEach(subscriber => {

                        if (subscriber.validate(msg)) {

                            subscriber.accept(msg);
                        }

                    });
                }

                /**
                 * 
                 * 判断给定消息是否可接受
                 * 
                 * @param {mixed} msg 消息
                 * 
                 * @return {boolean} 如果可接受消息则返回 true , 否则返回 false
                 * 
                 */
                isAcceptMessage(msg) {

                    return false;
                }

                /**
                 * 
                 * 针对消息进行处理
                 * 
                 * @param {mixed} ...args 消息
                 * 
                 * @return {mixed}
                 *  
                 */
                processMessage(...args) {

                    return {};
                }

                get subscribeParamNames() {

                    return [];
                }

                /**
                 * 
                 * 根据参数生成一个唯一的键值
                 * 
                 * @param {mixed} params 订阅参数
                 * 
                 * @return {string} 
                 */
                generateSubscriberKey(params) {

                    let keys = this.subscribeParamNames,
                        result = [];

                    for (let key of keys) {

                        let value = get(params, key);

                        result.push(`${key}=${JSON.stringify(value)}`);
                    }

                    return result.join('&');
                }

                /**
                 * 
                 * 判断指定指阅参数是否还有订阅器在使用
                 * 
                 * @param {mixed} params 远程订阅参数
                 * 
                 * @return {boolean} 如果还有订阅器在使用则返回 true , 否则返回 false
                 *  
                 */
                hasSubscribeRemoteParams(params) {

                    let me = this,
                        {
                            subscribers
                        } = me,
                        key = me.generateSubscriberKey(params);

                    subscribers = subscribers.values();

                    for (let subscriber of subscribers) {

                        if (me.generateSubscriberKey(subscriber.remoteParams) === key) {

                            return true;
                        }
                    }

                    return false;
                }

                /**
                 * 
                 * 根据订阅参数获得订阅器
                 * 
                 * @param {mixed} params 订阅参数
                 * 
                 * @return {data.connection.socket.Subscriber} 订阅器
                 * 
                 */
                getSubscriber(params) {

                    let me = this,
                        key = me.generateSubscriberKey(params),
                        {
                            subscribers
                        } = me;

                    if (!subscribers.has(key)) {

                        subscribers.set(key, me.createSubscriber(params));
                    }

                    return subscribers.get(key);
                }

                /**
                 * 
                 * 创建订阅器
                 * 
                 * @param {mixed} params 订阅参数
                 * 
                 * @return {data.connection.socket.Subscriber} 订阅器
                 * 
                 */
                createSubscriber(params) {}

                /**
                 * 
                 * 根据订阅参数获得订阅器
                 * 
                 * @param {mixed} params 订阅参数
                 * 
                 * @return {data.connection.socket.Subscriber} 订阅器
                 * 
                 */
                removeSubscriber(params) {

                    let me = this,
                        key = me.generateSubscriberKey(params),
                        {
                            subscribers
                        } = me;

                    if (subscribers.has(key)) {

                        let subscriber = subscribers.get(key);

                        subscribers.delete(key);

                        return subscriber;
                    }
                }

                /**
                 * 
                 * 订阅参数至服务器
                 * 
                 * @param {mixed} params 订阅参数
                 * 
                 */
                doSubscribe(params) {}

                /**
                 * 
                 * 取消订阅参数至服务器
                 * 
                 * @param {mixed} params 订阅参数 
                 * 
                 */
                doUnsubscribe(params) {}

                /**
                 * 
                 * 处理订阅参数
                 * 
                 * @param  {mixed} ...args 订阅参数
                 *  
                 */
                processSubscribeParams(...args) {

                    return {};
                }

                /**
                 * 
                 * 订阅
                 * 
                 */
                subscribe(...args) {

                    let me = this,
                        {
                            remoteParams
                        } = me.getSubscriber(me.processSubscribeParams(...args));

                    me.doSubscribe(remoteParams);
                }

                /**
                 * 
                 * 取消订阅
                 * 
                 * 
                 */
                unsubscribe(...args) {

                    let me = this,
                        {
                            remoteParams
                        } = me.removeSubscriber(me.processSubscribeParams(...args));

                    if (!me.hasSubscribeRemoteParams(remoteParams)) {

                        me.doUnsubscribe(remoteParams);
                    }
                }
            }

            var_class_1557128179354 = main;
        }


        return var_class_1557128179354;
    };

})();

exports['src::data.connection.socket.io'] = (() => {

    let Socket;

    let var_init_locked_1557128179359;

    let var_class_1557128179359;

    return function() {


        if (!var_init_locked_1557128179359) {

            Socket = include('src::data.connection.socket')();

            var_init_locked_1557128179359 = true;
        }



        if (!var_class_1557128179359) {

            /**
             * 
             * 基于 socket.io 标准进行开发
             * 
             * @import Socket from ....socket value
             * 
             * @require socket.io-client
             * 
             * @param {mixed} options Socket 初始化配置
             * 
             * @class
             * 
             */

            const IO = require('socket.io-client');

            class main extends Socket {

                init({
                    url,
                    options
                }) {

                    let me = this,
                        {
                            messageEventName,
                            onMessageEvent
                        } = me,
                        socket = me.socket = IO(url, {
                            transports: [
                                'websocket',
                                'polling'
                            ],
                            ...options
                        });

                    socket.on(messageEventName, onMessageEvent.bind(me));
                }

                get connected() {

                    let {
                        socket
                    } = this;

                    return socket.connected;
                }

                onMessageEvent(...args) {

                    this.acceptMessage(...args);
                }

                get messageEventName() {

                    return 'msg';
                }


                get subscribeEventName() {

                    return 'sub';
                }

                get unsubscribeEventName() {

                    return 'unsub';
                }

                doEmit(socket, event, params) {

                    socket.emit(event, params);
                }

                emit(event, params) {

                    let me = this,
                        {
                            connected,
                            socket
                        } = me;

                    if (connected) {

                        me.doEmit(socket, event, params);

                    } else {

                        const emitFn = () => me.emit(event, params);

                        socket.once('connect', emitFn);

                        socket.once('reconnect', emitFn);
                    }
                }

                doSubscribe(params) {

                    let me = this,
                        {
                            subscribeEventName
                        } = me;

                    me.emit(subscribeEventName, params);
                }

                doUnsubscribe(params) {

                    let me = this,
                        {
                            unsubscribeEventName
                        } = me;

                    me.emit(unsubscribeEventName, params);
                }
            }

            var_class_1557128179359 = main;
        }


        return var_class_1557128179359;
    };

})();

exports['src::data.connection.socket.standard'] = (() => {

    let createTimer;

    let var_init_locked_1557128179365;





    /**
     * 
     * 基于标准 WebSocket 进行开发
     * 
     * @import createTimer from timer
     * 
     * @param {string} url socket 连接地址
     * 
     * @param {object} config socket 连接配置
     * 
     */

    function main(url, options = {}) {

        return new Socket(url, options);
    }

    const EventEmitter = require('events');

    class Socket extends EventEmitter {

        constructor(url, options) {

            super();

            let me = this;

            me.url = url;

            me.options = options;

            let {
                timeout = 20000,
                    parse
            } = options;

            me.timer = createTimer(timeout);

            createSocket.call(me);

            let {
                socket
            } = me;

            socket.addEventListener('message', ({
                data
            }) => {

                let {
                    event,
                    params
                } = parse(data);

                me.emit(event, params);

            });

            let onException = () => reconnect.call(me);

            me.once('connect', () => {

                socket.addEventListener('error', onException);

                socket.addEventListener('close', onException);

            });
        }

        get connected() {

            let {
                socket
            } = this;

            return socket.readyState === 1;
        }

        emit(event, ...args) {

            let me = this,
                {
                    connected,
                    options,
                    socket
                } = me,
                {
                    stringify
                } = options;

            if (connected) {

                socket.send(stringify(event, args));

            } else {

                me.on('connect', () => me.emit(event, ...args));
            }
        }

        on(eventName, fn) {

            this.addListener(eventName, fn);
        }
    }

    function reconnect() {

        let me = this;

        if (me.connected) {

            me.socket.close();
        }

        return createSocket.call(me);
    }

    function createSocket() {

        let me = this,
            socket = me.socket = new WebSocket(url),
            {
                timer
            } = me,
            onConnectError = () => me.emit('connect_error');

        timer.start();

        timer.on('timeout', () => me.emit('connect_timeout'));

        socket.addEventListener('open', () => {

            socket.removeEventListener('error', onConnectError);

            timer.end();

            me.emit('connect');

        });

        socket.addEventListener('error', onConnectError);

        return me.socket;
    }

    return function(url, config) {


        if (!var_init_locked_1557128179365) {

            createTimer = include('timer');

            var_init_locked_1557128179365 = true;
        }




        return main.call(this, url, config);
    };

})();

exports['src::function.empty'] = (() => {









    /**
     * 
     * 返回一个空函数
     * 
     * @scoped
     * 
     */

    const emptyFn = () => {};

    function main() {

        return emptyFn;
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::function.get'] = (() => {

    let isString, isFunction, empty;

    let var_init_locked_1557128179373;





    function main(fn, scope) {

        /**
         * 
         * 获得一个函数引用
         * 
         * @import is.string
         * 
         * @import is.function
         * 
         * @import empty from function.empty
         * 
         * @param {string | function} fn 函数描述
         * 
         * @param {mixed} [scope] 函数作用域
         * 
         * @return {function} 函数引用本身 
         * 
         */

        if (isString(fn)) {

            if (scope && scope.hasOwnProperty(fn)) {

                fn = scope[fn];

            } else {

                fn = include(fn);
            }
        }

        if (isFunction(fn)) {

            if (scope) {

                return fn.bind(scope);
            }

            return fn;
        }

        return empty();

    }

    return function(fn, scope) {


        if (!var_init_locked_1557128179373) {

            isString = include('is.string');
            isFunction = include('is.function');
            empty = include('function.empty');

            var_init_locked_1557128179373 = true;
        }




        return main.call(this, fn, scope);
    };

})();

exports['src::map.constructor'] = (() => {









    function main() {


        /**
         * 
         * 初始化 Map 对象
         * 
         */

        this.map = new Map();

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::map.size.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前 Map 的键值对数量
         * 
         * @return {number} 数量 
         * 
         */

        return this.map.size;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::map.find'] = (() => {









    function main(keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @param {array} keys 组合键
         * 
         * @return {object} 返回查询结果 
         * 
         */

        let me = this,
            {
                map
            } = me,
            currentKeys = map.keys(),
            {
                length
            } = keys;

        for (let groupKeys of currentKeys) {

            if (length === groupKeys.length) {

                let isMatch = true;

                for (let i = 0; i < length; i++) {

                    if (groupKeys[i] !== keys[i]) {

                        isMatch = false;

                        break;
                    }
                }

                if (isMatch) {

                    return {
                        match: true,
                        key: groupKeys
                    };
                }
            }
        }

        return {
            match: false
        };

    }

    return function(keys) {





        return main.call(this, keys);
    };

})();

exports['src::map.set'] = (() => {

    let find;

    let var_init_locked_1557128179385;

    let var_current_scope_1557128179385;



    function main(...values) {


        /**
         * 
         * 设置一个值
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...values] 包含多维键，以及相应值
         * 
         * @return {Map} 返回当前对象 
         * 
         */

        let me = this,
            {
                map
            } = me,
            {
                length
            } = values;

        if (length >= 2) {

            let keys = values.slice(0, length - 1),
                value = values[length - 1],
                {
                    match,
                    key
                } = find(keys);

            if (match) {

                map.set(key, value);

            } else {

                map.set(keys, value);
            }
        }

        return me;

    }

    return function(...values) {




        if (!var_current_scope_1557128179385 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1557128179385 = this;
        }


        return main.call(this, ...values);
    };

})();

exports['src::map.get'] = (() => {

    let find;

    let var_init_locked_1557128179389;

    let var_current_scope_1557128179389;



    function main(...keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let me = this,
            {
                map
            } = me;

        let {
            match,
            key
        } = find(keys);

        if (match) {

            return map.get(key);
        }

    }

    return function(...keys) {




        if (!var_current_scope_1557128179389 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1557128179389 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.has'] = (() => {

    let find;

    let var_init_locked_1557128179391;

    let var_current_scope_1557128179391;



    function main(...keys) {


        /**
         * 
         * 判断指定组合键是否存在
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let {
            match
        } = find(keys);

        return match;

    }

    return function(...keys) {




        if (!var_current_scope_1557128179391 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1557128179391 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.delete'] = (() => {

    let find;

    let var_init_locked_1557128179395;

    let var_current_scope_1557128179395;



    function main(...keys) {



        /**
         * 
         * 删除指定组合键
         * 
         * @import find from .find scoped
         * 
         * @param {array} [...keys] 组合键
         * 
         * @return {boolean} 如果组合键存在，则返回 true , 否则返回 false 
         * 
         */

        let me = this,
            {
                map
            } = me;

        let {
            match,
            key
        } = find(keys);

        if (match) {

            return map.delete(key);
        }

        return false;

    }

    return function(...keys) {




        if (!var_current_scope_1557128179395 !== this) {

            find = include('src::map.find').bind(this);

            var_current_scope_1557128179395 = this;
        }


        return main.call(this, ...keys);
    };

})();

exports['src::map.forEach'] = (() => {









    function main(fn, scope) {


        /**
         * 
         * 实现迭代
         * 
         * @param {function} fn 函数引用
         * 
         * @param {mixed} scope 函数作用域
         * 
         */

        let {
            map
        } = this;

        map.forEach(fn, scope);

    }

    return function(fn, scope) {





        return main.call(this, fn, scope);
    };

})();

exports['src::map.clear'] = (() => {









    function main(data) {


        /**
         * 
         * 函数实现说明
         * 
         * @param {mixed} data 参数说明
         * 
         * @return {mixed} 返回说明 
         * 
         */

        // 代码实现

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::map'] = (() => {

    let extend, constructor, get_size, method_set, method_get, method_has, method_delete, method_forEach, method_clear;

    let var_init_locked_1557128179403;

    let var_class_1557128179403;

    return function() {


        if (!var_init_locked_1557128179403) {

            extend = include('class.empty')();
            constructor = include('src::map.constructor');
            get_size = include('src::map.size.get');
            method_set = include('src::map.set');
            method_get = include('src::map.get');
            method_has = include('src::map.has');
            method_delete = include('src::map.delete');
            method_forEach = include('src::map.forEach');
            method_clear = include('src::map.clear');

            var_init_locked_1557128179403 = true;
        }



        if (!var_class_1557128179403) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                set(...args) {

                    return method_set.apply(this, args);

                }
                get(...args) {

                    return method_get.apply(this, args);

                }
                has(...args) {

                    return method_has.apply(this, args);

                }
                delete(...args) {

                    return method_delete.apply(this, args);

                }
                forEach(...args) {

                    return method_forEach.apply(this, args);

                }
                clear(...args) {

                    return method_clear.apply(this, args);

                }

                get size() {

                    return get_size.call(this);

                }

            }

            var_class_1557128179403 = main;
        }


        return new var_class_1557128179403();
    };

})();

exports['src::data.connection.socket.subscriber'] = (() => {

    let get, isArray, createMap;

    let var_init_locked_1557128179409;

    let var_class_1557128179409;

    return function() {


        if (!var_init_locked_1557128179409) {

            get = include('function.get');
            isArray = include('is.array');
            createMap = include('map');

            var_init_locked_1557128179409 = true;
        }



        if (!var_class_1557128179409) {


            /**
             * 
             * Socket 订阅器
             * 
             * @import get from function.get
             * 
             * @import is.array
             * 
             * @import createMap from map
             * 
             * @param {object} options 订阅参数
             * 
             * @param {object} options.params  订阅参数
             * 
             * @param {object} [options.saveLastMessage = true] 订阅器配置
             * 
             * @param {mixed} [options.fn] 绑定函数
             * 
             * @param {mixed} [options.scope] 绑定函数作用域
             * 
             * @class
             * 
             */

            class main {

                constructor({
                    params,
                    saveLastMessage,
                    fn,
                    scope
                }) {

                    let me = this;

                    if (saveLastMessage === false) {

                        me.data = [];
                    }

                    me.params = params;

                    me.callbacks = createMap();

                    if (fn) {

                        me.bind(fn, scope);
                    }
                }

                /**
                 * 
                 * 校验推送数据是否满足当前订阅的要求
                 * 
                 * @param {mixed} msg 数据
                 * 
                 * @return {boolean} 如果检验数据成功则返回 true , 否则返回 false
                 * 
                 */
                validate(msg) {

                    return false;
                }

                /**
                 * 
                 * 将订阅推送过来的数据注入到订阅器
                 * 
                 * @param {mixed} data 
                 * 
                 */
                accept(message) {

                    let me = this,
                        {
                            data
                        } = me;

                    if (isArray(data)) {

                        data.push(message);

                    } else {

                        me.data = message;
                    }

                    let {
                        callbacks
                    } = me;

                    callbacks.forEach(fn => fn(message));
                }

                /**
                 * 
                 * 将注入到订阅器的数据推送给函数
                 * 
                 * @param {mixed} fn 函数
                 * 
                 * @param {mixed} scope 函数作用域
                 * 
                 */
                bind(fn, scope) {

                    let me = this,
                        {
                            callbacks
                        } = me,
                        bindFn = get(fn, scope),
                        {
                            data
                        } = me;

                    callbacks.set(fn, scope, bindFn);

                    if (isArray(data)) {

                        for (let message of data) {

                            bindFn(message);
                        }

                    } else if (data) {

                        bindFn(data);
                    }
                }

                unbind(fn, scope) {

                    let {
                        callbacks
                    } = this;

                    callbacks.delete(fn, scope);
                }

                /**
                 * 
                 * 返回实际的订阅参数
                 * 
                 * @return {object}
                 * 
                 */
                get remoteParams() {

                    return this.params;
                }
            }

            var_class_1557128179409 = main;
        }


        return var_class_1557128179409;
    };

})();

exports['src::object.keys'] = (() => {

    let isObject;

    let var_init_locked_1557128179414;





    /**
     * 
     * 获取对象的键值组合
     * 
     * @import isObject from is.object.simple
     * 
     * @param {object} data 对象
     * 
     * @return {array} 键值数组
     * 
     * @scoped
     * 
     */

    function main(data) {

        return get_keys(data);
    }

    function get_keys(data, rootKey = '') {

        let keys = Object.keys(data),
            result = [];

        for (let key of keys) {

            let value = data[key];

            if (isObject(value)) {

                result.push(...get_keys(value, `${rootKey}${key}.`));

            } else {

                result.push(`${rootKey}${key}`);
            }
        }

        return result;
    }


    return function(data) {


        if (!var_init_locked_1557128179414) {

            isObject = include('is.object.simple');

            var_init_locked_1557128179414 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::object.equals'] = (() => {

    let keys, get;

    let var_init_locked_1557128179417;





    function main(value1, value2) {

        /**
         * 
         * 匹配两个对象数据是否匹配
         * 
         * @import keys from object.keys
         * 
         * @import get from object.get
         * 
         * @param {object} value1 第一个对象数据
         * 
         * @param {object} value2 第二个对象数据
         * 
         * @return {boolean} 如果对象数据匹配则返回 true ， 否则返回 false
         * 
         */

        let keys1 = keys(value1),
            keys2 = keys(value2);

        if (keys1.length !== keys2.length) {

            return false;
        }

        for (let key of keys1) {

            if (!keys2.includes(key) || get(value1, key) !== get(value2, key)) {

                return false;
            }
        }

        return true;

    }

    return function(value1, value2) {


        if (!var_init_locked_1557128179417) {

            keys = include('object.keys');
            get = include('object.get');

            var_init_locked_1557128179417 = true;
        }




        return main.call(this, value1, value2);
    };

})();

exports['src::map.set.multi'] = (() => {

    let isArray;

    let var_init_locked_1557128179421;





    function main(map, ...values) {


        /**
         * 
         * 设置复合值
         * 
         * @import is.array
         * 
         * @param {Map} map Map 对象
         * 
         * @param {array} [...values] 包含多维键，以及相应值
         * 
         * @return {Map} 返回 Map 对象引用
         * 
         */

        let {
            length
        } = values;

        if (length >= 2) {

            let key = values.slice(0, length - 1),
                value = values[length - 1],
                oldValues = map.get(...key);

            if (isArray(oldValues)) {

                if (!oldValues.includes(value)) {

                    oldValues.push(value);
                }

            } else {

                oldValues = [
                    value
                ];
            }

            map.set(...key, oldValues);
        }

        return map;



    }

    return function(map, ...values) {


        if (!var_init_locked_1557128179421) {

            isArray = include('is.array');

            var_init_locked_1557128179421 = true;
        }




        return main.call(this, map, ...values);
    };

})();

exports['src::is.number'] = (() => {

    let isType;

    let var_init_locked_1557128179423;





    function main(data) {

        /**
         * 
         * 判定数据是否为数值类型
         * 
         * @import is.type
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为数值类型则返回 true , 否则返回 false 
         * 
         */

        return isType(data, 'number') && isFinite(data);

    }

    return function(data) {


        if (!var_init_locked_1557128179423) {

            isType = include('is.type');

            var_init_locked_1557128179423 = true;
        }




        return main.call(this, data);
    };

})();

exports['src::math.region.rect.constructor'] = (() => {









    function main({
        x,
        y,
        width,
        height
    }) {


        /**
         * 
         * 初始化一个矩形计算区域
         * 
         * @param {object} config 区域配置
         * 
         * @param {number} config.x 区域横坐标
         * 
         * @param {number} config.y 区域纵坐标
         * 
         * @param {number} config.width 区域宽度
         * 
         * @param {number} config.height 区域高度
         * 
         */

        let me = this;

        me.x = x;

        me.y = y;

        me.width = width;

        me.height = height;

    }

    return function({
        x,
        y,
        width,
        height
    }) {





        return main.call(this, {
            x,
            y,
            width,
            height
        });
    };

})();

exports['src::math.region.rect.getAnchorXY'] = (() => {









    function main(anchor) {


        /**
         * 
         * 计算当前区域锚点坐标
         * 
         * @param {string} [anchor = 'tl'] 锚点信息
         * 
         * @return {object} 坐标值 
         * 
         */

        let {
            x,
            y,
            width,
            height
        } = this;

        switch (anchor) {

            case 'tl':

                return {
                    x,
                    y
                };

            case 'r':

                return {
                    x: x + width,
                    y: y + height / 2
                };

            case 'l':

                return {
                    x,
                    y: y + height / 2
                };

            case 't':

                return {
                    x: x + width / 2,
                    y
                };

            case 'b':

                return {
                    x: x + width / 2,
                    y: y + height
                }
        }

    }

    return function(anchor = 'tl') {





        return main.call(this, anchor);
    };

})();

exports['src::math.region.rect'] = (() => {

    let extend, constructor, method_getAnchorXY;

    let var_init_locked_1557128179432;

    let var_class_1557128179432;

    return function(config) {


        if (!var_init_locked_1557128179432) {

            extend = include('class.empty')();
            constructor = include('src::math.region.rect.constructor');
            method_getAnchorXY = include('src::math.region.rect.getAnchorXY');

            var_init_locked_1557128179432 = true;
        }



        if (!var_class_1557128179432) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                getAnchorXY(...args) {

                    return method_getAnchorXY.apply(this, args);

                }



            }

            var_class_1557128179432 = main;
        }


        return new var_class_1557128179432(config);
    };

})();

exports['src::string.split'] = (() => {

    let isEmpty;

    let var_init_locked_1557128179435;






    /**
     * 
     * 将字符串通过间隔符分隔成数组
     * 
     * @import is.empty
     * 
     * @param {String} target 字符串
     * 
     * @param {RegEx} splitRe 字符串分隔符
     * 
     * @scoped
     * 
     */

    function main(target, splitRe) {

        return target.split(splitRe).filter(filter);
    }

    function filter(target) {

        return !isEmpty(target);
    }

    return function(target, splitRe) {


        if (!var_init_locked_1557128179435) {

            isEmpty = include('is.empty');

            var_init_locked_1557128179435 = true;
        }




        return main.call(this, target, splitRe);
    };

})();

exports['src::object.set'] = (() => {

    let isObject, split;

    let var_init_locked_1557128179437;





    /**
     * 
     * 设置对象的属性值
     * 
     * @import is.object
     * 
     * @import split from string.split
     * 
     * @param {object} target 目标对象
     * 
     * @param {string} key 属性名称
     * 
     * @param {mixed} value 属性值
     * 
     * @scoped
     * 
     */

    const splitRe = /\./;

    function main(target, key, value) {

        if (splitRe.test(key)) {

            let keys = split(key, splitRe);

            key = keys.pop();

            for (let key of keys) {

                let data = target[key];

                if (!isObject(data)) {

                    data = target[key] = {};
                }

                target = data;
            }

            target[key] = value;

        } else {

            target[key] = value;
        }
    }

    return function(target, key, value) {


        if (!var_init_locked_1557128179437) {

            isObject = include('is.object');
            split = include('string.split');

            var_init_locked_1557128179437 = true;
        }




        return main.call(this, target, key, value);
    };

})();

exports['src::object.assign'] = (() => {

    let getKeys, set, get;

    let var_init_locked_1557128179440;






    /**
     * 
     * 深度合并
     * 
     * @import getKeys from object.keys
     * 
     * @import set from object.set
     * 
     * @import get from object.get
     * 
     * @param {object} dest 目标数据
     * 
     * @param {object} [...sources] 来源数据
     * 
     * @return {object} 合并后数据
     * 
     * @scoped
     * 
     */

    function assign(dest, source) {

        let keys = getKeys(source);

        for (let key of keys) {

            set(dest, key, get(source, key));
        }

    }

    function main(dest, ...sources) {

        for (let source of sources) {

            assign(dest, source);
        }

        return dest;

    }

    return function(dest, ...sources) {


        if (!var_init_locked_1557128179440) {

            getKeys = include('object.keys');
            set = include('object.set');
            get = include('object.get');

            var_init_locked_1557128179440 = true;
        }




        return main.call(this, dest, ...sources);
    };

})();

exports['src::canvas.draw.line.bezierCurve'] = (() => {

    let assign;

    let var_init_locked_1557128179444;





    function main(context, {
        points,
        ...styles
    }) {


        /**
         * 
         * 绘制贝赛尔曲线
         * 
         * @import assign from object.assign
         * 
         * @param {canvas.Context} context 画板的上下文对象
         * 
         * @param {object} [config = {}] 画线配置
         * 
         * @param {array} [config.points = []] 画线点集合
         * 
         * @param {object} [...config.styles] 画线样式
         * 
         */

        if (points.length === 8) {

            context.beginPath();

            assign(context, styles);

            context.moveTo(...points.slice(0, 2));

            context.bezierCurveTo(...points.slice(2));

            context.stroke();
        }

    }

    return function(context, {
        points = [],
        ...styles
    } = {}) {


        if (!var_init_locked_1557128179444) {

            assign = include('object.assign');

            var_init_locked_1557128179444 = true;
        }




        return main.call(this, context, {
            points,
            ...styles
        });
    };

})();

exports['src::math.degree2radian'] = (() => {









    function main(degree) {


        /**
         * 
         * 将角度转换成弧度
         * 
         * @param {number} degree 角度
         * 
         * @return {number} 弧度 
         * 
         */

        return Math.PI / 180 * degree;


    }

    return function(degree) {





        return main.call(this, degree);
    };

})();

exports['src::canvas.draw.line.arc'] = (() => {

    let assign, degree2radian;

    let var_init_locked_1557128179451;





    function main(context, {
        x,
        y,
        r,
        start,
        end,
        counterclockwise,
        ...styles
    }) {


        /**
         * 
         * 绘制弧线
         * 
         * @import assign from object.assign
         * 
         * @import degree2radian from math.degree2radian
         * 
         * @param {canvas.Context} context 画板的上下文对象
         * 
         * @param {object} [config = {}] 画线配置
         * 
         * @param {number} config.x 圆中心点横坐标
         * 
         * @param {number} config.y 圆中心点纵坐标
         * 
         * @param {number} config.r 圆的半径
         * 
         * @param {number} [config.start = -90] 圆起始角度
         * 
         * @param {number} config.end 圆终止角度
         * 
         * @param {number} [config.counterclockwise = false] 如果为 false 则为顺时针，反之为逆时针
         * 
         * @param {object} [...config.styles] 画线样式
         * 
         */

        context.beginPath();

        assign(context, styles);

        context.arc(x, y, r, degree2radian(start), degree2radian(end), counterclockwise);

        context.stroke();

    }

    return function(context, {
        x,
        y,
        r,
        start = -90,
        end,
        counterclockwise = false,
        ...styles
    } = {}) {


        if (!var_init_locked_1557128179451) {

            assign = include('object.assign');
            degree2radian = include('math.degree2radian');

            var_init_locked_1557128179451 = true;
        }




        return main.call(this, context, {
            x,
            y,
            r,
            start,
            end,
            counterclockwise,
            ...styles
        });
    };

})();

exports['src::object.proxy'] = (() => {










    /**
     * 
     * 对象代理，如果对象没有需要的方法或者属性时，则会抛出异常
     * 
     * @param {mixed} target 需要代理的对象
     * 
     * @return {object.Proxy} 代理对象引用 
     * 
     */

    function main(target) {

        return new Proxy(target);
    }

    class Proxy {

        constructor(target) {

            this.target = target;
        }

        call(method, ...args) {

            let {
                target
            } = this;

            if (method in target) {

                return target[method](...args);

            } else {

                throw new ProxyMethodNotFoundError(target, method);
            }
        }

        callIf(method, ...args) {

            let {
                target
            } = this;

            if (method in target) {

                return target[method](...args);
            }
        }

        set(name, value) {

            let {
                target
            } = this;

            if (name in target) {

                target[name] = value;

            } else {

                throw new ProxyPropertyNotFoundError(target, name, 'set');
            }
        }

        setIf(name, value) {

            let {
                target
            } = this;

            if (name in target) {

                target[name] = value;

            }
        }

        get(name) {

            let {
                target
            } = this;

            if (name in target) {

                return target[name];

            } else {

                throw new ProxyPropertyNotFoundError(target, name, 'get');
            }
        }

        getIf(name) {

            let {
                target
            } = this;

            if (name in target) {

                return target[name];

            }
        }

        fireEvent(name, ...args) {

            let {
                target
            } = this;

            if ('fireEvent' in target) {

                target.fireEvent(name, ...args);
            }
        }
    }

    class ProxyMethodNotFoundError extends Error {

        constructor(target, method) {

            super(`无法访问名称为 ${method} 的方法`);

            let me = this;

            me.proxyTarget = target;

            me.proxyMethod = method;

        }
    }

    class ProxyPropertyNotFoundError extends Error {

        constructor(target, property, mode) {

            let modeMessage;

            switch (mode) {

                case 'set':

                    modeMessage = '设置';

                    break;

                case 'get':

                    modeMessage = '获取';
            }

            super(`无法${modeMessage}名称为 ${property} 的属性`);

            let me = this;

            me.proxyTarget = target;

            me.proxyProperty = property;

        }
    }

    return function(target) {





        return main.call(this, target);
    };

})();

exports['src::date.get'] = (() => {

    let isDefined;

    let var_init_locked_1557128179459;





    function main({
        year,
        month,
        day,
        hours,
        minutes,
        seconds
    }) {


        /**
         * 
         * 获得日期对象
         * 
         * @import is.defined
         * 
         * @param {object} [config = {}] 日期配置
         * 
         * @param {number} [config.year] 年份
         * 
         * @param {number} [config.month] 月份
         * 
         * @param {number} [config.day] 日
         * 
         * @param {number} [config.hours] 小时
         * 
         * @param {number} [config.minutes] 分钟
         * 
         * @param {number} [config.seconds] 秒
         * 
         * @return {Date} 日期对象 
         * 
         */

        let data = new Date();

        data.setMonth(0);

        data.setDate(1);

        if (isDefined(year)) {

            data.setFullYear(year);
        }

        if (isDefined(month)) {

            data.setMonth(month - 1);
        }

        if (isDefined(day)) {

            data.setDate(day);

        }

        if (isDefined(hours)) {

            data.setHours(hours);
        }

        if (isDefined(minutes)) {

            data.setMinutes(minutes);
        }

        if (isDefined(seconds)) {

            data.setSeconds(seconds);
        }

        return data;



    }

    return function({
        year,
        month,
        day,
        hours,
        minutes,
        seconds
    } = {}) {


        if (!var_init_locked_1557128179459) {

            isDefined = include('is.defined');

            var_init_locked_1557128179459 = true;
        }




        return main.call(this, {
            year,
            month,
            day,
            hours,
            minutes,
            seconds
        });
    };

})();

exports['src::week.days'] = (() => {









    function main(startDay) {


        /**
         * 
         * 获得一周周期排列
         * 
         * @param {number} [startDay = 0] 确定起始周几
         * 
         * @return {array} 一周周期排列数字集合
         * 
         */

        let result = [
            startDay
        ];

        while (result.length < 7) {

            startDay++;

            if (startDay <= 6) {

                result.push(startDay);

            } else {

                result.push(startDay = 0);
            }
        }

        return result;


    }

    return function(startDay = 0) {





        return main.call(this, startDay);
    };

})();

exports['src::date.get.properties'] = (() => {

    let from;

    let var_init_locked_1557128179464;





    function main(date, names) {


        /**
         * 
         * 获得指定日期的属性值
         * 
         * @import from from array.from
         * 
         * @param {Date} date 日期对象
         * 
         * @param {string[]} [names] 属性名称集合
         * 
         * @return {object} 日期描述
         * 
         */

        names = from(names);

        let result = {};

        for (name of names) {

            let value;

            switch (name) {

                case 'year':

                    value = date.getFullYear();

                    break;

                case 'month':

                    value = date.getMonth() + 1;

                    break;

                case 'day':

                    value = date.getDate();
            }

            result[name] = value;
        }

        return result;

    }

    return function(date, names) {


        if (!var_init_locked_1557128179464) {

            from = include('array.from');

            var_init_locked_1557128179464 = true;
        }




        return main.call(this, date, names);
    };

})();

exports['src::is.date'] = (() => {









    function main(data) {

        /**
         * 
         * 判定数据是否为日期类型
         * 
         * @param {mixed} data 检验数据
         * 
         * @return {boolean} 如果给定值为日期类型则返回 true , 否则返回 false 
         * 
         */


        return Object.prototype.toString.call(data) === '[object Date]';

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::date.prev'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1557128179468;





    function main(date, step) {

        /**
         * 
         * 基于当前日历向前移一次
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date} date 基准日期
         * 
         * @param {number} [step = 1] 步长
         * 
         * @return {Date} 移过的日期 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            day,
            ...other
        } = date;

        day -= step;

        return get({
            day,
            ...other
        });

    }

    return function(date, step = 1) {


        if (!var_init_locked_1557128179468) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1557128179468 = true;
        }




        return main.call(this, date, step);
    };

})();

exports['src::date.next'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1557128179472;





    function main(date, step) {

        /**
         * 
         * 基于当前日历向后移一次
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 基准日期
         * 
         * @param {number} [step = 1] 步长
         * 
         * @return {Date} 移过的日期 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            day,
            ...other
        } = date;

        day += step;

        return get({
            day,
            ...other
        });

    }

    return function(date, step = 1) {


        if (!var_init_locked_1557128179472) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1557128179472 = true;
        }




        return main.call(this, date, step);
    };

})();

exports['src::month.date.last'] = (() => {

    let get, prev, getLastDate;

    let var_init_locked_1557128179478;





    function main(year, month) {


        /**
         * 
         * 指定月份的最后日期
         * 
         * @import get from date.get
         * 
         * @import prev from date.prev
         * 
         * @import getLastDate from ..last
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @return {Date} 日期对象 
         * 
         */

        let date = get({
            year,
            month,
            day: 31
        });

        if (month < 1 || month > 12) {

            return getLastDate(date.getFullYear(), date.getMonth() + 1);
        }

        while (date.getMonth() + 1 !== month) {

            date = prev(date);
        }

        return date;


    }

    return function(year, month) {


        if (!var_init_locked_1557128179478) {

            get = include('date.get');
            prev = include('date.prev');
            getLastDate = include('src::month.date.last');

            var_init_locked_1557128179478 = true;
        }




        return main.call(this, year, month);
    };

})();

exports['src::calendar.month'] = (() => {

    let get, getDays, prev, next, getLastDate;

    let var_init_locked_1557128179488;





    function main(year, month, {
        row,
        weekStartDay,
        day,
        ignoreNotCurrentMonthLastRow
    }) {


        /**
         * 
         * 显示以月份显示的日历数据
         * 
         * @import get from date.get
         * 
         * @import getDays from week.days
         * 
         * @import prev from date.prev
         * 
         * @import next from date.next
         * 
         * @import getLastDate from month.date.last
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @param {object} [config = {}] 日历构造配置
         * 
         * @param {number} [config.row = 6] 日历显示行数
         * 
         * @param {number} [config.weekStartDay = 1] 每周从周几进行显示
         * 
         * @param {number} [config.day] 指定日期所在周作为日历的第一周
         * 
         * @param {boolean} [config.ignoreNotCurrentMonthLastRow = true] 是否忽略不是本月的尾行
         * 
         * @return {array} 一组日历数据 
         * 
         */


        if (!day) {

            day = 1;

        }

        let lastDay = getLastDate(year, month).getDate();

        if (day > lastDay) {

            day = lastDay;
        }

        let date = get({
            year,
            month,
            day
        });

        let days = getDays(weekStartDay),
            prevCount = days.indexOf(date.getDay()),
            nextCount = 6 - prevCount,
            result = [
                date
            ];

        let currentDate = date;

        while (prevCount-- > 0) {

            result.unshift(date = prev(date));
        }

        date = currentDate;

        while (nextCount-- > 0) {

            result.push(date = next(date));
        }

        let count = (row - 1);

        while (count-- > 0) {

            date = next(date);

            if (ignoreNotCurrentMonthLastRow && date.getMonth() + 1 !== month) {

                break;
            }

            result.push(date);

            for (let i = 0; i < 6; i++) {

                result.push(date = next(date));
            }


        }

        return result;





    }

    return function(year, month, {
        row = 6,
        weekStartDay = 1,
        day,
        ignoreNotCurrentMonthLastRow = true
    } = {}) {


        if (!var_init_locked_1557128179488) {

            get = include('date.get');
            getDays = include('week.days');
            prev = include('date.prev');
            next = include('date.next');
            getLastDate = include('month.date.last');

            var_init_locked_1557128179488 = true;
        }




        return main.call(this, year, month, {
            row,
            weekStartDay,
            day,
            ignoreNotCurrentMonthLastRow
        });
    };

})();

exports['src::calendar.month.view.deselect'] = (() => {









    function main() {


        /**
         * 
         * 清除当前日历所有选定
         * 
         */

        let me = this,
            {
                proxy,
                dates,
                selectedDate
            } = me;

        if (selectedDate) {

            selectedDate.selected = false;

            proxy.call('deselect', dates.indexOf(selectedDate), selectedDate);

        }

        delete me.selectedDate;


    }

    return function() {





        return main.call(this);
    };

})();

exports['src::calendar.month.view.select'] = (() => {

    let deselect, getLastDate, get;

    let var_init_locked_1557128179496;

    let var_current_scope_1557128179496;



    function main(year, month, day) {


        /**
         * 
         * 选定
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import getLastDate from month.date.last
         * 
         * @import get from date.get.properties
         * 
         * @param {number} year 选定年份
         * 
         * @param {number} month 选定月份
         * 
         * @param {number} day 选定日期
         * 
         */

        let me = this,
            {
                proxy,
                selectedDate,
                dates
            } = me;

        deselect();

        let {
            day: lastDay
        } = get(getLastDate(year, month), [
            'day'
        ]);

        if (day > lastDay) {

            day = lastDay;
        }

        let count = -1;

        for (let date of dates) {

            let {
                year: itemYear,
                month: itemMonth,
                day: itemDay
            } = date;

            count++;

            if (itemYear === year && itemMonth === month && itemDay === day) {

                me.selectedDate = date;

                date.selected = true;

                proxy.call('select', count, date);

                break;
            }
        }







    }

    return function(year, month, day) {


        if (!var_init_locked_1557128179496) {

            getLastDate = include('month.date.last');
            get = include('date.get.properties');

            var_init_locked_1557128179496 = true;
        }



        if (!var_current_scope_1557128179496 !== this) {

            deselect = include('src::calendar.month.view.deselect').bind(this);

            var_current_scope_1557128179496 = this;
        }


        return main.call(this, year, month, day);
    };

})();

exports['src::calendar.month.view.selectMonth'] = (() => {

    let getDates, deselect, select, getProperty;

    let var_init_locked_1557128179501;

    let var_current_scope_1557128179501;



    function main(year, month) {


        /**
         * 
         * 选定月份
         * 
         * @import getDates from ......month
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import select from ..select scoped
         * 
         * @import getProperty from date.get.properties
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         */

        let me = this,
            {
                selectedDate,
                weekStartDay,
                viewConfig
            } = me;

        deselect();

        let fields = [
                'year',
                'month',
                'day'
            ],
            dates = me.dates = getDates(year, month, {
                ...viewConfig,
                weekStartDay
            }).map(date => {

                let {
                    year: itemYear,
                    month: itemMonth,
                    day
                } = getProperty(date, fields),
                    activate = year === itemYear && month === itemMonth;

                return {
                    activate,
                    year: itemYear,
                    month: itemMonth,
                    day,
                    selected: false,
                    key: date.getTime()
                };

            });

        me.year = year;

        me.month = month;

        me.proxy.call('load', year, month, dates);

        if (selectedDate) {

            let {
                day
            } = selectedDate, {
                year,
                month
            } = me;

            select(year, month, day);
        }

    }

    return function(year, month) {


        if (!var_init_locked_1557128179501) {

            getDates = include('src::calendar.month');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179501 = true;
        }



        if (!var_current_scope_1557128179501 !== this) {

            deselect = include('src::calendar.month.view.deselect').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179501 = this;
        }


        return main.call(this, year, month);
    };

})();

exports['src::calendar.month.view.constructor'] = (() => {

    let getProxy, selectMonth, select, getProperty;

    let var_init_locked_1557128179506;

    let var_current_scope_1557128179506;



    function main(target, {
        selectedDate,
        weekStartDay,
        viewConfig
    }) {


        /**
         * 
         * 构建一个月基日历
         * 
         * @import getProxy from object.proxy
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         * @import select from ..select scoped
         * 
         * @import getProperty from date.get.properties
         * 
         * @param {mixed} target 可提供日历显示的套件
         * 
         * @param {object} [config = {}] 初始化配置
         * 
         * @param {object} [config.selectedDate] 初始化选择日期
         * 
         * @param {number} [config.weekStartDay = 0] 默认从星期天进行计算
         * 
         * @param {object} [config.viewConfig = {}] 日历视图设置
         * 
         */

        let me = this;

        me.viewConfig = viewConfig;

        me.weekStartDay = weekStartDay;

        me.proxy = getProxy(target);

        me.selectedDates = [];

        me.dates = [];

        if (!selectedDate) {

            selectedDate = getProperty(new Date(), [
                'year',
                'month',
                'day'
            ]);
        }

        let {
            year,
            month,
            day
        } = selectedDate;

        selectMonth(year, month);

        select(year, month, day);

    }

    return function(target, {
        selectedDate,
        weekStartDay = 0,
        viewConfig = {}
    } = {}) {


        if (!var_init_locked_1557128179506) {

            getProxy = include('object.proxy');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179506 = true;
        }



        if (!var_current_scope_1557128179506 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179506 = this;
        }


        return main.call(this, target, {
            selectedDate,
            weekStartDay,
            viewConfig
        });
    };

})();

exports['src::is.week.day.first'] = (() => {









    function main(date, weekStartDay) {


        /**
         * 
         * 判断指定日期是否为一周的第一天
         * 
         * @param {Date} date 校验日期
         * 
         * @param {number} [weekStartDay = 1] 确认一周是从周几算起
         *  
         * @return {boolean} 如果是第一天的话，则返回 true , 否则返回 false
         * 
         */

        return date.getDay() === weekStartDay;



    }

    return function(date, weekStartDay = 1) {





        return main.call(this, date, weekStartDay);
    };

})();

exports['src::month.prev'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1557128179512;





    function main(date) {

        /**
         * 
         * 获得指定月份的上一个月份
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 包括月份的日期对象 
         * 
         * @return {Date} 上一个月份 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month'
            ]);
        }

        let {
            month,
            ...other
        } = date;

        month--;

        console.log(month, get({
            month,
            ...other
        }).toJSON());

        return get({
            month,
            ...other
        });

    }

    return function(date) {


        if (!var_init_locked_1557128179512) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1557128179512 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectPrevMonth'] = (() => {

    let prev, getProperty, selectMonth;

    let var_init_locked_1557128179515;

    let var_current_scope_1557128179515;



    function main() {


        /**
         * 
         * 向上移动月份
         * 
         * @import prev from month.prev
         * 
         * @import getProperty from date.get.properties
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         */

        let me = this,
            {
                year,
                month
            } = me,
            {
                year: selectedYear,
                month: selectedMonth
            } = getProperty(prev({
                year,
                month
            }), [
                'year',
                'month'
            ]);

        selectMonth(selectedYear, selectedMonth);

    }

    return function() {


        if (!var_init_locked_1557128179515) {

            prev = include('month.prev');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179515 = true;
        }



        if (!var_current_scope_1557128179515 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);

            var_current_scope_1557128179515 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view.selectLeft'] = (() => {

    let isFirst, get, prevMonth, prevDate, getProperty, select;

    let var_init_locked_1557128179520;

    let var_current_scope_1557128179520;



    function main() {

        /**
         * 
         * 向左移一个格
         * 
         * @import isFirst from is.week.day.first
         * 
         * @import get from date.get
         * 
         * @import prevMonth from ..selectPrevMonth scoped
         * 
         * @import prevDate from date.prev
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            month
        } = this;

        if (selectedDate) {

            let date = get(selectedDate);

            if (isFirst(date, weekStartDay)) {

                prevMonth();

            } else {

                date = prevDate(date);

                let {
                    year: prevYearValue,
                    month: prevMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (prevMonthValue !== month) {

                    prevMonth();
                }

                select(prevYearValue, prevMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1557128179520) {

            isFirst = include('is.week.day.first');
            get = include('date.get');
            prevDate = include('date.prev');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179520 = true;
        }



        if (!var_current_scope_1557128179520 !== this) {

            prevMonth = include('src::calendar.month.view.selectPrevMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179520 = this;
        }


        return main.call(this);
    };

})();

exports['src::is.week.day.last'] = (() => {

    let getDays;

    let var_init_locked_1557128179526;





    function main(date, weekStartDay) {


        /**
         * 
         * 判断指定日期是否为一周的最后一天
         * 
         * @import getDays from week.days
         * 
         * @param {Date} date 校验日期
         * 
         * @param {number} [weekStartDay = 1] 确认一周是从周几算起
         *  
         * @return {boolean} 如果是最后一天的话，则返回 true , 否则返回 false
         * 
         */

        let days = getDays(weekStartDay);

        return date.getDay() === days[days.length - 1];

    }

    return function(date, weekStartDay = 1) {


        if (!var_init_locked_1557128179526) {

            getDays = include('week.days');

            var_init_locked_1557128179526 = true;
        }




        return main.call(this, date, weekStartDay);
    };

})();

exports['src::month.next'] = (() => {

    let get, getProperty, isDate;

    let var_init_locked_1557128179528;





    function main(date) {

        /**
         * 
         * 获得指定月份的下一个月份
         * 
         * @import get from date.get
         * 
         * @import getProperty from date.get.properties
         * 
         * @import is.date
         * 
         * @param {Date | object} date 包括月份的日期对象 
         * 
         * @return {Date} 下一个月份 
         * 
         */

        if (isDate(date)) {

            date = getProperty(date, [
                'year',
                'month'
            ]);
        }

        let {
            month,
            ...other
        } = date;

        month++;

        return get({
            month,
            ...other
        });

    }

    return function(date) {


        if (!var_init_locked_1557128179528) {

            get = include('date.get');
            getProperty = include('date.get.properties');
            isDate = include('is.date');

            var_init_locked_1557128179528 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectNextMonth'] = (() => {

    let next, getProperty, selectMonth;

    let var_init_locked_1557128179532;

    let var_current_scope_1557128179532;



    function main() {


        /**
         * 
         * 向下移动月份
         * 
         * @import next from month.next
         * 
         * @import getProperty from date.get.properties
         * 
         * @import selectMonth from ..selectMonth scoped
         * 
         */

        let me = this,
            {
                year,
                month
            } = me,
            {
                year: selectedYear,
                month: selectedMonth
            } = getProperty(next({
                year,
                month
            }), [
                'year',
                'month'
            ]);


        selectMonth(selectedYear, selectedMonth);

    }

    return function() {


        if (!var_init_locked_1557128179532) {

            next = include('month.next');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179532 = true;
        }



        if (!var_current_scope_1557128179532 !== this) {

            selectMonth = include('src::calendar.month.view.selectMonth').bind(this);

            var_current_scope_1557128179532 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view.selectRight'] = (() => {

    let isLast, get, nextMonth, nextDate, getProperty, select;

    let var_init_locked_1557128179538;

    let var_current_scope_1557128179538;



    function main() {


        /**
         * 
         * 向右移一个格日期
         * 
         * @import isLast from is.week.day.last
         * 
         * @import get from date.get
         * 
         * @import nextMonth from ..selectNextMonth scoped
         * 
         * @import nextDate from date.next
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */


        let {
            selectedDate,
            weekStartDay,
            month
        } = this;

        if (selectedDate) {

            let date = get(selectedDate);

            if (isLast(date, weekStartDay)) {

                nextMonth();

            } else {

                date = nextDate(date);

                let {
                    year: nextYearValue,
                    month: nextMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (nextMonthValue !== month) {

                    nextMonth();
                }

                select(nextYearValue, nextMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1557128179538) {

            isLast = include('is.week.day.last');
            get = include('date.get');
            nextDate = include('date.next');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179538 = true;
        }



        if (!var_current_scope_1557128179538 !== this) {

            nextMonth = include('src::calendar.month.view.selectNextMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179538 = this;
        }


        return main.call(this);
    };

})();

exports['src::month.date.first'] = (() => {

    let get;

    let var_init_locked_1557128179546;





    function main(year, month) {


        /**
         * 
         * 指定月份的第一个日期
         * 
         * @import get from date.get
         * 
         * @param {number} year 年份
         * 
         * @param {number} month 月份
         * 
         * @return {Date} 日期对象 
         * 
         */

        return get({
            year,
            month,
            day: 1
        });

    }

    return function(year, month) {


        if (!var_init_locked_1557128179546) {

            get = include('date.get');

            var_init_locked_1557128179546 = true;
        }




        return main.call(this, year, month);
    };

})();

exports['src::month.dates.week.first'] = (() => {

    let getDays, getFirstDate, next;

    let var_init_locked_1557128179548;





    function main(year, month, weekStartDay) {


        /**
         * 
         * 获得指定月份的第一周的所有日期
         * 
         * @import getDays from week.days
         * 
         * @import getFirstDate from month.date.first
         * 
         * @import next from date.next
         * 
         * @param {number} year 年份 
         * 
         * @param {number} month 月份
         * 
         * @param {number} [weekStartDay = 1] 确定一周从周几进行计算
         * 
         * @return {Date[]} 一周里所有的日期 
         * 
         */

        let days = getDays(weekStartDay),
            date = getFirstDate(year, month),
            firstIndex = days.indexOf(date.getDay()),
            result = [
                date
            ];

        for (let i = firstIndex + 1; i < 7; i++) {

            result.push(date = next(date));
        }

        return result;





    }

    return function(year, month, weekStartDay = 1) {


        if (!var_init_locked_1557128179548) {

            getDays = include('week.days');
            getFirstDate = include('month.date.first');
            next = include('date.next');

            var_init_locked_1557128179548 = true;
        }




        return main.call(this, year, month, weekStartDay);
    };

})();

exports['src::array.dates.includes'] = (() => {

    let get;

    let var_init_locked_1557128179552;





    function main(dates, date, fields) {


        /**
         * 
         * 基于日历数组进行包含性检测
         * 
         * @import get from date.get.properties
         * 
         * @param {Date[]} dates 日历数组
         * 
         * @param {Date} date 校验匹配数据项
         * 
         * @param {array} [fields = ['year' , 'month' , 'day']] 校验字段项
         * 
         * @return {boolean} 如果日历数组中包含校验项则返回 true , 否则返回 false 
         * 
         */

        let {
            year,
            month,
            day
        } = get(date, fields);

        for (let date of dates) {

            let {
                year: itemYear,
                month: itemMonth,
                day: itemDay
            } = get(date, fields);

            if (itemYear === year && itemMonth === month && itemDay === day) {

                return true;
            }
        }

        return false;






    }

    return function(dates, date, fields = ['year', 'month', 'day']) {


        if (!var_init_locked_1557128179552) {

            get = include('date.get.properties');

            var_init_locked_1557128179552 = true;
        }




        return main.call(this, dates, date, fields);
    };

})();

exports['src::date.prev.week'] = (() => {

    let prev;

    let var_init_locked_1557128179554;





    function main(date) {


        /**
         * 
         * 基于当前日期的上一周的日期
         * 
         * @import prev from date.prev
         * 
         * @param {Date | object} date 基准日期
         * 
         * @return {Date} 移过的日期 
         * 
         */

        return prev(date, 7);


    }

    return function(date) {


        if (!var_init_locked_1557128179554) {

            prev = include('date.prev');

            var_init_locked_1557128179554 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectUp'] = (() => {

    let getFirstWeekDates, includes, get, prevMonth, prevDate, getProperty, select;

    let var_init_locked_1557128179558;

    let var_current_scope_1557128179558;



    function main() {


        /**
         * 
         * 向上移一格日期
         * 
         * @import getFirstWeekDates from month.dates.week.first
         * 
         * @import includes from array.dates.includes
         * 
         * @import get from date.get
         * 
         * @import prevMonth from ..selectPrevMonth scoped
         * 
         * @import prevDate from date.prev.week
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            year,
            month
        } = this;

        if (selectedDate) {

            let dates = getFirstWeekDates(year, month, weekStartDay),
                date = get(selectedDate);

            if (includes(dates, date)) {

                prevMonth();

            } else {

                date = prevDate(date);

                let {
                    year: prevYearValue,
                    month: prevMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (prevMonthValue !== month) {

                    prevMonth();
                }

                select(prevYearValue, prevMonthValue, day);
            }
        }

    }

    return function() {


        if (!var_init_locked_1557128179558) {

            getFirstWeekDates = include('month.dates.week.first');
            includes = include('array.dates.includes');
            get = include('date.get');
            prevDate = include('date.prev.week');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179558 = true;
        }



        if (!var_current_scope_1557128179558 !== this) {

            prevMonth = include('src::calendar.month.view.selectPrevMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179558 = this;
        }


        return main.call(this);
    };

})();

exports['src::month.dates.week.last'] = (() => {

    let getDays, getLastDate, prev;

    let var_init_locked_1557128179564;





    function main(year, month, weekStartDay) {


        /**
         * 
         * 获得指定月份的最后一周的所有日期
         * 
         * @import getDays from week.days
         * 
         * @import getLastDate from month.date.last
         * 
         * @import prev from date.prev
         * 
         * @param {number} year 年份 
         * 
         * @param {number} month 月份
         * 
         * @param {number} [weekStartDay = 1] 确定一周从周几进行计算
         * 
         * @return {Date[]} 一周里所有的日期 
         * 
         */

        let days = getDays(weekStartDay),
            date = getLastDate(year, month),
            lastIndex = days.indexOf(date.getDay()),
            result = [
                date
            ];

        for (let i = lastIndex - 1; i >= 0; i--) {

            result.push(date = prev(date));
        }

        return result;

    }

    return function(year, month, weekStartDay = 1) {


        if (!var_init_locked_1557128179564) {

            getDays = include('week.days');
            getLastDate = include('month.date.last');
            prev = include('date.prev');

            var_init_locked_1557128179564 = true;
        }




        return main.call(this, year, month, weekStartDay);
    };

})();

exports['src::date.next.week'] = (() => {

    let next;

    let var_init_locked_1557128179567;





    function main(date) {


        /**
         * 
         * 基于当前日期的下一周的日期
         * 
         * @import next from date.next
         * 
         * @param {Date | object} date 基准日期
         * 
         * @return {Date} 移过的日期 
         * 
         */

        return next(date, 7);



    }

    return function(date) {


        if (!var_init_locked_1557128179567) {

            next = include('date.next');

            var_init_locked_1557128179567 = true;
        }




        return main.call(this, date);
    };

})();

exports['src::calendar.month.view.selectDown'] = (() => {

    let getLastWeekDates, includes, get, nextMonth, nextDate, getProperty, select;

    let var_init_locked_1557128179572;

    let var_current_scope_1557128179572;



    function main() {


        /**
         * 
         * 向下移一格日期
         * 
         * @import getLastWeekDates from month.dates.week.last
         * 
         * @import includes from array.dates.includes
         * 
         * @import get from date.get
         * 
         * @import nextMonth from ..selectNextMonth scoped
         * 
         * @import nextDate from date.next.week
         * 
         * @import getProperty from date.get.properties
         * 
         * @import select from ..select scoped
         * 
         */

        let {
            selectedDate,
            weekStartDay,
            year,
            month
        } = this;

        if (selectedDate) {

            let dates = getLastWeekDates(year, month, weekStartDay),
                date = get(selectedDate);

            if (includes(dates, date)) {

                nextMonth();

            } else {

                date = nextDate(date);

                let {
                    year: nextYearValue,
                    month: nextMonthValue,
                    day
                } = getProperty(date, [
                    'year',
                    'month',
                    'day'
                ]);

                if (nextMonthValue !== month) {

                    nextMonth();
                }

                select(nextYearValue, nextMonthValue, day);
            }
        }



    }

    return function() {


        if (!var_init_locked_1557128179572) {

            getLastWeekDates = include('month.dates.week.last');
            includes = include('array.dates.includes');
            get = include('date.get');
            nextDate = include('date.next.week');
            getProperty = include('date.get.properties');

            var_init_locked_1557128179572 = true;
        }



        if (!var_current_scope_1557128179572 !== this) {

            nextMonth = include('src::calendar.month.view.selectNextMonth').bind(this);
            select = include('src::calendar.month.view.select').bind(this);

            var_current_scope_1557128179572 = this;
        }


        return main.call(this);
    };

})();

exports['src::calendar.month.view'] = (() => {

    let extend, constructor, method_select, method_selectLeft, method_selectRight, method_selectUp, method_selectDown, method_selectMonth, method_selectNextMonth, method_selectPrevMonth, method_deselect;

    let var_init_locked_1557128179579;

    let var_class_1557128179579;

    return function(target, config) {


        if (!var_init_locked_1557128179579) {

            extend = include('class.empty')();
            constructor = include('src::calendar.month.view.constructor');
            method_select = include('src::calendar.month.view.select');
            method_selectLeft = include('src::calendar.month.view.selectLeft');
            method_selectRight = include('src::calendar.month.view.selectRight');
            method_selectUp = include('src::calendar.month.view.selectUp');
            method_selectDown = include('src::calendar.month.view.selectDown');
            method_selectMonth = include('src::calendar.month.view.selectMonth');
            method_selectNextMonth = include('src::calendar.month.view.selectNextMonth');
            method_selectPrevMonth = include('src::calendar.month.view.selectPrevMonth');
            method_deselect = include('src::calendar.month.view.deselect');

            var_init_locked_1557128179579 = true;
        }



        if (!var_class_1557128179579) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                select(...args) {

                    return method_select.apply(this, args);

                }
                selectLeft(...args) {

                    return method_selectLeft.apply(this, args);

                }
                selectRight(...args) {

                    return method_selectRight.apply(this, args);

                }
                selectUp(...args) {

                    return method_selectUp.apply(this, args);

                }
                selectDown(...args) {

                    return method_selectDown.apply(this, args);

                }
                selectMonth(...args) {

                    return method_selectMonth.apply(this, args);

                }
                selectNextMonth(...args) {

                    return method_selectNextMonth.apply(this, args);

                }
                selectPrevMonth(...args) {

                    return method_selectPrevMonth.apply(this, args);

                }
                deselect(...args) {

                    return method_deselect.apply(this, args);

                }



            }

            var_class_1557128179579 = main;
        }


        return new var_class_1557128179579(target, config);
    };

})();

exports['src::browser.support.pointer'] = (() => {







    let var_once_value_1557128179586;

    function main() {


        /**
         * 
         * 判断当前浏览器是否支持点触
         * 
         * @return {boolean} 如果是支持点触则返回 true ，否则返回 false 
         * 
         * @once
         * 
         */

        return window.hasOwnProperty('onpointerdown');

    }

    return function() {






        if (var_once_value_1557128179586) {

            return var_once_value_1557128179586;

        }
        return var_once_value_1557128179586 = main.call(this);

    };

})();

exports['src::browser.support.touch'] = (() => {







    let var_once_value_1557128179588;

    function main() {


        /**
         * 
         * 判断当前浏览器是否支持触摸
         * 
         * @return {boolean} 如果是支持触摸则返回 true ，否则返回 false 
         * 
         * @once
         * 
         */

        return window.hasOwnProperty('ontouchstart');

    }

    return function() {






        if (var_once_value_1557128179588) {

            return var_once_value_1557128179588;

        }
        return var_once_value_1557128179588 = main.call(this);

    };

})();

exports['src::browser.event.name'] = (() => {

    let isPointer, isTouch;

    let var_init_locked_1557128179589;






    /**
     * 
     * 获得事件的兼容名称
     * 
     * @import isPointer from browser.support.pointer
     * 
     * @import isTouch from browser.support.touch
     * 
     * @param {string} name 事件名称
     * 
     * @return {string} 对应事件的兼容名称 
     * 
     */

    function get_event_name(name) {

        switch (name) {

            case 'start':

                if (isPointer()) {

                    return 'pointerdown';

                } else if (isTouch()) {

                    return 'touchstart';
                }

                return 'mousedown';

            case 'move':

                if (isPointer()) {

                    return 'pointermove';

                } else if (isTouch()) {

                    return 'touchmove';
                }

                return 'mousemove';

            case 'end':

                if (isPointer()) {

                    return 'pointerup';

                } else if (isTouch()) {

                    return 'touchend';
                }

                return 'mouseup';
        }
    }

    function main(name) {

        switch (name) {

            case 'pointerdown':
            case 'touchstart':
            case 'mousedown':

                return get_event_name('start');

            case 'pointermove':
            case 'touchmove':
            case 'mousemove':

                return get_event_name('move');

            case 'pointerup':
            case 'touchend':
            case 'mousedup':

                return get_event_name('end');
        }

        return name;
    }



    return function(name) {


        if (!var_init_locked_1557128179589) {

            isPointer = include('browser.support.pointer');
            isTouch = include('browser.support.touch');

            var_init_locked_1557128179589 = true;
        }




        return main.call(this, name);
    };

})();

exports['src::browser.global.listener.map'] = (() => {

    let map;

    let var_init_locked_1557128179591;



    let var_once_value_1557128179591;

    function main() {


        /**
         * 
         * 维护全局事件监听对象
         * 
         * @import map value
         * 
         * @return {Map} 集合对象 
         * 
         * @once
         * 
         */

        return map;

    }

    return function() {


        if (!var_init_locked_1557128179591) {

            map = include('map')();

            var_init_locked_1557128179591 = true;
        }





        if (var_once_value_1557128179591) {

            return var_once_value_1557128179591;

        }
        return var_once_value_1557128179591 = main.call(this);

    };

})();

exports['src::browser.selector.is'] = (() => {









    function main(el, selector) {


        /**
         * 
         * 判断元素是否匹配选择器
         * 
         * @param {HTMLElement} el 元素
         * 
         * @param {string} selector 选择器字符串
         * 
         * @return {boolean} 如果元素匹配选择器则返回 true , 否则返回 false 
         * 
         */

        let {
            ownerDocument
        } = el;

        let els = Array.from(ownerDocument.querySelectorAll(selector));

        return els.includes(el);

    }

    return function(el, selector) {





        return main.call(this, el, selector);
    };

})();

exports['src::browser.selector.parent'] = (() => {

    let is;

    let var_init_locked_1557128179597;





    function main(el, selector) {


        /**
         * 
         * 判断元素及其元素父祖级元素是否匹配选择器
         * 
         * @import is from ..is
         * 
         * @param {HTMLElement} el 元素
         * 
         * @param {string} selector 选择器
         * 
         * @return {boolean} 如果匹配则返回 true , 否则返回 false 
         * 
         */

        while (el) {

            if (is(el, selector)) {

                return el;
            }

            el = el.parentElement;
        }

    }

    return function(el, selector) {


        if (!var_init_locked_1557128179597) {

            is = include('src::browser.selector.is');

            var_init_locked_1557128179597 = true;
        }




        return main.call(this, el, selector);
    };

})();

exports['src::browser.global.listener.add'] = (() => {

    let getEventName, getMap, is;

    let var_init_locked_1557128179600;





    function main(event, fn, selector) {


        /**
         * 
         * 监听全局事件
         * 
         * @import getEventName from browser.event.name
         * 
         * @import getMap from ..map
         * 
         * @import is from browser.selector.parent
         * 
         * @param {string} event 目标监听事件
         * 
         * @param {function} fn 目标监听回调
         * 
         * @param {string} selector 选择器
         * 
         * @return {mixed} 返回说明 
         * 
         */

        event = getEventName(event);

        let map = getMap(),
            listenerFn = e => {

                let {
                    target
                } = e;

                if (selector) {

                    if (is(target, selector)) {

                        fn(e);
                    }

                } else {

                    fn(e);
                }
            };

        map.set(event, fn, selector, listenerFn);

        document.addEventListener(event, listenerFn);




    }

    return function(event, fn, selector) {


        if (!var_init_locked_1557128179600) {

            getEventName = include('browser.event.name');
            getMap = include('src::browser.global.listener.map');
            is = include('browser.selector.parent');

            var_init_locked_1557128179600 = true;
        }




        return main.call(this, event, fn, selector);
    };

})();

exports['src::browser.global.listener.remove'] = (() => {

    let getEventName, getMap;

    let var_init_locked_1557128179605;





    function main(event, fn, selector) {


        /**
         * 
         * 去除监听全局事件
         * 
         * @import getEventName from browser.event.name
         * 
         * @import getMap from ..map
         * 
         * @param {string} event 目标监听事件
         * 
         * @param {function} fn 目标监听回调
         * 
         * @param {string} selector 选择器
         * 
         * @return {mixed} 返回说明 
         * 
         */

        event = getEventName(event);

        let map = getMap(),
            listenerFn = map.get(event, fn, selector);

        if (listenerFn) {

            document.removeEventListener(event, listenerFn);
        }

    }

    return function(event, fn, selector) {


        if (!var_init_locked_1557128179605) {

            getEventName = include('browser.event.name');
            getMap = include('src::browser.global.listener.map');

            var_init_locked_1557128179605 = true;
        }




        return main.call(this, event, fn, selector);
    };

})();

exports['src::browser.event.key'] = (() => {










    /**
     * 
     * 得到对应代码的值键值 
     * 
     * @param {Event} event 键事件对象
     * 
     * @return {mixed} 键值 
     * 
     */

    const KEY_CODES = {
            39: 'DIRECTION::RIGHT',
            37: 'DIRECTION::LEFT',
            38: 'DIRECTION::UP',
            40: 'DIRECTION::DOWN',
            13: 'ENTER',
            46: 'DELETE',
            9: 'TAB',
            107: '+',
            187: '=',
            27: 'ESC'
        },
        WITH_SHIFT_KEY_CODES = {
            187: '+'
        };

    function main({
        shiftKey,
        keyCode
    }) {

        let value;

        if (shiftKey) {

            value = WITH_SHIFT_KEY_CODES[keyCode];
        }

        if (value) {

            return value;
        }

        return KEY_CODES[keyCode];
    }

    return function(event) {





        return main.call(this, event);
    };

})();

exports['src::os.name'] = (() => {







    let var_once_value_1557128179611;

    function main() {

        /**
         * 
         * 返回当前操作系统的名称
         * 
         * @once
         * 
         * @return {string} 操作系统的名称
         * 
         */

        const NAMES = {
            iphone: 'iOS',
            android: 'Android',
            mac: 'MacOS',
            win: 'Windows',
            linux: 'Linux',
            other: 'Other'
        };

        let userAgent = navigator.userAgent.toLowerCase(),
            name = NAMES[(userAgent.match(/mac|win|linux/) || ['other'])[0]];

        switch (name) {

            case 'MacOS':
            case 'Linux':

                {

                    let name = NAMES[(userAgent.match(/iphone|android/) || ['other'])[0]];

                    if (name !== 'Other') {

                        return name;
                    }
                }
        }

        return name;

    }

    return function() {






        if (var_once_value_1557128179611) {

            return var_once_value_1557128179611;

        }
        return var_once_value_1557128179611 = main.call(this);

    };

})();

exports['src::observer'] = (() => {

    let isObject, isFunction, createMap, remove;

    let var_init_locked_1557128179613;

    let var_class_1557128179613;

    return function() {


        if (!var_init_locked_1557128179613) {

            isObject = include('is.object.simple');
            isFunction = include('is.function');
            createMap = include('map');
            remove = include('array.remove');

            var_init_locked_1557128179613 = true;
        }



        if (!var_class_1557128179613) {


            /**
             * 
             * 观察者模式
             * 
             * @import isObject from is.object.simple
             * 
             * @import is.function
             * 
             * @import createMap from map
             * 
             * @import remove from array.remove
             * 
             * @class
             * 
             */

            class main extends require('events') {

                constructor() {

                    super();

                    this.listeners = createMap();
                }

                clearAllListeners() {

                    this.removeAllListeners();
                }

                clearListeners(event) {

                    this.removeAllListeners(event);
                }

                addListeners(listeners) {

                    let me = this,
                        events = Object.keys(listeners),
                        {
                            scope
                        } = listeners;

                    remove(events, 'scope');

                    for (let event of events) {

                        let listener = listeners[event];

                        if (isObject(listener)) {

                            let {
                                fn,
                                scope: listenerScope,
                                ...options
                            } = listener;

                            me.on(event, fn, listenerScope || scope, options);

                        } else if (isFunction(listener)) {

                            me.on(event, listener, scope);
                        }
                    }
                }

                removeListeners(listeners) {

                    let me = this,
                        events = Object.keys(listeners);

                    for (let event of events) {

                        let listener = listeners[event];

                        if (isObject(listener)) {

                            let {
                                fn
                            } = listener;

                            me.un(event, fn);

                        } else if (isFunction(listener)) {

                            me.un(event, listener);
                        }
                    }
                }

                on(event, fn, scope, options) {

                    this.addListener(event, fn, scope, options);
                }

                addListener(event, fn, scope, {
                    once = false
                } = {}) {

                    let me = this,
                        {
                            listeners
                        } = me,
                        listener = fn.bind(scope);

                    listeners.set(event, fn, scope, listener);

                    if (once) {

                        me.once(event, listener);
                    }

                    super.addListener(event, listener);
                }

                un(event, fn, scope) {

                    this.removeListener(event, fn, scope);
                }

                removeListener(event, fn, scope) {

                    let me = this,
                        {
                            listeners
                        } = me,
                        listener = listeners.get(event, fn, scope);

                    if (listener) {

                        super.removeListener(event, listener);

                        listeners.delete(event, fn, scope);
                    }
                }

                fireEvent(event, ...args) {

                    let me = this;

                    doFireBubbleEvent.call(me, event, me, ...args);
                }
            }

            function doFireBubbleEvent(event, target, ...args) {

                let me = this,
                    {
                        bubbleTarget
                    } = me;

                me.emit(event, target, ...args);

                if (bubbleTarget && bubbleTarget instanceof main) {

                    doFireBubbleEvent.call(bubbleTarget, event, target, ...args);
                }
            }

            var_class_1557128179613 = main;
        }


        return var_class_1557128179613;
    };

})();

exports['src::data.node.relationship.constructor'] = (() => {

    let getProxy;

    let var_init_locked_1557128179618;





    function main(node, {
        parentNodeField,
        childNodesField,
        relationshipField
    }) {


        /**
         * 
         * 构建节点方向识别器
         * 
         * @import getProxy from object.proxy
         * 
         * @param {mixed} node 节点引用
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {string} [config.parentNodeField = 'parentNode'] 父节点引用字段名称
         * 
         * @param {string} [config.childNodesField = 'childNodes'] 子节点集合引用字段名称 
         * 
         * @param {string} [config.relationshipField = 'relationship'] 描述节点关系字段名称
         * 
         */

        let me = this;

        me.proxy = getProxy(node);

        me.node = node;

        me.parentNodeField = parentNodeField;

        me.childNodesField = childNodesField;

        node[me.relationshipField = relationshipField] = me;

    }

    return function(node, {
        parentNodeField = 'parentNode',
        childNodesField = 'childNodes',
        relationshipField = 'relationship'
    } = {}) {


        if (!var_init_locked_1557128179618) {

            getProxy = include('object.proxy');

            var_init_locked_1557128179618 = true;
        }




        return main.call(this, node, {
            parentNodeField,
            childNodesField,
            relationshipField
        });
    };

})();

exports['src::object.proxy.fly'] = (() => {

    let createProxy;

    let var_init_locked_1557128179620;






    /**
     * 
     * 构建一个共享对象代理
     * 
     * @import createProxy from object.proxy
     * 
     * @param {mixed} target 需要代理的对象
     * 
     * @return {object.Proxy} 代理
     * 
     */

    let proxy;

    function main(target) {

        if (!proxy) {

            proxy = createProxy();
        }

        proxy.target = target;

        return proxy;
    }

    return function(target) {


        if (!var_init_locked_1557128179620) {

            createProxy = include('object.proxy');

            var_init_locked_1557128179620 = true;
        }




        return main.call(this, target);
    };

})();

exports['src::data.node.relationship.node.parent'] = (() => {

    let fly;

    let var_init_locked_1557128179622;





    function main() {


        /**
         * 
         * 返回父节点
         * 
         * @import fly from object.proxy.fly
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        let {
            proxy,
            parentNodeField,
            relationshipField
        } = this,
        parentNode = proxy.getIf(parentNodeField);

        if (parentNode) {

            return fly(parentNode).get(relationshipField);
        }

    }

    return function() {


        if (!var_init_locked_1557128179622) {

            fly = include('object.proxy.fly');

            var_init_locked_1557128179622 = true;
        }




        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.child'] = (() => {

    let isString, isNumber, fly;

    let var_init_locked_1557128179624;





    function main(index) {

        /**
         * 
         * 快速子节点定位器
         * 
         * @import is.string
         * 
         * @import is.number
         * 
         * @import fly from object.proxy.fly
         * 
         * @param {mixed} index 子节点定位索引
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        let {
            node,
            proxy,
            parentNodeField,
            childNodesField,
            relationshipField
        } = this,
        result;

        if (isString(index)) {

            let childNodes = proxy.get(childNodesField);

            switch (index) {

                case 'first':

                    result = childNodes[0];

                    break;

                case 'last':

                    result = childNodes[childNodes.length - 1];
            }

        } else if (isNumber(index)) {

            let parentNode = proxy.getIf(parentNodeField);

            if (parentNode) {

                let childNodes = fly(parentNode).get(childNodesField);

                result = childNodes[childNodes.indexOf(node) + index];
            }
        }

        if (result) {

            return fly(result).get(relationshipField);
        }

    }

    return function(index) {


        if (!var_init_locked_1557128179624) {

            isString = include('is.string');
            isNumber = include('is.number');
            fly = include('object.proxy.fly');

            var_init_locked_1557128179624 = true;
        }




        return main.call(this, index);
    };

})();

exports['src::data.node.relationship.node.next'] = (() => {

    let getNode;

    let var_init_locked_1557128179626;

    let var_current_scope_1557128179626;



    function main() {


        /**
         * 
         * 返回下一个兄弟节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode(1);

    }

    return function() {




        if (!var_current_scope_1557128179626 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1557128179626 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.first'] = (() => {

    let getNode;

    let var_init_locked_1557128179629;

    let var_current_scope_1557128179629;



    function main() {


        /**
         * 
         * 返回第一个子节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('first');

    }

    return function() {




        if (!var_current_scope_1557128179629 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1557128179629 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.last'] = (() => {

    let getNode;

    let var_init_locked_1557128179632;

    let var_current_scope_1557128179632;



    function main() {


        /**
         * 
         * 返回最后一个子节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('last');

    }

    return function() {




        if (!var_current_scope_1557128179632 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1557128179632 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.previos'] = (() => {

    let getNode;

    let var_init_locked_1557128179634;

    let var_current_scope_1557128179634;



    function main() {


        /**
         * 
         * 返回下一个兄弟节点
         * 
         * @import getNode from ..child scoped
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode(-1);

    }

    return function() {




        if (!var_current_scope_1557128179634 !== this) {

            getNode = include('src::data.node.relationship.node.child').bind(this);

            var_current_scope_1557128179634 = this;
        }


        return main.call(this);
    };

})();

exports['src::data.node.relationship.node.deep'] = (() => {









    function main(field, deep, strict) {


        /**
         * 
         * 获得指定层数节点数据,如果层数不足，则返回最后一层的节点数据
         * 
         * @param {string} field 节点字段
         * 
         * @param {number} [deep = 1] 深度
         * 
         * @param {boolean} [strict = true] 是否严格匹配
         * 
         * @return {data.node.Relationship} 节点关系对象 
         * 
         */


        let node = this;

        for (let i = 1; i <= deep; i++) {

            while (true) {

                let tempNode = node[field];

                if (tempNode) {

                    node = tempNode;

                    break;

                } else {

                    switch (field) {

                        case 'firstNode':

                            tempNode = node.nextNode;

                            break;

                        case 'lastNode':

                            tempNode = node.previousNode;
                    }

                    if (tempNode) {

                        node = tempNode;

                    } else {

                        return strict === false ? node : null;
                    }
                }
            }
        }

        return node;

    }

    return function(field, deep = 1, strict = true) {





        return main.call(this, field, deep, strict);
    };

})();

exports['src::data.node.relationship.node.first.get'] = (() => {

    let getNode;

    let var_init_locked_1557128179639;

    let var_current_scope_1557128179639;



    function main(count, strict) {


        /**
         * 
         * 返回指定层数的第一个节点
         * 
         * @import getNode from ....deep scoped
         * 
         * @param {number} [count] 迭代次数
         * 
         * @param {boolean} [strict] 严格模式
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('firstNode', count, strict);

    }

    return function(count, strict) {




        if (!var_current_scope_1557128179639 !== this) {

            getNode = include('src::data.node.relationship.node.deep').bind(this);

            var_current_scope_1557128179639 = this;
        }


        return main.call(this, count, strict);
    };

})();

exports['src::data.node.relationship.node.last.get'] = (() => {

    let getNode;

    let var_init_locked_1557128179640;

    let var_current_scope_1557128179640;



    function main(count, strict) {


        /**
         * 
         * 返回指定层数的第一个节点
         * 
         * @import getNode from ....deep scoped
         * 
         * @param {number} [count] 迭代次数
         * 
         * @param {boolean} [strict] 严格模式
         * 
         * @return {data.node.Relationship} 节点关系对象
         * 
         */

        return getNode('lastNode', count, strict);

    }

    return function(count, strict) {




        if (!var_current_scope_1557128179640 !== this) {

            getNode = include('src::data.node.relationship.node.deep').bind(this);

            var_current_scope_1557128179640 = this;
        }


        return main.call(this, count, strict);
    };

})();

exports['src::data.node.relationship.up'] = (() => {









    function main() {


        /**
         * 
         * 返回上面的节点引用
         * 
         * @return {data.node.Relationship} 上面节点 
         * 
         */

        let node = this,
            {
                previousNode
            } = node;

        if (previousNode) {

            return previousNode;
        }

        let count = 0,
            firstPreviousNode,
            firstCount;

        while (node = node.parentNode) {

            count++;

            let {
                previousNode
            } = node;

            if (previousNode) {

                if (!firstPreviousNode) {

                    firstPreviousNode = previousNode;

                    firstCount = count;
                }

                let result = previousNode.getLastNode(count);

                if (result) {

                    return result;
                }
            }
        }

        if (firstPreviousNode) {

            return firstPreviousNode.getLastNode(firstCount, false);
        }



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.down'] = (() => {









    function main() {


        /**
         * 
         * 返回下面的节点引用
         * 
         * @return {mixed} 下面节点 
         * 
         */

        let node = this,
            {
                nextNode
            } = node;

        if (nextNode) {

            return nextNode;
        }

        let count = 0,
            firstNextNode,
            firstCount;

        while (node = node.parentNode) {

            count++;

            let nextNode;

            while (nextNode = node.nextNode) {

                if (!firstNextNode) {

                    firstNextNode = nextNode;

                    firstCount = count;
                }

                let result = nextNode.getFirstNode(count);

                if (result) {

                    return result;
                }

                node = nextNode;


            }
        }

        if (firstNextNode) {

            return firstNextNode.getFirstNode(firstCount, false);
        }



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.left'] = (() => {









    function main() {


        /**
         * 
         * 返回左面的节点引用
         * 
         * @return {data.node.Relationship} 左面节点 
         * 
         */

        let node = this,
            {
                parentNode
            } = node;

        if (parentNode) {

            return parentNode;
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship.right'] = (() => {









    function main() {


        /**
         * 
         * 返回右面的节点引用
         * 
         * @return {data.node.Relationship} 右面节点 
         * 
         */

        let node = this,
            {
                firstNode
            } = node;

        if (firstNode) {

            return firstNode;
        }

        let previousCount = 0,
            previousNode,
            lastChildNode,
            basePreviousNode = node;

        while (previousNode = basePreviousNode.previousNode) {

            previousCount++;

            if (lastChildNode = previousNode.lastNode) {

                break;

            } else {

                basePreviousNode = previousNode;
            }
        }

        if (!lastChildNode) {

            let upNode;

            while (upNode = basePreviousNode.up()) {

                previousCount++;

                if (lastChildNode = upNode.lastNode) {

                    break;

                } else {

                    basePreviousNode = upNode;
                }
            }
        }

        let nextount = 0,
            nextNode,
            firstChildNode,
            baseNextNode = node;

        while (nextNode = baseNextNode.nextNode) {

            nextount++;

            if (firstChildNode = nextNode.firstNode) {

                break;

            } else {

                baseNextNode = nextNode;
            }
        }

        if (!firstChildNode) {

            let downNode;

            while (downNode = baseNextNode.down()) {

                nextount++;

                if (firstChildNode = downNode.firstNode) {

                    break;

                } else {

                    baseNextNode = downNode;
                }
            }
        }

        let result;

        if (firstChildNode && lastChildNode) {

            if (previousCount >= nextount) {

                result = lastChildNode;

            } else {

                result = firstChildNode;
            }

        } else {

            result = lastChildNode || firstChildNode;
        }



        return result;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.relationship'] = (() => {

    let extend, constructor, get_parentNode, get_nextNode, get_firstNode, get_lastNode, get_previousNode, method_getFirstNode, method_getLastNode, method_up, method_down, method_left, method_right;

    let var_init_locked_1557128179653;

    let var_class_1557128179653;

    return function(node, config) {


        if (!var_init_locked_1557128179653) {

            extend = include('class.empty')();
            constructor = include('src::data.node.relationship.constructor');
            get_parentNode = include('src::data.node.relationship.node.parent');
            get_nextNode = include('src::data.node.relationship.node.next');
            get_firstNode = include('src::data.node.relationship.node.first');
            get_lastNode = include('src::data.node.relationship.node.last');
            get_previousNode = include('src::data.node.relationship.node.previos');
            method_getFirstNode = include('src::data.node.relationship.node.first.get');
            method_getLastNode = include('src::data.node.relationship.node.last.get');
            method_up = include('src::data.node.relationship.up');
            method_down = include('src::data.node.relationship.down');
            method_left = include('src::data.node.relationship.left');
            method_right = include('src::data.node.relationship.right');

            var_init_locked_1557128179653 = true;
        }



        if (!var_class_1557128179653) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                getFirstNode(...args) {

                    return method_getFirstNode.apply(this, args);

                }
                getLastNode(...args) {

                    return method_getLastNode.apply(this, args);

                }
                up(...args) {

                    return method_up.apply(this, args);

                }
                down(...args) {

                    return method_down.apply(this, args);

                }
                left(...args) {

                    return method_left.apply(this, args);

                }
                right(...args) {

                    return method_right.apply(this, args);

                }

                get parentNode() {

                    return get_parentNode.call(this);

                }
                get nextNode() {

                    return get_nextNode.call(this);

                }
                get firstNode() {

                    return get_firstNode.call(this);

                }
                get lastNode() {

                    return get_lastNode.call(this);

                }
                get previousNode() {

                    return get_previousNode.call(this);

                }

            }

            var_class_1557128179653 = main;
        }


        return new var_class_1557128179653(node, config);
    };

})();

exports['src::data.node.view.constructor'] = (() => {

    let getProxy;

    let var_init_locked_1557128179658;





    function main(node, {
        expandedField,
        viewField
    }) {


        /**
         * 
         * 构建一个可视化节点
         * 
         * @import getProxy from object.proxy
         * 
         * @param {mixed} node 数据节点
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {string} [config.expandedField = 'expanded'] 展开收起控制字段
         * 
         * @param {string} [config.viewField = 'view'] 描述节点关系字段名称
         * 
         */

        let me = this,
            proxy = me.proxy = getProxy(node);

        me.expandedField = expandedField;

        if (proxy.get(expandedField) === true) {

            me.expand();
        } else {

            me.collapse();
        }

        node[viewField] = me;

    }

    return function(node, {
        expandedField = 'expanded',
        viewField = 'view'
    } = {}) {


        if (!var_init_locked_1557128179658) {

            getProxy = include('object.proxy');

            var_init_locked_1557128179658 = true;
        }




        return main.call(this, node, {
            expandedField,
            viewField
        });
    };

})();

exports['src::data.node.view.expand'] = (() => {









    function main() {


        /**
         * 
         * 展开
         * 
         */

        let me = this,
            {
                proxy,
                expandedField
            } = me;

        if (proxy.get(expandedField) !== true) {

            proxy.set(expandedField, true);

            proxy.fireEvent('expand');

        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.view.collapse'] = (() => {









    function main() {


        /**
         * 
         * 收起
         * 
         */

        let me = this,
            {
                proxy,
                expandedField
            } = me;

        if (proxy.get(expandedField) === true) {

            proxy.set(expandedField, false);

            proxy.fireEvent('collapse');

        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::data.node.view'] = (() => {

    let extend, constructor, method_expand, method_collapse;

    let var_init_locked_1557128179667;

    let var_class_1557128179667;

    return function(node, config) {


        if (!var_init_locked_1557128179667) {

            extend = include('class.empty')();
            constructor = include('src::data.node.view.constructor');
            method_expand = include('src::data.node.view.expand');
            method_collapse = include('src::data.node.view.collapse');

            var_init_locked_1557128179667 = true;
        }



        if (!var_class_1557128179667) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                expand(...args) {

                    return method_expand.apply(this, args);

                }
                collapse(...args) {

                    return method_collapse.apply(this, args);

                }



            }

            var_class_1557128179667 = main;
        }


        return new var_class_1557128179667(node, config);
    };

})();

exports['src::tree.node.constructor'] = (() => {

    let createRelationship, createView, generate;

    let var_init_locked_1557128179669;





    function main(config) {


        /**
         * 
         * 构建一个树型节点
         * 
         * @import createRelationship from data.node.relationship
         * 
         * @import createView from data.node.view
         * 
         * 
         * @import generate from id.generate
         * 
         * @param {object} config 节点配置
         * 
         */

        let me = this;

        Object.assign(me, config);

        me.expanded = me.expanded || true;

        me.id = generate('tree-node-');

        me.$children = [];

        createRelationship(me, {
            childNodesField: 'children'
        });

        createView(me, {
            childNodesField: 'children'
        });

    }

    return function(config) {


        if (!var_init_locked_1557128179669) {

            createRelationship = include('data.node.relationship');
            createView = include('data.node.view');
            generate = include('id.generate');

            var_init_locked_1557128179669 = true;
        }




        return main.call(this, config);
    };

})();

exports['src::tree.node.bubbleTarget.get'] = (() => {









    function main() {


        /**
         * 
         * 返回冒泡对象
         * 
         * @return {tree.Node} 父节点 
         * 
         */

        return this.parentNode;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::array.insert'] = (() => {









    function main(data, index, ...items) {


        /**
         * 
         * 在指定下标处插入项
         * 
         * @param {array} data 数组
         * 
         * @param {number} index 数组下标
         * 
         * @param {mixed} [...items] 项
         * 
         */

        data.splice(index, 0, ...items);

    }

    return function(data, index, ...items) {





        return main.call(this, data, index, ...items);
    };

})();

exports['src::data.node.list.node.index.start.before'] = (() => {









    function main(node) {


        /**
         * 
         * 节点头部之前的位置
         * 
         * @param {mixed} node 节点
         * 
         * @return {number} 位置 
         * 
         */

        let {
            nodes
        } = this;

        return nodes.indexOf(node);

    }

    return function(node) {





        return main.call(this, node);
    };

})();

exports['src::data.node.list.node.index.start.after'] = (() => {

    let getIndex;

    let var_init_locked_1557128179679;

    let var_current_scope_1557128179679;



    function main(node) {


        /**
         * 
         * 节点头部之后的位置
         * 
         * @import getIndex from ..before scoped
         * 
         * @param {mixed} node 节点
         * 
         * @return {number} 位置 
         * 
         */

        return getIndex(node) + 1;

    }

    return function(node) {




        if (!var_current_scope_1557128179679 !== this) {

            getIndex = include('src::data.node.list.node.index.start.before').bind(this);

            var_current_scope_1557128179679 = this;
        }


        return main.call(this, node);
    };

})();

exports['src::data.node.list.node.index.end.before'] = (() => {

    let fly;

    let var_init_locked_1557128179681;






    /**
     * 
     * 节点尾部之前的位置
     * 
     * @import fly from object.proxy.fly
     * 
     * @param {mixed} node 节点
     * 
     * @return {number} 位置 
     * 
     */

    function get_last_node(node) {

        let me = this,
            {
                childNodesField
            } = me,
            childNodes = fly(node).get(childNodesField),
            {
                length
            } = childNodes;

        if (length) {

            get_last_node.call(me, childNodes[length - 1]);
        }

        return node;
    }

    function main(node) {

        let me = this,
            {
                nodes
            } = me,
            lastNode = get_last_node.call(me, node);

        if (lastNode !== node) {

            return nodes.indexOf(lastNode);
        }

        return nodes.indexOf(node) + 1;
    }

    return function(node) {


        if (!var_init_locked_1557128179681) {

            fly = include('object.proxy.fly');

            var_init_locked_1557128179681 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::data.node.list.node.index.end.after'] = (() => {

    let fly;

    let var_init_locked_1557128179683;






    /**
     * 
     * 节点尾部之后的位置
     * 
     * @import fly from object.proxy.fly
     * 
     * @param {mixed} node 节点
     * 
     * @return {number} 位置 
     * 
     */

    function get_last_node(node) {

        let me = this,
            {
                childNodesField
            } = me,
            childNodes = fly(node).get(childNodesField),
            {
                length
            } = childNodes;

        if (length) {

            get_last_node.call(me, childNodes[length - 1]);
        }

        return node;
    }

    function main(node) {

        let me = this,
            {
                nodes
            } = me,
            lastNode = get_last_node.call(me, node);

        if (lastNode !== node) {

            return nodes.indexOf(lastNode) + 1;
        }

        return nodes.indexOf(node) + 1;
    }

    return function(node) {


        if (!var_init_locked_1557128179683) {

            fly = include('object.proxy.fly');

            var_init_locked_1557128179683 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::data.node.list.insert'] = (() => {

    let isArray, insert, fly, getBeforeStartIndex, getAfterStartIndex, getBeforeEndIndex, getAfterEndIndex, doInsertNodes;

    let var_init_locked_1557128179685;

    let var_current_scope_1557128179685;



    function main(node, insertNodes, position) {

        /**
         * 
         * 插入节点列表
         * 
         * @import is.array
         * 
         * @import insert from array.insert
         * 
         * @import fly from object.proxy.fly
         * 
         * @import getBeforeStartIndex from ..node.index.start.before scoped
         * 
         * @import getAfterStartIndex from ..node.index.start.after scoped
         * 
         * @import getBeforeEndIndex from ..node.index.end.before scoped
         * 
         * @import getAfterEndIndex from ..node.index.end.after scoped
         * 
         * @import doInsertNodes from ..insert scoped
         * 
         * @param {mixed} node 基准节点
         * 
         * @param {mixed} insertNodes 子节点
         * 
         * @param {string} [position = 'beforeend'] 插入位置
         * 
         * @return {boolean} 如果插入成功则返回 true , 否则返回 false
         * 
         */

        if (!isArray(insertNodes)) {

            insertNodes = [
                insertNodes
            ];
        }

        let {
            nodes,
            childNodesField,
            expandedField
        } = this;


        if (nodes.includes(node)) {

            switch (position) {

                case 'beforestart':

                    insert(nodes, getBeforeStartIndex(node), ...insertNodes);

                    break;

                case 'afterstart':

                    insert(nodes, getAfterStartIndex(node), ...insertNodes);

                    break;

                case 'beforeend':

                    insert(nodes, getBeforeEndIndex(node), ...insertNodes);

                    break;

                case 'afterend':

                    insert(nodes, getAfterEndIndex(node), ...insertNodes);
            }

            for (let insertNode of insertNodes) {

                if (fly(insertNode).get(expandedField) === true) {

                    doInsertNodes(insertNode, fly(insertNode).get(childNodesField));
                }
            }

            return true;
        }

        return false;





    }

    return function(node, insertNodes, position = 'beforeend') {


        if (!var_init_locked_1557128179685) {

            isArray = include('is.array');
            insert = include('array.insert');
            fly = include('object.proxy.fly');

            var_init_locked_1557128179685 = true;
        }



        if (!var_current_scope_1557128179685 !== this) {

            getBeforeStartIndex = include('src::data.node.list.node.index.start.before').bind(this);
            getAfterStartIndex = include('src::data.node.list.node.index.start.after').bind(this);
            getBeforeEndIndex = include('src::data.node.list.node.index.end.before').bind(this);
            getAfterEndIndex = include('src::data.node.list.node.index.end.after').bind(this);
            doInsertNodes = include('src::data.node.list.insert').bind(this);

            var_current_scope_1557128179685 = this;
        }


        return main.call(this, node, insertNodes, position);
    };

})();

exports['src::data.node.list.constructor'] = (() => {

    let fly, insert;

    let var_init_locked_1557128179688;

    let var_current_scope_1557128179688;



    function main(node, {
        childNodesField,
        expandedField
    }) {


        /**
         * 
         * 构建节点的一维列表
         * 
         * @import fly from object.proxy.fly
         * 
         * @import insert from ..insert scoped
         * 
         * @param {mixed} node 节点
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {string} [config.childNodesField = 'childNodes'] 子节点集合引用字段名称
         * 
         * @param {string} [config.expandedField = 'expanded'] 节点展开收起标识字段
         * 
         */

        let me = this;

        me.nodes = [
            node
        ];

        me.childNodesField = childNodesField;

        me.expandedField = expandedField;

        insert(node, fly(node).get(childNodesField));


    }

    return function(node, {
        childNodesField = 'childNodes',
        expandedField = 'expanded'
    } = {}) {


        if (!var_init_locked_1557128179688) {

            fly = include('object.proxy.fly');

            var_init_locked_1557128179688 = true;
        }



        if (!var_current_scope_1557128179688 !== this) {

            insert = include('src::data.node.list.insert').bind(this);

            var_current_scope_1557128179688 = this;
        }


        return main.call(this, node, {
            childNodesField,
            expandedField
        });
    };

})();

exports['src::data.node.list.remove'] = (() => {

    let remove, doRemoveNodes, fly, isArray;

    let var_init_locked_1557128179692;

    let var_current_scope_1557128179692;



    function main(removeNodes) {


        /**
         * 
         * 删除节点列表
         * 
         * @import remove from array.remove
         * 
         * @import doRemoveNodes from ..remove scoped
         * 
         * @import fly from object.proxy
         * 
         * @import is.array
         * 
         * @param {mixed} removeNodes 子节点
         * 
         * 
         */

        if (!isArray(removeNodes)) {

            removeNodes = [
                removeNodes
            ];
        }

        let {
            nodes,
            childNodesField
        } = this;

        remove(nodes, ...removeNodes);

        for (let removeNode of removeNodes) {

            doRemoveNodes(fly(removeNode).get(childNodesField));
        }

    }

    return function(removeNodes) {


        if (!var_init_locked_1557128179692) {

            remove = include('array.remove');
            fly = include('object.proxy');
            isArray = include('is.array');

            var_init_locked_1557128179692 = true;
        }



        if (!var_current_scope_1557128179692 !== this) {

            doRemoveNodes = include('src::data.node.list.remove').bind(this);

            var_current_scope_1557128179692 = this;
        }


        return main.call(this, removeNodes);
    };

})();

exports['src::data.node.list'] = (() => {

    let extend, constructor, method_remove, method_insert;

    let var_init_locked_1557128179694;

    let var_class_1557128179694;

    return function(node, config) {


        if (!var_init_locked_1557128179694) {

            extend = include('class.empty')();
            constructor = include('src::data.node.list.constructor');
            method_remove = include('src::data.node.list.remove');
            method_insert = include('src::data.node.list.insert');

            var_init_locked_1557128179694 = true;
        }



        if (!var_class_1557128179694) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                remove(...args) {

                    return method_remove.apply(this, args);

                }
                insert(...args) {

                    return method_insert.apply(this, args);

                }



            }

            var_class_1557128179694 = main;
        }


        return new var_class_1557128179694(node, config);
    };

})();

exports['src::tree.node.list.get'] = (() => {

    let getList;

    let var_init_locked_1557128179699;





    function main() {


        /**
         * 
         * 获取节点列表
         * 
         * @import getList from data.node.list
         * 
         * @return {data.node.List} 节点列表 
         * 
         */

        return getList(this, {
            childNodesField: 'children'
        });

    }

    return function() {


        if (!var_init_locked_1557128179699) {

            getList = include('data.node.list');

            var_init_locked_1557128179699 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.index.get'] = (() => {









    function main() {


        /**
         * 
         * 获取树型节点在线性表中的位置
         * 
         * @return {number} 位置信息
         * 
         */

        let me = this,
            {
                nodes
            } = me.tree.list;

        console.log('节点列表', nodes);

        return nodes.indexOf(me);

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.remove'] = (() => {

    let remove;

    let var_init_locked_1557128179704;





    function main(node) {


        /**
         * 
         * 删除子节点
         * 
         * @import remove from array.remove
         * 
         * @param {tree.node} node 子节点
         * 
         */

        let me = this,
            {
                $children,
                tree
            } = me;

        if ($children.includes(node)) {

            remove($children, node);

            me.fireEvent('remove', node);

            delete node.parentNode;
        }

    }

    return function(node) {


        if (!var_init_locked_1557128179704) {

            remove = include('array.remove');

            var_init_locked_1557128179704 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::tree.node.append'] = (() => {

    let isObject;

    let var_init_locked_1557128179707;





    function main(node) {


        /**
         * 
         * 添加子节点
         * 
         * @import isObject from is.object.simple
         * 
         * @param {mixed} node 子节点
         * 
         */

        let me = this,
            {
                $children,
                tree
            } = me;

        if (isObject(node)) {

            node = tree.read(node);

            if (!node) {

                return;
            }
        }

        let {
            parentNode
        } = node;

        if (parentNode) {

            parentNode.removeChild(node);

        }

        if (!$children.includes(node)) {

            node.parentNode = me;

            $children.push(node);

            me.fireEvent('append', node);

            return node;
        }

    }

    return function(node) {


        if (!var_init_locked_1557128179707) {

            isObject = include('is.object.simple');

            var_init_locked_1557128179707 = true;
        }




        return main.call(this, node);
    };

})();

exports['src::tree.node.children.set'] = (() => {

    let from, remove, append;

    let var_init_locked_1557128179709;

    let var_current_scope_1557128179709;



    function main(children) {


        /**
         * 
         * 设置子节点集合
         * 
         * @import from from array.from
         * 
         * @import remove from ....remove scoped
         * 
         * @import append from ....append scoped
         * 
         * @param {array} children 子节点集合
         * 
         * 
         */

        children = from(children);

        let me = this,
            {
                $children
            } = me;

        {
            let childNodes = from($children);

            for (let childNode of childNodes) {

                remove(childNode);
            }
        }

        {
            let childNodes = from(children);

            for (let childNode of childNodes) {

                append(childNode);
            }
        }



    }

    return function(children) {


        if (!var_init_locked_1557128179709) {

            from = include('array.from');

            var_init_locked_1557128179709 = true;
        }



        if (!var_current_scope_1557128179709 !== this) {

            remove = include('src::tree.node.remove').bind(this);
            append = include('src::tree.node.append').bind(this);

            var_current_scope_1557128179709 = this;
        }


        return main.call(this, children);
    };

})();

exports['src::tree.node.children.get'] = (() => {

    let from;

    let var_init_locked_1557128179712;





    function main() {


        /**
         * 
         * 获取子节点集合
         * 
         * @import from from array.from
         * 
         * @return {array} 子节点数组 
         * 
         */

        return from(this.$children);

    }

    return function() {


        if (!var_init_locked_1557128179712) {

            from = include('array.from');

            var_init_locked_1557128179712 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.descendants.get'] = (() => {









    function main() {


        /**
         * 
         * 获得所有的子孙节点
         * 
         * @return {array} 子孙节点集合
         * 
         */

        let nodes = [],
            {
                children
            } = this;

        for (let child of children) {

            nodes.push(child);

            if (!child.isLeaf) {

                nodes.push(...child.descendants);
            }
        }

        return nodes;



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::object.copy'] = (() => {









    function main(dest, source, fields) {


        /**
         * 
         * 复制
         * 
         * @param {object} dest 目标对象
         * 
         * @param {object} source 来源对象
         * 
         * @param {string[]} [fields = []] 拷贝字段集合 
         * 
         * @return {object} 目标对象引用
         * 
         */

        for (let field of fields) {

            dest[field] = source[field];
        }

        return dest;

    }

    return function(dest, source, fields = []) {





        return main.call(this, dest, source, fields);
    };

})();

exports['src::tree.node.data.get'] = (() => {

    let copy;

    let var_init_locked_1557128179718;





    function main() {


        /**
         * 
         * 获取节点的简单JSON数据
         * 
         * @import copy from object.copy
         * 
         * @return {object} JSON 数据
         * 
         */

        let me = this,
            {
                fields
            } = me.tree;

        return copy({
            leaf: me.isLeaf
        }, me, fields);

    }

    return function() {


        if (!var_init_locked_1557128179718) {

            copy = include('object.copy');

            var_init_locked_1557128179718 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.isLeaf.get'] = (() => {









    function main() {


        /**
         * 
         * 判断当前节点是否是叶子节点
         * 
         * @return {boolean} 如果为叶子节点则返回 true , 否则返回 false 
         * 
         */

        return this.$children.length === 0;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.isRoot.get'] = (() => {









    function main() {


        /**
         * 
         * 判断当前节点是否为根节点
         * 
         * @return {boolean} 如果是根节点则返回 true , 否则返回 false 
         * 
         */

        return !this.parentNode;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.first.get'] = (() => {









    function main() {


        /**
         * 
         * 获得第一个子节点引用
         * 
         * @return {tree.Node} 树型节点
         * 
         */

        let {
            $children: children
        } = this;

        if (children.length) {

            return children[0];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.last.get'] = (() => {









    function main() {


        /**
         * 
         * 获得最后一个子节点引用
         * 
         * @return {tree.Node} 树型节点
         * 
         */

        let {
            $children: children
        } = this, {
            length
        } = children;

        if (length) {

            return children[length - 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.prev.get'] = (() => {









    function main() {


        /**
         * 
         * 返回当前节点的上一个兄弟节点
         * 
         * @return {tree.Node} 节点 
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            let {
                $children: children
            } = parentNode;

            return children[children.indexOf(me) - 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.next.get'] = (() => {









    function main() {


        /**
         * 
         * 返回当前节点的下一个兄弟节点
         * 
         * @return {tree.Node} 节点 
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            let {
                $children: children
            } = parentNode;

            return children[children.indexOf(me) + 1];
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.first'] = (() => {










    /**
     * 
     * 第一个叶子节点
     * 
     * @return {tree.Node} 节点 
     * 
     */


    function get_first_node(node) {

        let {
            isLeaf
        } = node;

        if (isLeaf) {

            return node;
        }

        return get_first_node(node.first);
    }

    function main() {

        let me = this,
            {
                isLeaf
            } = me;

        if (isLeaf) {

            return
        }

        return get_first_node(me);
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.last'] = (() => {










    /**
     * 
     * 最后一个叶子节点
     * 
     * @return {tree.Node} 节点 
     * 
     */

    function get_last_node(node) {

        let {
            isLeaf
        } = node;

        if (isLeaf) {

            return node;
        }

        return get_last_node(node.last);
    }

    function main() {

        let me = this,
            {
                isLeaf
            } = me;

        if (isLeaf) {

            return
        }

        return get_last_node(me);
    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.descendants'] = (() => {









    function main() {


        /**
         * 
         * 所有叶子子孙节点
         * 
         * @return {array} 子孙节点集合
         * 
         */


        let nodes = [],
            {
                descendants
            } = this;

        for (let descendant of descendants) {

            if (descendant.isLeaf) {

                nodes.push(descendant);
            }
        }

        return nodes;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.leaf.deepest'] = (() => {









    function main() {


        /**
         * 
         * 获取最深节点
         * 
         * @return {tree.NOde} 节点引用 
         * 
         */

        let {
            leafDescendants: nodes
        } = this;

        if (nodes.length) {

            let deepestNode = nodes[0],
                deepestFloor = deepestNode.floor;

            for (let node of nodes) {

                let {
                    floor
                } = node;

                if (deepestFloor < floor) {

                    deepestFloor = floor;

                    deepestNode = node;
                }
            }

            return deepestNode;
        }



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.floor.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前节点所在的层次
         * 
         * @return {number} 层次数值 
         * 
         */

        let node = this,
            floor = 1,
            parentNode;

        while (parentNode = node.parentNode) {

            node = parentNode;

            floor++;
        }

        return floor;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::array.insert.after'] = (() => {









    function main(data, insertItem, existItem) {


        /**
         * 
         * 在数组中指定项之后添加
         * 
         * @param {array} data 目标数组
         * 
         * @param {mixed} insertItem 需要添加的项
         * 
         * @param {mixed} existItem 指定项
         * 
         */

        let index = data.indexOf(existItem);

        if (index !== -1) {

            data.splice(index + 1, 0, insertItem);
        }

    }

    return function(data, insertItem, existItem) {





        return main.call(this, data, insertItem, existItem);
    };

})();

exports['src::tree.node.insert.after'] = (() => {

    let isObject, insert;

    let var_init_locked_1557128179739;





    function main(node, existNode) {


        /**
         * 
         * 在指定节点之前插入
         * 
         * @import isObject from is.object.simple
         * 
         * @import insert from array.insert.after
         * 
         * @param {mixed} node 子节点
         * 
         * @param {tree.Node} existNode 已有子节点
         * 
         * @return {mixed} 返回说明 
         * 
         */

        let me = this,
            {
                $children: children,
                tree
            } = me;

        if (!children.includes(existNode)) {

            return;
        }

        if (isObject(node)) {

            node = tree.read(node);

            if (!node) {

                return;
            }
        }

        let {
            parentNode
        } = node;

        if (parentNode) {

            parentNode.removeChild(node);

        }

        if (!children.includes(node)) {

            node.parentNode = me;

            insert(children, node, existNode);

            me.fireEvent('insert', node, existNode, 'after');

            return node;
        }

    }

    return function(node, existNode) {


        if (!var_init_locked_1557128179739) {

            isObject = include('is.object.simple');
            insert = include('array.insert.after');

            var_init_locked_1557128179739 = true;
        }




        return main.call(this, node, existNode);
    };

})();

exports['src::tree.node.insert.before'] = (() => {









    function main(data) {


        /**
         * 
         * 函数实现说明
         * 
         * @param {mixed} data 参数说明
         * 
         * @return {mixed} 返回说明 
         * 
         */

        // 代码实现

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::tree.node.destroy'] = (() => {









    function main() {


        /**
         * 
         * 销毁节点
         *
         * 
         */

        let me = this,
            {
                parentNode
            } = me;

        if (parentNode) {

            parentNode.remove(me);
        }





    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node'] = (() => {

    let extend, constructor, get_bubbleTarget, get_list, get_index, set_children, get_children, get_descendants, get_data, get_isLeaf, get_isRoot, get_first, get_last, get_prev, get_next, get_firstLeaf, get_lastLeaf, get_leafDescendants, get_deepestLeaf, get_floor, method_append, method_insertAfter, method_insertBefore, method_remove, method_destroy;

    let var_init_locked_1557128179747;

    let var_class_1557128179747;

    return function() {


        if (!var_init_locked_1557128179747) {

            extend = include('observer')();
            constructor = include('src::tree.node.constructor');
            get_bubbleTarget = include('src::tree.node.bubbleTarget.get');
            get_list = include('src::tree.node.list.get');
            get_index = include('src::tree.node.index.get');
            set_children = include('src::tree.node.children.set');
            get_children = include('src::tree.node.children.get');
            get_descendants = include('src::tree.node.descendants.get');
            get_data = include('src::tree.node.data.get');
            get_isLeaf = include('src::tree.node.isLeaf.get');
            get_isRoot = include('src::tree.node.isRoot.get');
            get_first = include('src::tree.node.first.get');
            get_last = include('src::tree.node.last.get');
            get_prev = include('src::tree.node.prev.get');
            get_next = include('src::tree.node.next.get');
            get_firstLeaf = include('tree.node.leaf.first');
            get_lastLeaf = include('tree.node.leaf.last');
            get_leafDescendants = include('tree.node.leaf.descendants');
            get_deepestLeaf = include('tree.node.leaf.deepest');
            get_floor = include('src::tree.node.floor.get');
            method_append = include('src::tree.node.append');
            method_insertAfter = include('tree.node.insert.after');
            method_insertBefore = include('tree.node.insert.before');
            method_remove = include('src::tree.node.remove');
            method_destroy = include('src::tree.node.destroy');

            var_init_locked_1557128179747 = true;
        }



        if (!var_class_1557128179747) {

            class main extends mixins({
                extend,
                mixins: []
            }) {





                constructor(...args) {

                    super(...args);

                    constructor.apply(this, args);

                }

                append(...args) {

                    return method_append.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                insertBefore(...args) {

                    return method_insertBefore.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }
                destroy(...args) {

                    return method_destroy.apply(this, args);

                }

                get bubbleTarget() {

                    return get_bubbleTarget.call(this);

                }
                get list() {

                    return get_list.call(this);

                }
                get index() {

                    return get_index.call(this);

                }
                set children(value) {

                    set_children.call(this, value);

                }
                get children() {

                    return get_children.call(this);

                }
                get descendants() {

                    return get_descendants.call(this);

                }
                get data() {

                    return get_data.call(this);

                }
                get isLeaf() {

                    return get_isLeaf.call(this);

                }
                get isRoot() {

                    return get_isRoot.call(this);

                }
                get first() {

                    return get_first.call(this);

                }
                get last() {

                    return get_last.call(this);

                }
                get prev() {

                    return get_prev.call(this);

                }
                get next() {

                    return get_next.call(this);

                }
                get firstLeaf() {

                    return get_firstLeaf.call(this);

                }
                get lastLeaf() {

                    return get_lastLeaf.call(this);

                }
                get leafDescendants() {

                    return get_leafDescendants.call(this);

                }
                get deepestLeaf() {

                    return get_deepestLeaf.call(this);

                }
                get floor() {

                    return get_floor.call(this);

                }

            }

            var_class_1557128179747 = main;
        }


        return var_class_1557128179747;
    };

})();

exports['src::tree.node.mind.constructor'] = (() => {









    function main() {


        /**
         * 
         * 构建脑图节点
         * 
         */

        let me = this;

        me.x = 0;

        me.y = 0;

        me.selected = false;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind.height.region'] = (() => {









    function main() {


        /**
         * 
         * 当前节点所占的区域高度
         * 
         * @return {nubmber} 高度值 
         * 
         */

        let {
            leafDescendants,
            tree,
            height
        } = this, {
            verticalSpacing = 5
        } = tree.layoutConfig, {
            length
        } = leafDescendants;

        if (this.expanded === false) {

            return height;
        }

        if (length) {

            let countHeight = 0;

            for (let descendant of leafDescendants) {

                countHeight += descendant.height;
            }

            return countHeight + verticalSpacing * (length - 1);
        }

        return height;



    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind.region.node'] = (() => {

    let getRegion;

    let var_init_locked_1557128179769;





    function main() {


        /**
         * 
         * 实现基于节点的区域模型
         * 
         * @import getRegion from math.region.rect
         * 
         * @return {math.region.Rect} 矩型区域模型 
         * 
         */

        return getRegion(this);

    }

    return function() {


        if (!var_init_locked_1557128179769) {

            getRegion = include('math.region.rect');

            var_init_locked_1557128179769 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.node.mind.layout'] = (() => {









    function main() {


        /**
         * 
         * 布局
         * 
         */

        let me = this,
            {
                isRoot,
                isLeaf,
                x,
                y,
                width,
                height,
                $children: children,
                tree
            } = me,
            {
                length
            } = children,
            {
                horizontalSpacing = 5,
                verticalSpacing = 5
            } = tree.layoutConfig,
            startX = x + width + horizontalSpacing,
            startY;

        if (me.expanded === false) {

            return;
        }

        if (isRoot) {

            let countHeight = 0;

            for (let child of children) {

                countHeight += child.regionHeight;
            }

            startY = y - (countHeight + (length - 1) * verticalSpacing) / 2 + height / 2;

        } else {

            startY = y;
        }

        for (let child of children) {

            child.x = startX;

            child.y = startY;

            startY += child.regionHeight + verticalSpacing;

            child.layout();
        }

        if (!isRoot && !isLeaf) {

            let {
                first,
                last
            } = me;

            me.y = first.y + (last.y + last.height - first.y) / 2 - height / 2;
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.mind'] = (() => {

    let extend, constructor, get_regionHeight, get_nodeRegion, method_layout;

    let var_init_locked_1557128179773;

    let var_class_1557128179773;

    return function() {


        if (!var_init_locked_1557128179773) {

            extend = include('tree.node')();
            constructor = include('src::tree.node.mind.constructor');
            get_regionHeight = include('tree.node.mind.height.region');
            get_nodeRegion = include('tree.node.mind.region.node');
            method_layout = include('src::tree.node.mind.layout');

            var_init_locked_1557128179773 = true;
        }



        if (!var_class_1557128179773) {

            class main extends mixins({
                extend,
                mixins: []
            }) {





                constructor(...args) {

                    super(...args);

                    constructor.apply(this, args);

                }

                layout(...args) {

                    return method_layout.apply(this, args);

                }

                get regionHeight() {

                    return get_regionHeight.call(this);

                }
                get nodeRegion() {

                    return get_nodeRegion.call(this);

                }

            }

            var_class_1557128179773 = main;
        }


        return var_class_1557128179773;
    };

})();

exports['src::tree.reader.json'] = (() => {

    let objectGet, from, isEmpty, isObjectSimple, getReader;

    let var_init_locked_1557128179793;






    /**
     * 
     * 解析树型数据
     * 
     * @import object.get
     * 
     * @import from from array.from
     * 
     * @import is.empty
     * 
     * @import is.object.simple
     * 
     * @import getReader from data.reader.json
     * 
     * @param {object} [config = {}] 读取参数设置
     * 
     * @param {string} [config.rootProperty = '.'] 读取数据的根名称
     * 
     * @param {string} [config.childrenProperty = 'cn'] 读取子节点的字段名称
     * 
     * @param {string} [config.childrenField = 'children'] 存储子节点的字段名称
     * 
     * @param {function} [config.create] 构建对象函数
     * 
     * @param {function} [config.createExtraParams] 基于构建对象函数附加参数
     * 
     * @param {string} [config.fields] 读取数据记录的字段项
     * 
     * @return {function} 读取器所生成的解析函数
     * 
     */

    function main({
        rootProperty,
        childrenProperty,
        childrenField,
        fields,
        create,
        createExtraParams
    }) {

        const read = getReader({
                multi: false,
                create,
                createExtraParams,
                fields
            }),
            parse = children => {

                children = from(children);

                let result = [];

                for (let child of children) {

                    {
                        let children = child[childrenProperty];

                        child = read(child);

                        if (children) {

                            child[childrenField] = parse(children);

                        } else {

                            child[childrenField] = [];
                        }

                        result.push(child);
                    }
                }

                return result;

            };

        return (new Function('data', `

        var include = this.include,
            parse = this.parse,
            get = include('object.get'),
            isObject = include('is.object.simple');

        ${generate_get_root_data(rootProperty)}

        if(isObject(data)){

            return parse(data)[0] ;
        }

    `)).bind({
            include,
            parse
        });
    }

    function generate_get_root_data(rootProperty) {

        if (rootProperty !== '.') {

            return `data = get(data , '${rootProperty}');`;
        }

        return '';
    }

    return function({
        rootProperty = '.',
        childrenProperty = 'cn',
        childrenField = 'children',
        create,
        createExtraParams,
        fields
    } = {}) {


        if (!var_init_locked_1557128179793) {

            objectGet = include('object.get');
            from = include('array.from');
            isEmpty = include('is.empty');
            isObjectSimple = include('is.object.simple');
            getReader = include('data.reader.json');

            var_init_locked_1557128179793 = true;
        }




        return main.call(this, {
            rootProperty,
            childrenProperty,
            childrenField,
            create,
            createExtraParams,
            fields
        });
    };

})();

exports['src::tree.constructor'] = (() => {

    let createRead, getNodeClass, getProxy, getFields;

    let var_init_locked_1557128179799;





    function main(target, {
        reader,
        Node,
        defaultNodeConfig,
        layoutConfig,
        fields
    }) {


        /**
         * 
         * 初始化树
         * 
         * @import createRead from tree.reader.json
         * 
         * @import getNodeClass from tree.node
         * 
         * @import getProxy from object.proxy
         * 
         * @import getFields from data.reader.fields
         * 
         * @param {mixed} target 树所绑定的对象
         * 
         * @param {object} [config = {}] 配置
         * 
         * @param {object} [config.reader = {}] 读取器配置
         * 
         * @param {class} [config.Node] 节点类型 
         * 
         * @param {object} [config.defaultNodeConfig = {}] 默认的节点配置
         * 
         * @param {object} [config.layoutConfig = {}] 树型图的布局信息
         * 
         * @param {array} [config.fields] 可以显示的节点字段
         * 
         */

        let me = this;

        Node = me.Node = Node || getNodeClass();

        me.proxy = getProxy(target);

        fields = getFields(fields || [
            'id'
        ]);

        me.layoutConfig = layoutConfig;

        me.read = createRead(Object.assign({
            fields,
            create(config) {

                return new Node(config);

            }
        }, reader, {
            childrenField: 'children',
            createExtraParams: Object.assign({
                tree: me
            }, defaultNodeConfig)
        }));

        let fieldNames = me.fields = [];

        for (let {
                name
            } of fields) {

            fieldNames.push(name);
        }

        me.loading = false;

    }

    return function(target, {
        reader = {},
        Node,
        defaultNodeConfig = {},
        layoutConfig = {},
        fields
    } = {}) {


        if (!var_init_locked_1557128179799) {

            createRead = include('tree.reader.json');
            getNodeClass = include('tree.node');
            getProxy = include('object.proxy');
            getFields = include('data.reader.fields');

            var_init_locked_1557128179799 = true;
        }




        return main.call(this, target, {
            reader,
            Node,
            defaultNodeConfig,
            layoutConfig,
            fields
        });
    };

})();

exports['src::tree.data.get'] = (() => {









    function main() {


        /**
         * 
         * 获得当前树型结构的所有节点数据
         * 
         * @return {array} 一组数据 
         * 
         */

        let me = this,
            {
                rootNode
            } = me;

        if (!rootNode) {

            return [];
        }

        let {
            nodes
        } = me.list,
            result = [];

        for (let {
                data
            } of nodes) {

            result.push(data);
        }

        return result;

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.node.get'] = (() => {









    function main(id) {


        /**
         * 
         * 获取树型节点
         * 
         * @param {string} id 基于编号定位树型节点
         * 
         * @return {tree.Node} 树型节点 
         * 
         */

        let {
            nodes
        } = this.list;

        for (let node of nodes) {

            if (node.id === id) {

                return node;
            }
        }

    }

    return function(id) {





        return main.call(this, id);
    };

})();

exports['src::tree.set'] = (() => {

    let assign, get;

    let var_init_locked_1557128179819;

    let var_current_scope_1557128179819;



    function main(id, values) {

        /**
         * 
         * 设置节点属性
         * 
         * @import assign from object.assign
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} [values = {}] 节点值
         * 
         * @return {mixed} 返回说明 
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node) {

            console.log('修改内容', values);

            let {
                children,
                ...data
            } = values

            assign(node, data);

            proxy.call('update', node.data, node.index);
        }


    }

    return function(id, values = {}) {


        if (!var_init_locked_1557128179819) {

            assign = include('object.assign');

            var_init_locked_1557128179819 = true;
        }



        if (!var_current_scope_1557128179819 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1557128179819 = this;
        }


        return main.call(this, id, values);
    };

})();

exports['src::tree.clear'] = (() => {

    let from;

    let var_init_locked_1557128179823;





    function main() {


        /**
         * 
         * 清除所有节点
         * 
         * @import from from array.from
         * 
         */

        let me = this,
            {
                proxy
            } = me;

        let {
            rootNode
        } = me;

        if (rootNode) {

            rootNode.clearAllListeners();

            delete me.rootNode;

            delete me.list;

            proxy.callIf('remove', 1);
        }

    }

    return function() {


        if (!var_init_locked_1557128179823) {

            from = include('array.from');

            var_init_locked_1557128179823 = true;
        }




        return main.call(this);
    };

})();

exports['src::tree.queue.append'] = (() => {









    function main(parentNode, node) {


        /**
         * 
         * 新增一个节点进队列
         * 
         * @param {number} parentNode 父节点
         * 
         * @param {tree.Node} node 节点
         * 
         */

        let {
            list
        } = this;

        if (list) {

            list.insert(parentNode, node);
        }

    }

    return function(parentNode, node) {





        return main.call(this, parentNode, node);
    };

})();

exports['src::tree.queue.insert'] = (() => {









    function main(parentNode, node, baseChildNode, position) {

        /**
         * 
         * 将节点插入到线性表中
         * 
         * @param {mixed} parentNode 父节点
         * 
         * @param {mixed} node 子节点
         * 
         * @param {mixed} baseChildNode 基准子节点
         * 
         * @param {string} position 插入在基准子节点的前后位置
         * 
         */

        let {
            list
        } = this;

        switch (position) {

            case 'before':

                list.insert(baseChildNode, node, 'beforestart');

                break;

            case 'after':

                list.insert(baseChildNode, node, 'afterend');
        }

    }

    return function(parentNode, node, baseChildNode, position) {





        return main.call(this, parentNode, node, baseChildNode, position);
    };

})();

exports['src::tree.queue.remove'] = (() => {

    let remove;

    let var_init_locked_1557128179828;





    function main(parentNode, node) {


        /**
         * 
         * 移除树型节点
         * 
         * @import remove from array.remove
         * 
         * @param {mixed} parentNode 父节点
         *
         * @param {mixed} node 节点配置
         * 
         */

        let {
            list
        } = this;

        list.remove(node);

    }

    return function(parentNode, node) {


        if (!var_init_locked_1557128179828) {

            remove = include('array.remove');

            var_init_locked_1557128179828 = true;
        }




        return main.call(this, parentNode, node);
    };

})();

exports['src::tree.load'] = (() => {

    let append, insert, remove;

    let var_init_locked_1557128179829;

    let var_current_scope_1557128179829;




    /**
     * 
     * 重新载入树形数据
     * 
     * @import append from ..queue.append scoped
     * 
     * @import insert from ..queue.insert scoped
     * 
     * @import remove from ..queue.remove scoped
     * 
     * @param {mixed} data 树型数据
     * 
     */

    function main(data) {


        let me = this;

        me.clear();

        me.loading = true;

        let rootNode = me.read(data);

        if (rootNode) {

            me.rootNode = rootNode;

            let {
                proxy
            } = me;

            me.list = rootNode.list;

            proxy.callIf('load', me.data);

            rootNode.addListeners({

                append(parentNode, node) {

                    if (parentNode.expanded) {

                        append(parentNode, node);
                    }

                },

                insert(parentNode, node, existNode, position) {

                    if (parentNode.expanded) {

                        insert(parentNode, node, existNode, position);
                    }
                },

                remove(parentNode, node) {

                    remove(parentNode, node);
                },

                expand(parentNode) {

                    let {
                        children
                    } = parentNode;

                    for (let childNode of children) {

                        append(parentNode, childNode);
                    }
                },

                collapse(parentNode) {

                    let {
                        children
                    } = parentNode;

                    for (let childNode of children) {

                        remove(parentNode, childNode);
                    }
                }

            });
        }

        me.loading = false;
    }






    return function(data) {




        if (!var_current_scope_1557128179829 !== this) {

            append = include('src::tree.queue.append').bind(this);
            insert = include('src::tree.queue.insert').bind(this);
            remove = include('src::tree.queue.remove').bind(this);

            var_current_scope_1557128179829 = this;
        }


        return main.call(this, data);
    };

})();

exports['src::tree.append'] = (() => {

    let get;

    let var_init_locked_1557128179833;

    let var_current_scope_1557128179833;



    function main(id, config) {


        /**
         * 
         * 添加子节点
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node) {

            let newNode = node.append(config);

            if (newNode) {

                proxy.callIf('insert', newNode.data, newNode.index);

                return true;
            }
        }

        return false;



    }

    return function(id, config) {




        if (!var_current_scope_1557128179833 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1557128179833 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.insert.before'] = (() => {









    function main(data) {


        /**
         * 
         * 函数实现说明
         * 
         * @param {mixed} data 参数说明
         * 
         * @return {mixed} 返回说明 
         * 
         */

        // 代码实现

    }

    return function(data) {





        return main.call(this, data);
    };

})();

exports['src::tree.insert.after'] = (() => {

    let get;

    let var_init_locked_1557128179836;

    let var_current_scope_1557128179836;



    function main(id, config) {


        /**
         * 
         * 在指定节点下方添加节点
         * 
         * @import get from ....node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node && !node.isRoot) {

            let {
                parentNode
            } = node,
            newNode = parentNode.insertAfter(config, node);

            if (newNode) {

                proxy.callIf('insert', newNode.data, newNode.index);

                return true;
            }
        }

        return false;

    }

    return function(id, config) {




        if (!var_current_scope_1557128179836 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1557128179836 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.remove'] = (() => {

    let get;

    let var_init_locked_1557128179838;

    let var_current_scope_1557128179838;



    function main(id) {


        /**
         * 
         * 删除子节点
         * 
         * @import get from .node.get scoped
         * 
         * @param {string} id 节点编号
         * 
         */

        let {
            proxy
        } = this,
        node = get(id);

        if (node && !node.isRoot) {

            proxy.callIf('remove', node.index);

            node.destroy();

            return true;
        }

        return false;


    }

    return function(id) {




        if (!var_current_scope_1557128179838 !== this) {

            get = include('src::tree.node.get').bind(this);

            var_current_scope_1557128179838 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree'] = (() => {

    let extend, constructor, get_data, method_set, method_clear, method_load, method_appendQueue, method_removeQueue, method_insertQueue, method_append, method_insertBefore, method_insertAfter, method_remove;

    let var_init_locked_1557128179840;

    let var_class_1557128179840;

    return function() {


        if (!var_init_locked_1557128179840) {

            extend = include('class.empty')();
            constructor = include('src::tree.constructor');
            get_data = include('src::tree.data.get');
            method_set = include('src::tree.set');
            method_clear = include('src::tree.clear');
            method_load = include('src::tree.load');
            method_appendQueue = include('tree.queue.append');
            method_removeQueue = include('tree.queue.remove');
            method_insertQueue = include('tree.queue.insert');
            method_append = include('src::tree.append');
            method_insertBefore = include('tree.insert.before');
            method_insertAfter = include('tree.insert.after');
            method_remove = include('src::tree.remove');

            var_init_locked_1557128179840 = true;
        }



        if (!var_class_1557128179840) {

            class main {





                constructor(...args) {



                    constructor.apply(this, args);

                }

                set(...args) {

                    return method_set.apply(this, args);

                }
                clear(...args) {

                    return method_clear.apply(this, args);

                }
                load(...args) {

                    return method_load.apply(this, args);

                }
                appendQueue(...args) {

                    return method_appendQueue.apply(this, args);

                }
                removeQueue(...args) {

                    return method_removeQueue.apply(this, args);

                }
                insertQueue(...args) {

                    return method_insertQueue.apply(this, args);

                }
                append(...args) {

                    return method_append.apply(this, args);

                }
                insertBefore(...args) {

                    return method_insertBefore.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }

                get data() {

                    return get_data.call(this);

                }

            }

            var_class_1557128179840 = main;
        }


        return var_class_1557128179840;
    };

})();

exports['src::tree.mind.extend'] = (() => {

    let Node, tree;

    let var_init_locked_1557128179859;

    let var_class_1557128179859;

    return function() {


        if (!var_init_locked_1557128179859) {

            Node = include('tree.node.mind')();
            tree = include('tree')();

            var_init_locked_1557128179859 = true;
        }



        if (!var_class_1557128179859) {

            /**
             * 
             * 脑图
             * 
             * @import Node from tree.node.mind value
             * 
             * @import tree value
             * 
             * @class
             * 
             */

            class main extends tree {

                constructor(target, config) {

                    let {
                        fields = []
                    } = config;

                    config.fields = [
                        'id',
                        'x',
                        'y',
                        'width',
                        'height',
                        'selected',
                        ...fields
                    ];

                    config.Node = Node;

                    super(target, config);
                }
            }

            var_class_1557128179859 = main;
        }


        return var_class_1557128179859;
    };

})();

exports['src::tree.mind.constructor'] = (() => {









    function main(target, {
        rootXY
    }) {


        /**
         * 
         * 构建脑图
         * 
         * @param {mixed} target 脑图绑定对象
         * 
         * @param {object} config 脑图配置
         * 
         * @param {object} config.rootXY 脑图根节点的位置
         * 
         */

        this.rootXY = rootXY;

    }

    return function(target, {
        rootXY
    }) {





        return main.call(this, target, {
            rootXY
        });
    };

})();

exports['src::tree.mind.deselect'] = (() => {









    function main() {


        /**
         * 
         * 取消选定
         * 
         */

        let me = this,
            {
                selectedNode,
                proxy
            } = me;

        if (selectedNode) {

            selectedNode.selected = false;

            delete me.selectedNode;

            proxy.call('deselect', selectedNode.index);
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.clear'] = (() => {

    let clear, deselect;

    let var_init_locked_1557128179882;

    let var_current_scope_1557128179882;



    function main() {


        /**
         * 
         * 清空数据
         * 
         * @import clear from tree.clear scoped
         * 
         * @import deselect from ..deselect scoped
         * 
         */

        deselect();

        clear();

    }

    return function() {




        if (!var_current_scope_1557128179882 !== this) {

            clear = include('tree.clear').bind(this);
            deselect = include('src::tree.mind.deselect').bind(this);

            var_current_scope_1557128179882 = this;
        }


        return main.call(this);
    };

})();

exports['src::tree.mind.layout'] = (() => {










    /**
     * 
     * 基于根节点进行布局
     * 
     */

    function main() {

        let me = this,
            {
                rootNode,
                rootXY,
                layoutConfig,
                list
            } = me,
            {
                line: {
                    offset: lineOffset = 5,
                    startX: lineStartX = 0,
                    startY: lineStartY = 0
                }
            } = layoutConfig;

        if (rootNode) {

            let {
                x,
                y
            } = rootXY;

            rootNode.x = x;

            rootNode.y = y;

            rootNode.layout();

            let {
                proxy,
                data
            } = me, {
                firstLeaf,
                lastLeaf,
                deepestLeaf
            } = rootNode;

            if (!firstLeaf) {

                firstLeaf = rootNode;
            }

            if (!lastLeaf) {

                lastLeaf = rootNode;
            }

            if (!deepestLeaf) {

                deepestLeaf = rootNode;
            }

            let top = firstLeaf.y;

            if (top > 0) {

                top = 0;

            } else {

                top = -top;
            }

            let left = rootNode.x;

            if (left > 0) {

                left = 0;

            } else {

                left = -left;
            }

            proxy.call('layout', data, {
                left,
                right: deepestLeaf.x + deepestLeaf.width,
                top,
                bottom: lastLeaf.y + lastLeaf.height,
                lines: get_lines(list.nodes, {
                    left,
                    top,
                    lineOffset,
                    lineStartX,
                    lineStartY
                })
            });
        }
    }

    function get_lines(nodes, {
        left,
        top,
        lineOffset,
        lineStartX,
        lineStartY
    }) {

        let lines = [];

        for (let node of nodes) {

            let {
                parentNode
            } = node;

            if (!parentNode) {

                continue;
            }

            let {
                nodeRegion
            } = parentNode, {
                x: startX,
                y: startY
            } = nodeRegion.getAnchorXY('r');

            startX += left + lineStartX;

            startY += top + lineStartY;

            {
                let {
                    nodeRegion
                } = node, {
                    x,
                    y
                } = nodeRegion.getAnchorXY('l');

                x += left;

                y += top;

                lines.push([
                    startX,
                    startY,
                    startX + lineOffset,
                    startY,
                    x - lineOffset,
                    y,
                    x,
                    y
                ]);
            }

        }

        return lines;
    }



    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.load'] = (() => {

    let load, layout;

    let var_init_locked_1557128179886;

    let var_current_scope_1557128179886;



    function main(data) {


        /**
         * 
         * 数据载入
         * 
         * @import load from tree.load scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {mixed} data 树型数据
         * 
         */

        load(data);

        layout();



    }

    return function(data) {




        if (!var_current_scope_1557128179886 !== this) {

            load = include('tree.load').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179886 = this;
        }


        return main.call(this, data);
    };

})();

exports['src::tree.mind.insert.after'] = (() => {

    let insert, layout;

    let var_init_locked_1557128179889;

    let var_current_scope_1557128179889;



    function main(id, config) {

        /**
         * 
         * 增加子节点
         * 
         * @import insert from tree.insert.after scoped
         * 
         * @import layout from ....layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        if (insert(id, config)) {

            layout();
        }

    }

    return function(id, config) {




        if (!var_current_scope_1557128179889 !== this) {

            insert = include('tree.insert.after').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179889 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.expand'] = (() => {

    let get, layout;

    let var_init_locked_1557128179890;

    let var_current_scope_1557128179890;



    function main(id) {


        /**
         * 
         * 展开
         * 
         * @import get from tree.node.get scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         */

        let node = get(id);

        if (node) {

            node.view.expand();

            layout();
        }

        return false;


    }

    return function(id) {




        if (!var_current_scope_1557128179890 !== this) {

            get = include('tree.node.get').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179890 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree.mind.collapse'] = (() => {

    let get, layout;

    let var_init_locked_1557128179892;

    let var_current_scope_1557128179892;



    function main(id) {


        /**
         * 
         * 收起
         * 
         * @import get from tree.node.get scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         */

        let node = get(id);

        if (node) {

            node.view.collapse();

            layout();
        }

        return false;


    }

    return function(id) {




        if (!var_current_scope_1557128179892 !== this) {

            get = include('tree.node.get').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179892 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree.mind.append'] = (() => {

    let append, layout;

    let var_init_locked_1557128179894;

    let var_current_scope_1557128179894;



    function main(id, config) {


        /**
         * 
         * 增加子节点
         * 
         * @import append from tree.append scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        if (append(id, config)) {

            layout();
        }



    }

    return function(id, config) {




        if (!var_current_scope_1557128179894 !== this) {

            append = include('tree.append').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179894 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.remove'] = (() => {

    let deselect, remove, layout;

    let var_init_locked_1557128179896;

    let var_current_scope_1557128179896;



    function main(id, config) {


        /**
         * 
         * 删除子节点
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import remove from tree.remove scoped
         * 
         * @import layout from ..layout scoped
         * 
         * @param {string} id 节点编号
         * 
         * @param {object} config 节点配置
         * 
         */

        deselect();

        if (remove(id, config)) {

            layout();
        }


    }

    return function(id, config) {




        if (!var_current_scope_1557128179896 !== this) {

            deselect = include('src::tree.mind.deselect').bind(this);
            remove = include('tree.remove').bind(this);
            layout = include('src::tree.mind.layout').bind(this);

            var_current_scope_1557128179896 = this;
        }


        return main.call(this, id, config);
    };

})();

exports['src::tree.mind.select'] = (() => {

    let deselect, get;

    let var_init_locked_1557128179898;

    let var_current_scope_1557128179898;



    function main(id) {


        /**
         * 
         * 选定节点
         * 
         * @import deselect from ..deselect scoped
         * 
         * @import get from tree.node.get scoped
         * 
         * @param {string} id 需要选定的节点
         * 
         */

        let me = this,
            {
                proxy
            } = me,
            node = get(id);

        if (node) {

            deselect();

            node.selected = true;

            me.selectedNode = node;

            proxy.call('select', node.index);
        }



    }

    return function(id) {




        if (!var_current_scope_1557128179898 !== this) {

            deselect = include('src::tree.mind.deselect').bind(this);
            get = include('tree.node.get').bind(this);

            var_current_scope_1557128179898 = this;
        }


        return main.call(this, id);
    };

})();

exports['src::tree.mind.select.right'] = (() => {









    function main() {


        /**
         * 
         * 向右选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.right();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.left'] = (() => {









    function main() {


        /**
         * 
         * 向左选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.left();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.up'] = (() => {









    function main() {


        /**
         * 
         * 向上选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.up();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind.select.down'] = (() => {









    function main() {


        /**
         * 
         * 向下选择节点
         * 
         */

        let me = this,
            {
                selectedNode
            } = me;

        if (selectedNode) {

            let relationship = selectedNode.relationship.down();

            if (relationship) {

                me.select(relationship.node.id);
            }
        }

    }

    return function() {





        return main.call(this);
    };

})();

exports['src::tree.mind'] = (() => {

    let extend, constructor, method_clear, method_load, method_insertAfter, method_expand, method_collapse, method_append, method_remove, method_deselect, method_select, method_selectRight, method_selectLeft, method_selectUp, method_selectDown, method_layout;

    let var_init_locked_1557128179908;

    let var_class_1557128179908;

    return function(target, config) {


        if (!var_init_locked_1557128179908) {

            extend = include('src::tree.mind.extend')();
            constructor = include('src::tree.mind.constructor');
            method_clear = include('src::tree.mind.clear');
            method_load = include('src::tree.mind.load');
            method_insertAfter = include('tree.mind.insert.after');
            method_expand = include('src::tree.mind.expand');
            method_collapse = include('src::tree.mind.collapse');
            method_append = include('src::tree.mind.append');
            method_remove = include('src::tree.mind.remove');
            method_deselect = include('src::tree.mind.deselect');
            method_select = include('src::tree.mind.select');
            method_selectRight = include('src::tree.mind.select.right');
            method_selectLeft = include('src::tree.mind.select.left');
            method_selectUp = include('src::tree.mind.select.up');
            method_selectDown = include('src::tree.mind.select.down');
            method_layout = include('src::tree.mind.layout');

            var_init_locked_1557128179908 = true;
        }



        if (!var_class_1557128179908) {

            class main extends mixins({
                extend,
                mixins: []
            }) {





                constructor(...args) {

                    super(...args);

                    constructor.apply(this, args);

                }

                clear(...args) {

                    return method_clear.apply(this, args);

                }
                load(...args) {

                    return method_load.apply(this, args);

                }
                insertAfter(...args) {

                    return method_insertAfter.apply(this, args);

                }
                expand(...args) {

                    return method_expand.apply(this, args);

                }
                collapse(...args) {

                    return method_collapse.apply(this, args);

                }
                append(...args) {

                    return method_append.apply(this, args);

                }
                remove(...args) {

                    return method_remove.apply(this, args);

                }
                deselect(...args) {

                    return method_deselect.apply(this, args);

                }
                select(...args) {

                    return method_select.apply(this, args);

                }
                selectRight(...args) {

                    return method_selectRight.apply(this, args);

                }
                selectLeft(...args) {

                    return method_selectLeft.apply(this, args);

                }
                selectUp(...args) {

                    return method_selectUp.apply(this, args);

                }
                selectDown(...args) {

                    return method_selectDown.apply(this, args);

                }
                layout(...args) {

                    return method_layout.apply(this, args);

                }



            }

            var_class_1557128179908 = main;
        }


        return new var_class_1557128179908(target, config);
    };

})();